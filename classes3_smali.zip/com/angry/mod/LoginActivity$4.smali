.class Lcom/angry/mod/LoginActivity$4;
.super Ljava/lang/Object;
.source "LoginActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 331
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 334
    invoke-static {}, Lcom/angry/mod/LoginActivity;->access$100()Landroid/widget/TextView;

    move-result-object v0

    if-eqz v0, :cond_1d

    .line 335
    invoke-static {}, Lcom/angry/mod/LoginActivity;->access$100()Landroid/widget/TextView;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 336
    invoke-static {}, Lcom/angry/mod/LoginActivity;->access$600()Landroid/widget/Button;

    move-result-object v0

    if-eqz v0, :cond_1d

    .line 337
    invoke-static {}, Lcom/angry/mod/LoginActivity;->access$600()Landroid/widget/Button;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 340
    :cond_1d
    return-void
.end method
