.class Lcom/angry/mod/Floater$9;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater;->addSeekBar(Ljava/lang/String;IILjava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$ID:I

.field final synthetic val$max:I

.field final synthetic val$name:Ljava/lang/String;

.field final synthetic val$type:Ljava/lang/String;

.field final synthetic val$value:I


# direct methods
.method constructor <init>(Ljava/lang/String;IILjava/lang/String;I)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 659
    iput-object p1, p0, Lcom/angry/mod/Floater$9;->val$name:Ljava/lang/String;

    iput p2, p0, Lcom/angry/mod/Floater$9;->val$value:I

    iput p3, p0, Lcom/angry/mod/Floater$9;->val$max:I

    iput-object p4, p0, Lcom/angry/mod/Floater$9;->val$type:Ljava/lang/String;

    iput p5, p0, Lcom/angry/mod/Floater$9;->val$ID:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    .line 662
    iget-object v0, p0, Lcom/angry/mod/Floater$9;->val$name:Ljava/lang/String;

    iget v1, p0, Lcom/angry/mod/Floater$9;->val$value:I

    iget v2, p0, Lcom/angry/mod/Floater$9;->val$max:I

    iget-object v3, p0, Lcom/angry/mod/Floater$9;->val$type:Ljava/lang/String;

    iget v4, p0, Lcom/angry/mod/Floater$9;->val$ID:I

    invoke-static {v0, v1, v2, v3, v4}, Lcom/angry/mod/Floater;->addSeekBar(Ljava/lang/String;IILjava/lang/String;I)V

    .line 663
    return-void
.end method
