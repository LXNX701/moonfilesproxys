.class public Lcom/angry/mod/ESPView;
.super Landroid/view/View;
.source "ESPView.java"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field static sleepTime:J


# instance fields
.field FPS:I

.field formatter:Ljava/text/SimpleDateFormat;

.field mFilledPaint:Landroid/graphics/Paint;

.field mFilledPaint2:Landroid/graphics/Paint;

.field mStrokePaint:Landroid/graphics/Paint;

.field mStrokePaint2:Landroid/graphics/Paint;

.field mTextPaint:Landroid/graphics/Paint;

.field mTextPaint2:Landroid/graphics/Paint;

.field mThread:Ljava/lang/Thread;

.field time:Ljava/util/Date;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 5
    .param p1, "context"  # Landroid/content/Context;

    .line 33
    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, v0, v1}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 23
    const/16 v0, 0x3c

    iput v0, p0, Lcom/angry/mod/ESPView;->FPS:I

    .line 34
    invoke-virtual {p0}, Lcom/angry/mod/ESPView;->InitializePaints()V

    .line 35
    invoke-virtual {p0, v1}, Lcom/angry/mod/ESPView;->setFocusableInTouchMode(Z)V

    .line 36
    invoke-virtual {p0, v1}, Lcom/angry/mod/ESPView;->setBackgroundColor(I)V

    .line 37
    new-instance v0, Ljava/util/Date;

    invoke-direct {v0}, Ljava/util/Date;-><init>()V

    iput-object v0, p0, Lcom/angry/mod/ESPView;->time:Ljava/util/Date;

    .line 38
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "HH:mm:ss"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lcom/angry/mod/ESPView;->formatter:Ljava/text/SimpleDateFormat;

    .line 39
    const/16 v0, 0x3e8

    iget v1, p0, Lcom/angry/mod/ESPView;->FPS:I

    div-int/2addr v0, v1

    int-to-long v0, v0

    sput-wide v0, Lcom/angry/mod/ESPView;->sleepTime:J

    .line 40
    new-instance v0, Ljava/lang/Thread;

    invoke-direct {v0, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    iput-object v0, p0, Lcom/angry/mod/ESPView;->mThread:Ljava/lang/Thread;

    .line 41
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 42
    return-void
.end method

.method public static ChangeFps(I)V
    .registers 3
    .param p0, "fps"  # I

    .line 29
    add-int/lit8 v0, p0, 0x14

    const/16 v1, 0x3e8

    div-int/2addr v1, v0

    int-to-long v0, v1

    sput-wide v0, Lcom/angry/mod/ESPView;->sleepTime:J

    .line 30
    return-void
.end method


# virtual methods
.method public ClearCanvas(Landroid/graphics/Canvas;)V
    .registers 4
    .param p1, "cvs"  # Landroid/graphics/Canvas;

    .line 101
    const/4 v0, 0x0

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    .line 102
    return-void
.end method

.method public DebugText(Ljava/lang/String;)V
    .registers 3
    .param p1, "s"  # Ljava/lang/String;

    .line 223
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v0, p1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 224
    return-void
.end method

.method public DrawCircle(Landroid/graphics/Canvas;IIIIFFFF)V
    .registers 12
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "stroke"  # F
    .param p7, "posX"  # F
    .param p8, "posY"  # F
    .param p9, "radius"  # F

    .line 131
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mStrokePaint2:Landroid/graphics/Paint;

    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 132
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mStrokePaint2:Landroid/graphics/Paint;

    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 133
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mStrokePaint2:Landroid/graphics/Paint;

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 134
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mStrokePaint2:Landroid/graphics/Paint;

    invoke-virtual {p1, p7, p8, p9, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 135
    return-void
.end method

.method public DrawDistance(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V
    .registers 11
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "txt"  # Ljava/lang/String;
    .param p7, "posX"  # F
    .param p8, "posY"  # F
    .param p9, "size"  # F

    .line 192
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p2, p3, p4, p5}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 193
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p9}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 194
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, p6, p7, p8, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 195
    return-void
.end method

.method public DrawEnemyCount(Landroid/graphics/Canvas;IIIIIIII)V
    .registers 14
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "x"  # I
    .param p7, "y"  # I
    .param p8, "width"  # I
    .param p9, "height"  # I

    .line 204
    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    const/4 v1, 0x0

    filled-new-array {v1, v0, v1}, [I

    move-result-object v0

    .line 205
    .local v0, "colors":[I
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    sget-object v3, Landroid/graphics/drawable/GradientDrawable$Orientation;->RIGHT_LEFT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-direct {v2, v3, v0}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 206
    .local v2, "mDrawable":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v2, v1}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 207
    const/high16 v3, 0x42f00000  # 120.0f

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setGradientRadius(F)V

    .line 208
    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3, p6, p7, p8, p9}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 209
    .local v3, "mRect":Landroid/graphics/Rect;
    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setBounds(Landroid/graphics/Rect;)V

    .line 210
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 211
    invoke-virtual {v2, v1}, Landroid/graphics/drawable/GradientDrawable;->setGradientType(I)V

    .line 212
    invoke-virtual {v2, p1}, Landroid/graphics/drawable/GradientDrawable;->draw(Landroid/graphics/Canvas;)V

    .line 213
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 214
    return-void
.end method

.method public DrawFilledCircle(Landroid/graphics/Canvas;IIIIFFF)V
    .registers 11
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "posX"  # F
    .param p7, "posY"  # F
    .param p8, "radius"  # F

    .line 138
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 139
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 140
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, p6, p7, p8, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 141
    return-void
.end method

.method public DrawFilledName(Landroid/graphics/Canvas;IIIIFFFF)V
    .registers 19
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "x"  # F
    .param p7, "y"  # F
    .param p8, "width"  # F
    .param p9, "height"  # F

    .line 217
    move-object v0, p0

    iget-object v1, v0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 218
    iget-object v1, v0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    move v2, p2

    invoke-virtual {v1, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 219
    iget-object v8, v0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    move-object v3, p1

    move v4, p6

    move/from16 v5, p7

    move/from16 v6, p8

    move/from16 v7, p9

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 220
    return-void
.end method

.method public DrawFilledRect(Landroid/graphics/Canvas;IIIIFFFF)V
    .registers 19
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "x"  # F
    .param p7, "y"  # F
    .param p8, "width"  # F
    .param p9, "height"  # F

    .line 119
    move-object v0, p0

    iget-object v1, v0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 120
    iget-object v1, v0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    move v2, p2

    invoke-virtual {v1, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 121
    add-float v6, p6, p8

    add-float v7, p7, p9

    iget-object v8, v0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    move-object v3, p1

    move v4, p6

    move/from16 v5, p7

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 122
    return-void
.end method

.method public DrawFilledRect1(Landroid/graphics/Canvas;IIIIFFFF)V
    .registers 19
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "x"  # F
    .param p7, "y"  # F
    .param p8, "width"  # F
    .param p9, "height"  # F

    .line 125
    move-object v0, p0

    iget-object v1, v0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 126
    iget-object v1, v0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    move v2, p2

    invoke-virtual {v1, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 127
    iget-object v8, v0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    move-object v3, p1

    move v4, p6

    move/from16 v5, p7

    move/from16 v6, p8

    move/from16 v7, p9

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 128
    return-void
.end method

.method public DrawLine(Landroid/graphics/Canvas;IIIIFFFFF)V
    .registers 21
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "lineWidth"  # F
    .param p7, "fromX"  # F
    .param p8, "fromY"  # F
    .param p9, "toX"  # F
    .param p10, "toY"  # F

    .line 105
    move-object v0, p0

    iget-object v1, v0, Lcom/angry/mod/ESPView;->mStrokePaint:Landroid/graphics/Paint;

    invoke-static {p3, p4, p5}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 106
    iget-object v1, v0, Lcom/angry/mod/ESPView;->mStrokePaint:Landroid/graphics/Paint;

    move v2, p2

    invoke-virtual {v1, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 107
    iget-object v1, v0, Lcom/angry/mod/ESPView;->mStrokePaint:Landroid/graphics/Paint;

    move/from16 v3, p6

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 108
    iget-object v9, v0, Lcom/angry/mod/ESPView;->mStrokePaint:Landroid/graphics/Paint;

    move-object v4, p1

    move/from16 v5, p7

    move/from16 v6, p8

    move/from16 v7, p9

    move/from16 v8, p10

    invoke-virtual/range {v4 .. v9}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 109
    return-void
.end method

.method public DrawName(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V
    .registers 14
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "nametxt"  # Ljava/lang/String;
    .param p7, "posX"  # F
    .param p8, "posY"  # F
    .param p9, "size"  # F

    .line 162
    const-string v0, ":"

    invoke-virtual {p6, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 163
    .local v0, "namesp":[Ljava/lang/String;
    array-length v1, v0

    new-array v1, v1, [C

    .line 164
    .local v1, "nameChars":[C
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_a
    array-length v3, v0

    if-ge v2, v3, :cond_19

    .line 165
    aget-object v3, v0, v2

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    int-to-char v3, v3

    aput-char v3, v1, v2

    .line 164
    add-int/lit8 v2, v2, 0x1

    goto :goto_a

    .line 167
    .end local v2  # "i":I
    :cond_19
    new-instance v2, Ljava/lang/String;

    invoke-direct {v2, v1}, Ljava/lang/String;-><init>([C)V

    .line 168
    .local v2, "realname":Ljava/lang/String;
    iget-object v3, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v3, p2, p3, p4, p5}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 169
    iget-object v3, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v3, p9}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 170
    iget-object v3, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v2, p7, p8, v3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 171
    return-void
.end method

.method public DrawName1(Landroid/graphics/Canvas;IIIILjava/lang/String;IFFF)V
    .registers 16
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "nametxt"  # Ljava/lang/String;
    .param p7, "teamid"  # I
    .param p8, "posX"  # F
    .param p9, "posY"  # F
    .param p10, "size"  # F

    .line 174
    const-string v0, ":"

    invoke-virtual {p6, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 175
    .local v0, "namesp":[Ljava/lang/String;
    array-length v1, v0

    new-array v1, v1, [C

    .line 176
    .local v1, "nameChars":[C
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_a
    array-length v3, v0

    if-ge v2, v3, :cond_19

    .line 177
    aget-object v3, v0, v2

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    int-to-char v3, v3

    aput-char v3, v1, v2

    .line 176
    add-int/lit8 v2, v2, 0x1

    goto :goto_a

    .line 179
    .end local v2  # "i":I
    :cond_19
    new-instance v2, Ljava/lang/String;

    invoke-direct {v2, v1}, Ljava/lang/String;-><init>([C)V

    .line 180
    .local v2, "realname":Ljava/lang/String;
    iget-object v3, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v3, p2, p3, p4, p5}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 181
    iget-object v3, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v3, p10}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 182
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v3, p8, p9, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 183
    return-void
.end method

.method public DrawRect(Landroid/graphics/Canvas;IIIIFFFFFF)V
    .registers 24
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "stroke"  # F
    .param p7, "x"  # F
    .param p8, "y"  # F
    .param p9, "width"  # F
    .param p10, "height"  # F
    .param p11, "corner_rad"  # F

    .line 112
    move-object v0, p0

    iget-object v1, v0, Lcom/angry/mod/ESPView;->mStrokePaint:Landroid/graphics/Paint;

    move/from16 v2, p6

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 113
    iget-object v1, v0, Lcom/angry/mod/ESPView;->mStrokePaint:Landroid/graphics/Paint;

    invoke-static/range {p3 .. p5}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 114
    iget-object v1, v0, Lcom/angry/mod/ESPView;->mStrokePaint:Landroid/graphics/Paint;

    move v3, p2

    invoke-virtual {v1, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 115
    iget-object v11, v0, Lcom/angry/mod/ESPView;->mStrokePaint:Landroid/graphics/Paint;

    move-object v4, p1

    move/from16 v5, p7

    move/from16 v6, p8

    move/from16 v7, p9

    move/from16 v8, p10

    move/from16 v9, p11

    move/from16 v10, p11

    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 116
    return-void
.end method

.method public DrawTeamID(Landroid/graphics/Canvas;IIIIIFFF)V
    .registers 12
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "teamid"  # I
    .param p7, "posX"  # F
    .param p8, "posY"  # F
    .param p9, "size"  # F

    .line 186
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p2, p3, p4, p5}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 187
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    const/high16 v1, 0x41900000  # 18.0f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 188
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, p7, p8, v1}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 189
    return-void
.end method

.method public DrawText(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V
    .registers 11
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "txt"  # Ljava/lang/String;
    .param p7, "posX"  # F
    .param p8, "posY"  # F
    .param p9, "size"  # F

    .line 144
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p2, p3, p4, p5}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 145
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p9}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 146
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, p6, p7, p8, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 147
    return-void
.end method

.method public DrawText1(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V
    .registers 13
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "txt"  # Ljava/lang/String;
    .param p7, "posX"  # F
    .param p8, "posY"  # F
    .param p9, "size"  # F

    .line 150
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p2, p3, p4, p5}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 151
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p9}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 152
    const v0, 0x445d4000  # 885.0f

    sub-float v0, p7, v0

    const/high16 v1, 0x446b0000  # 940.0f

    add-float/2addr v1, p8

    iget-object v2, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, p6, v0, v1, v2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 153
    return-void
.end method

.method public DrawTextBot(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V
    .registers 11
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "txt"  # Ljava/lang/String;
    .param p7, "posX"  # F
    .param p8, "posY"  # F
    .param p9, "size"  # F

    .line 156
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p2, p3, p4, p5}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 157
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p9}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 158
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, p6, p7, p8, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 159
    return-void
.end method

.method public DrawWeapon(Landroid/graphics/Canvas;IIIIIIFFF)V
    .registers 13
    .param p1, "cvs"  # Landroid/graphics/Canvas;
    .param p2, "a"  # I
    .param p3, "r"  # I
    .param p4, "g"  # I
    .param p5, "b"  # I
    .param p6, "wid"  # I
    .param p7, "ammo"  # I
    .param p8, "posX"  # F
    .param p9, "posY"  # F
    .param p10, "size"  # F

    .line 198
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p2, p3, p4, p5}, Landroid/graphics/Paint;->setARGB(IIII)V

    .line 199
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p10}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 200
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, p8, p9, v1}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 201
    return-void
.end method

.method public InitializePaints()V
    .registers 4

    .line 71
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/angry/mod/ESPView;->mStrokePaint:Landroid/graphics/Paint;

    .line 72
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 73
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mStrokePaint:Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 75
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/angry/mod/ESPView;->mStrokePaint2:Landroid/graphics/Paint;

    .line 76
    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 77
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mStrokePaint2:Landroid/graphics/Paint;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 79
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    .line 80
    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 81
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mFilledPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 83
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/angry/mod/ESPView;->mFilledPaint2:Landroid/graphics/Paint;

    .line 84
    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 85
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mFilledPaint2:Landroid/graphics/Paint;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 86
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mFilledPaint2:Landroid/graphics/Paint;

    const/4 v2, 0x0

    invoke-static {v2, v2, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 88
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    .line 89
    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 90
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 91
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 92
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint:Landroid/graphics/Paint;

    const v2, 0x3f8ccccd  # 1.1f

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 94
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint2:Landroid/graphics/Paint;

    .line 95
    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 96
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint2:Landroid/graphics/Paint;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 97
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mTextPaint2:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 98
    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 4
    .param p1, "canvas"  # Landroid/graphics/Canvas;

    .line 46
    if-eqz p1, :cond_16

    invoke-virtual {p0}, Lcom/angry/mod/ESPView;->getVisibility()I

    move-result v0

    if-nez v0, :cond_16

    .line 47
    invoke-virtual {p0, p1}, Lcom/angry/mod/ESPView;->ClearCanvas(Landroid/graphics/Canvas;)V

    .line 48
    invoke-static {}, Lcom/angry/mod/Floater;->Width()I

    move-result v0

    .line 49
    .local v0, "DEVICE_WIDTH":I
    invoke-static {}, Lcom/angry/mod/Floater;->Height()I

    move-result v1

    .line 50
    .local v1, "DEVICE_HEIGHT":I
    invoke-static {p0, p1, v0, v1}, Lcom/angry/mod/Floater;->PxbftKZXivSr(Lcom/angry/mod/ESPView;Landroid/graphics/Canvas;II)V

    .line 52
    .end local v0  # "DEVICE_WIDTH":I
    .end local v1  # "DEVICE_HEIGHT":I
    :cond_16
    return-void
.end method

.method public run()V
    .registers 9

    .line 56
    const/16 v0, 0xa

    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V

    .line 57
    :goto_5
    iget-object v0, p0, Lcom/angry/mod/ESPView;->mThread:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->isAlive()Z

    move-result v0

    if-eqz v0, :cond_3d

    iget-object v0, p0, Lcom/angry/mod/ESPView;->mThread:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v0

    if-nez v0, :cond_3d

    .line 59
    :try_start_15
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 60
    .local v0, "t1":J
    invoke-virtual {p0}, Lcom/angry/mod/ESPView;->postInvalidate()V

    .line 61
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    sub-long/2addr v2, v0

    .line 62
    .local v2, "td":J
    sget-wide v4, Lcom/angry/mod/ESPView;->sleepTime:J

    sub-long/2addr v4, v2

    const-wide/16 v6, 0x0

    invoke-static {v6, v7, v4, v5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v4

    sget-wide v6, Lcom/angry/mod/ESPView;->sleepTime:J

    invoke-static {v4, v5, v6, v7}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_33
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_33} :catch_34

    .line 66
    .end local v0  # "t1":J
    .end local v2  # "td":J
    goto :goto_5

    .line 63
    :catch_34
    move-exception v0

    .line 64
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Thread;->interrupt()V

    .line 65
    return-void

    .line 68
    .end local v0  # "e":Ljava/lang/Exception;
    :cond_3d
    return-void
.end method
