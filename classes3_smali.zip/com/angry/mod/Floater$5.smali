.class Lcom/angry/mod/Floater$5;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater;->addCategory(Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$height:I

.field final synthetic val$name:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;I)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 509
    iput-object p1, p0, Lcom/angry/mod/Floater$5;->val$name:Ljava/lang/String;

    iput p2, p0, Lcom/angry/mod/Floater$5;->val$height:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 512
    iget-object v0, p0, Lcom/angry/mod/Floater$5;->val$name:Ljava/lang/String;

    iget v1, p0, Lcom/angry/mod/Floater$5;->val$height:I

    invoke-static {v0, v1}, Lcom/angry/mod/Floater;->addCategory(Ljava/lang/String;I)V

    .line 513
    return-void
.end method
