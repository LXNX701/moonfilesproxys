.class Lcom/angry/mod/SwitchStyle$3;
.super Ljava/lang/Object;
.source "SwitchStyle.java"

# interfaces
.implements Landroid/animation/Animator$AnimatorListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/angry/mod/SwitchStyle;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/angry/mod/SwitchStyle;


# direct methods
.method constructor <init>(Lcom/angry/mod/SwitchStyle;)V
    .registers 2
    .param p1, "this$0"  # Lcom/angry/mod/SwitchStyle;

    .line 834
    iput-object p1, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationCancel(Landroid/animation/Animator;)V
    .registers 2
    .param p1, "animation"  # Landroid/animation/Animator;

    .line 880
    return-void
.end method

.method public onAnimationEnd(Landroid/animation/Animator;)V
    .registers 5
    .param p1, "animation"  # Landroid/animation/Animator;

    .line 841
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0}, Lcom/angry/mod/SwitchStyle;->access$300(Lcom/angry/mod/SwitchStyle;)I

    move-result v0

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_66

    goto :goto_64

    .line 865
    :pswitch_b  #0x5
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0}, Lcom/angry/mod/SwitchStyle;->access$1500(Lcom/angry/mod/SwitchStyle;)Z

    move-result v2

    xor-int/lit8 v2, v2, 0x1

    invoke-static {v0, v2}, Lcom/angry/mod/SwitchStyle;->access$1502(Lcom/angry/mod/SwitchStyle;Z)Z

    .line 866
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0, v1}, Lcom/angry/mod/SwitchStyle;->access$302(Lcom/angry/mod/SwitchStyle;I)I

    .line 867
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-virtual {v0}, Lcom/angry/mod/SwitchStyle;->postInvalidate()V

    .line 868
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0}, Lcom/angry/mod/SwitchStyle;->access$1400(Lcom/angry/mod/SwitchStyle;)V

    .line 869
    goto :goto_64

    .line 859
    :pswitch_26  #0x4
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0, v1}, Lcom/angry/mod/SwitchStyle;->access$302(Lcom/angry/mod/SwitchStyle;I)I

    .line 860
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-virtual {v0}, Lcom/angry/mod/SwitchStyle;->postInvalidate()V

    .line 861
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0}, Lcom/angry/mod/SwitchStyle;->access$1400(Lcom/angry/mod/SwitchStyle;)V

    .line 862
    goto :goto_64

    .line 854
    :pswitch_36  #0x3
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0, v1}, Lcom/angry/mod/SwitchStyle;->access$302(Lcom/angry/mod/SwitchStyle;I)I

    .line 855
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-virtual {v0}, Lcom/angry/mod/SwitchStyle;->postInvalidate()V

    .line 856
    goto :goto_64

    .line 843
    :pswitch_41  #0x2
    goto :goto_64

    .line 846
    :pswitch_42  #0x1
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    const/4 v2, 0x2

    invoke-static {v0, v2}, Lcom/angry/mod/SwitchStyle;->access$302(Lcom/angry/mod/SwitchStyle;I)I

    .line 847
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v0

    iput v1, v0, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    .line 848
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v0

    iget-object v1, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v1}, Lcom/angry/mod/SwitchStyle;->access$1200(Lcom/angry/mod/SwitchStyle;)F

    move-result v1

    iput v1, v0, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    .line 850
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$3;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-virtual {v0}, Lcom/angry/mod/SwitchStyle;->postInvalidate()V

    .line 851
    nop

    .line 876
    :goto_64
    return-void

    nop

    :pswitch_data_66
    .packed-switch 0x1
        :pswitch_42  #00000001
        :pswitch_41  #00000002
        :pswitch_36  #00000003
        :pswitch_26  #00000004
        :pswitch_b  #00000005
    .end packed-switch
.end method

.method public onAnimationRepeat(Landroid/animation/Animator;)V
    .registers 2
    .param p1, "animation"  # Landroid/animation/Animator;

    .line 884
    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .registers 2
    .param p1, "animation"  # Landroid/animation/Animator;

    .line 837
    return-void
.end method
