.class Lcom/angry/mod/Floater$7;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater;->addSwitch(Ljava/lang/String;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$ID:I

.field final synthetic val$height:I

.field final synthetic val$name:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 592
    iput-object p1, p0, Lcom/angry/mod/Floater$7;->val$name:Ljava/lang/String;

    iput p2, p0, Lcom/angry/mod/Floater$7;->val$ID:I

    iput p3, p0, Lcom/angry/mod/Floater$7;->val$height:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 595
    iget-object v0, p0, Lcom/angry/mod/Floater$7;->val$name:Ljava/lang/String;

    iget v1, p0, Lcom/angry/mod/Floater$7;->val$ID:I

    iget v2, p0, Lcom/angry/mod/Floater$7;->val$height:I

    invoke-static {v0, v1, v2}, Lcom/angry/mod/Floater;->addSwitch(Ljava/lang/String;II)V

    .line 596
    return-void
.end method
