.class Lcom/angry/mod/Floater$2;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater;->onCreateTemplate()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/angry/mod/Floater;


# direct methods
.method constructor <init>(Lcom/angry/mod/Floater;)V
    .registers 2
    .param p1, "this$0"  # Lcom/angry/mod/Floater;

    .line 377
    iput-object p1, p0, Lcom/angry/mod/Floater$2;->this$0:Lcom/angry/mod/Floater;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 4
    .param p1, "view"  # Landroid/view/View;

    .line 380
    iget-object v0, p0, Lcom/angry/mod/Floater$2;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$400(Lcom/angry/mod/Floater;)Landroid/widget/RelativeLayout;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 381
    iget-object v0, p0, Lcom/angry/mod/Floater$2;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$500(Lcom/angry/mod/Floater;)Landroid/widget/LinearLayout;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 382
    return-void
.end method
