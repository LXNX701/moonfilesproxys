.class Lcom/angry/mod/Floater$4;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater;->createOnTouchListener()Landroid/view/View$OnTouchListener;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private initialTouchX:F

.field private initialTouchY:F

.field private initialX:I

.field private initialY:I

.field final synthetic this$0:Lcom/angry/mod/Floater;


# direct methods
.method constructor <init>(Lcom/angry/mod/Floater;)V
    .registers 2
    .param p1, "this$0"  # Lcom/angry/mod/Floater;

    .line 428
    iput-object p1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 9
    .param p1, "v"  # Landroid/view/View;
    .param p2, "event"  # Landroid/view/MotionEvent;

    .line 437
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/high16 v1, 0x41200000  # 10.0f

    const/4 v2, 0x1

    const/4 v3, 0x0

    packed-switch v0, :pswitch_data_136

    .line 496
    return v3

    .line 460
    :pswitch_c  #0x2
    iget-object v0, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$700(Lcom/angry/mod/Floater;)Z

    move-result v0

    if-eqz v0, :cond_15

    .line 461
    return v2

    .line 464
    :cond_15
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iget v3, p0, Lcom/angry/mod/Floater$4;->initialTouchX:F

    sub-float/2addr v0, v3

    .line 465
    .local v0, "moveX":F
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v3

    iget v4, p0, Lcom/angry/mod/Floater$4;->initialTouchY:F

    sub-float/2addr v3, v4

    .line 467
    .local v3, "moveY":F
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v4

    cmpl-float v4, v4, v1

    if-gtz v4, :cond_33

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v4

    cmpl-float v1, v4, v1

    if-lez v1, :cond_6f

    .line 468
    :cond_33
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$900(Lcom/angry/mod/Floater;)Landroid/os/Handler;

    move-result-object v1

    iget-object v4, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v4}, Lcom/angry/mod/Floater;->access$800(Lcom/angry/mod/Floater;)Ljava/lang/Runnable;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 469
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$600(Lcom/angry/mod/Floater;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v1

    iget v4, p0, Lcom/angry/mod/Floater$4;->initialX:I

    float-to-int v5, v0

    add-int/2addr v4, v5

    iput v4, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 470
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$600(Lcom/angry/mod/Floater;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v1

    iget v4, p0, Lcom/angry/mod/Floater$4;->initialY:I

    float-to-int v5, v3

    add-int/2addr v4, v5

    iput v4, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 471
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$1100(Lcom/angry/mod/Floater;)Landroid/view/WindowManager;

    move-result-object v1

    iget-object v4, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v4}, Lcom/angry/mod/Floater;->access$1000(Lcom/angry/mod/Floater;)Landroid/widget/FrameLayout;

    move-result-object v4

    iget-object v5, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v5}, Lcom/angry/mod/Floater;->access$600(Lcom/angry/mod/Floater;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v5

    invoke-interface {v1, v4, v5}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 473
    :cond_6f
    return v2

    .line 476
    .end local v0  # "moveX":F
    .end local v3  # "moveY":F
    :pswitch_70  #0x1
    iget-object v0, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$900(Lcom/angry/mod/Floater;)Landroid/os/Handler;

    move-result-object v0

    iget-object v4, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v4}, Lcom/angry/mod/Floater;->access$800(Lcom/angry/mod/Floater;)Ljava/lang/Runnable;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 478
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iget v4, p0, Lcom/angry/mod/Floater$4;->initialTouchX:F

    sub-float/2addr v0, v4

    .line 479
    .local v0, "moveXUp":F
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v4

    iget v5, p0, Lcom/angry/mod/Floater$4;->initialTouchY:F

    sub-float/2addr v4, v5

    .line 481
    .local v4, "moveYUp":F
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v5

    cmpg-float v5, v5, v1

    if-gez v5, :cond_f4

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v5

    cmpg-float v1, v5, v1

    if-gez v1, :cond_f4

    .line 482
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$700(Lcom/angry/mod/Floater;)Z

    move-result v1

    if-nez v1, :cond_f4

    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$1200(Lcom/angry/mod/Floater;)Landroid/widget/ImageView;

    move-result-object v1

    if-ne p1, v1, :cond_f4

    invoke-static {}, Lcom/angry/mod/Floater;->isLoggedIn()Z

    move-result v1

    if-eqz v1, :cond_f4

    .line 483
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$400(Lcom/angry/mod/Floater;)Landroid/widget/RelativeLayout;

    move-result-object v1

    const/16 v5, 0x8

    invoke-virtual {v1, v5}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 484
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$500(Lcom/angry/mod/Floater;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 485
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$000(Lcom/angry/mod/Floater;)Z

    move-result v1

    if-eqz v1, :cond_e2

    .line 486
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$200(Lcom/angry/mod/Floater;)Landroid/widget/Button;

    move-result-object v1

    invoke-virtual {v1, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 487
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$300(Lcom/angry/mod/Floater;)Landroid/widget/Button;

    move-result-object v1

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_f4

    .line 489
    :cond_e2
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$200(Lcom/angry/mod/Floater;)Landroid/widget/Button;

    move-result-object v1

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 490
    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$300(Lcom/angry/mod/Floater;)Landroid/widget/Button;

    move-result-object v1

    invoke-virtual {v1, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 494
    :cond_f4
    :goto_f4
    return v2

    .line 439
    .end local v0  # "moveXUp":F
    .end local v4  # "moveYUp":F
    :pswitch_f5  #0x0
    iget-object v0, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$600(Lcom/angry/mod/Floater;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    iput v0, p0, Lcom/angry/mod/Floater$4;->initialX:I

    .line 440
    iget-object v0, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$600(Lcom/angry/mod/Floater;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    iput v0, p0, Lcom/angry/mod/Floater$4;->initialY:I

    .line 441
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iput v0, p0, Lcom/angry/mod/Floater$4;->initialTouchX:F

    .line 442
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v0

    iput v0, p0, Lcom/angry/mod/Floater$4;->initialTouchY:F

    .line 443
    iget-object v0, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0, v3}, Lcom/angry/mod/Floater;->access$702(Lcom/angry/mod/Floater;Z)Z

    .line 445
    iget-object v0, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    new-instance v1, Lcom/angry/mod/Floater$4$1;

    invoke-direct {v1, p0}, Lcom/angry/mod/Floater$4$1;-><init>(Lcom/angry/mod/Floater$4;)V

    invoke-static {v0, v1}, Lcom/angry/mod/Floater;->access$802(Lcom/angry/mod/Floater;Ljava/lang/Runnable;)Ljava/lang/Runnable;

    .line 456
    iget-object v0, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$900(Lcom/angry/mod/Floater;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v1}, Lcom/angry/mod/Floater;->access$800(Lcom/angry/mod/Floater;)Ljava/lang/Runnable;

    move-result-object v1

    const-wide/16 v3, 0x320

    invoke-virtual {v0, v1, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 457
    return v2

    :pswitch_data_136
    .packed-switch 0x0
        :pswitch_f5  #00000000
        :pswitch_70  #00000001
        :pswitch_c  #00000002
    .end packed-switch
.end method
