.class Lcom/angry/mod/Floater$6;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater;->addText(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$text:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 555
    iput-object p1, p0, Lcom/angry/mod/Floater$6;->val$text:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    .line 558
    iget-object v0, p0, Lcom/angry/mod/Floater$6;->val$text:Ljava/lang/String;

    invoke-static {v0}, Lcom/angry/mod/Floater;->addText(Ljava/lang/String;)V

    .line 559
    return-void
.end method
