.class public Lcom/angry/mod/Auth;
.super Landroid/os/AsyncTask;
.source "Auth.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field private final activityRef:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/app/Activity;)V
    .registers 3
    .param p1, "activity"  # Landroid/app/Activity;

    .line 14
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    .line 15
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/angry/mod/Auth;->activityRef:Ljava/lang/ref/WeakReference;

    .line 16
    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 8
    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/angry/mod/Auth;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .registers 8
    .param p1, "params"  # [Ljava/lang/String;

    .line 26
    iget-object v0, p0, Lcom/angry/mod/Auth;->activityRef:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/Activity;

    .line 27
    .local v0, "activity":Landroid/app/Activity;
    if-nez v0, :cond_d

    const-string v1, "Context Error"

    return-object v1

    .line 30
    :cond_d
    const/4 v1, 0x0

    aget-object v1, p1, v1

    .line 33
    .local v1, "userKey":Ljava/lang/String;
    nop

    .line 34
    invoke-virtual {v0}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    .line 33
    const-string v3, "android_id"

    invoke-static {v2, v3}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 40
    .local v2, "hwid":Ljava/lang/String;
    :try_start_1b
    invoke-virtual {p0, v1, v2}, Lcom/angry/mod/Auth;->nativeLogin(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_1f
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_1b .. :try_end_1f} :catch_20

    return-object v3

    .line 41
    :catch_20
    move-exception v3

    .line 42
    .local v3, "e":Ljava/lang/UnsatisfiedLinkError;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Library not loaded: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v3}, Ljava/lang/UnsatisfiedLinkError;->getMessage()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    return-object v4
.end method

.method public native nativeLogin(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 2

    .line 8
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/angry/mod/Auth;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .registers 4
    .param p1, "result"  # Ljava/lang/String;

    .line 48
    iget-object v0, p0, Lcom/angry/mod/Auth;->activityRef:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/Activity;

    .line 49
    .local v0, "activity":Landroid/app/Activity;
    const/4 v1, 0x0

    invoke-static {v1}, Lcom/angry/mod/LoginActivity;->showProgressBar(Z)V

    .line 51
    if-eqz v0, :cond_2a

    if-nez p1, :cond_11

    goto :goto_2a

    .line 55
    :cond_11
    const-string v1, "Login Success"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_24

    .line 56
    const-string v1, "Success"

    invoke-static {v0, p1, v1}, Lcom/angry/mod/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 59
    new-instance v1, Lcom/angry/mod/Initialize;

    invoke-direct {v1, v0}, Lcom/angry/mod/Initialize;-><init>(Landroid/content/Context;)V

    goto :goto_29

    .line 62
    :cond_24
    const-string v1, "Error"

    invoke-static {v0, p1, v1}, Lcom/angry/mod/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 64
    :goto_29
    return-void

    .line 51
    :cond_2a
    :goto_2a
    return-void
.end method

.method protected onPreExecute()V
    .registers 2

    .line 21
    const/4 v0, 0x1

    invoke-static {v0}, Lcom/angry/mod/LoginActivity;->showProgressBar(Z)V

    .line 22
    return-void
.end method
