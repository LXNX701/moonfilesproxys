.class Lcom/angry/mod/LoginActivity$3;
.super Ljava/lang/Object;
.source "LoginActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/LoginActivity;->ShowLoginScreen(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/angry/mod/LoginActivity;

.field final synthetic val$context:Landroid/content/Context;


# direct methods
.method constructor <init>(Lcom/angry/mod/LoginActivity;Landroid/content/Context;)V
    .registers 3
    .param p1, "this$0"  # Lcom/angry/mod/LoginActivity;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 286
    iput-object p1, p0, Lcom/angry/mod/LoginActivity$3;->this$0:Lcom/angry/mod/LoginActivity;

    iput-object p2, p0, Lcom/angry/mod/LoginActivity$3;->val$context:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6
    .param p1, "v"  # Landroid/view/View;

    .line 289
    iget-object v0, p0, Lcom/angry/mod/LoginActivity$3;->val$context:Landroid/content/Context;

    invoke-static {v0}, Lcom/angry/mod/NetworkUtils;->isVPNConnected(Landroid/content/Context;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_2b

    .line 291
    :try_start_9
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "su"

    aput-object v3, v2, v1

    const-string v1, "-c"

    const/4 v3, 0x1

    aput-object v1, v2, v3

    const-string v1, "reboot"

    const/4 v3, 0x2

    aput-object v1, v2, v3

    invoke-virtual {v0, v2}, Ljava/lang/Runtime;->exec([Ljava/lang/String;)Ljava/lang/Process;
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_21} :catch_22

    .line 294
    goto :goto_2a

    .line 292
    :catch_22
    move-exception v0

    .line 293
    .local v0, "e":Ljava/lang/Exception;
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    invoke-static {v1}, Landroid/os/Process;->killProcess(I)V

    .line 295
    .end local v0  # "e":Ljava/lang/Exception;
    :goto_2a
    return-void

    .line 298
    :cond_2b
    iget-object v0, p0, Lcom/angry/mod/LoginActivity$3;->this$0:Lcom/angry/mod/LoginActivity;

    invoke-static {v0}, Lcom/angry/mod/LoginActivity;->access$400(Lcom/angry/mod/LoginActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 299
    .local v0, "username":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_44

    .line 300
    return-void

    .line 302
    :cond_44
    iget-object v2, p0, Lcom/angry/mod/LoginActivity$3;->this$0:Lcom/angry/mod/LoginActivity;

    invoke-static {v2}, Lcom/angry/mod/LoginActivity;->access$500(Lcom/angry/mod/LoginActivity;)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 303
    .local v2, "editor":Landroid/content/SharedPreferences$Editor;
    const-string v3, "username"

    invoke-interface {v2, v3, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 304
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 305
    invoke-static {}, Lcom/angry/mod/LoginActivity;->access$600()Landroid/widget/Button;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 306
    invoke-static {}, Lcom/angry/mod/LoginActivity;->access$700()V

    .line 307
    iget-object v1, p0, Lcom/angry/mod/LoginActivity$3;->val$context:Landroid/content/Context;

    instance-of v1, v1, Lcom/angry/mod/MainActivity;

    if-eqz v1, :cond_76

    .line 308
    new-instance v1, Lcom/angry/mod/Auth;

    iget-object v3, p0, Lcom/angry/mod/LoginActivity$3;->val$context:Landroid/content/Context;

    check-cast v3, Lcom/angry/mod/MainActivity;

    invoke-direct {v1, v3}, Lcom/angry/mod/Auth;-><init>(Landroid/app/Activity;)V

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcom/angry/mod/Auth;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 310
    :cond_76
    return-void
.end method
