.class Lcom/angry/mod/SwitchStyle$ViewState;
.super Ljava/lang/Object;
.source "SwitchStyle.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/angry/mod/SwitchStyle;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ViewState"
.end annotation


# instance fields
.field buttonX:F

.field checkStateColor:I

.field checkedLineColor:I

.field radius:F


# direct methods
.method constructor <init>()V
    .registers 1

    .line 892
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/angry/mod/SwitchStyle$ViewState;Lcom/angry/mod/SwitchStyle$ViewState;)V
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle$ViewState;
    .param p1, "x1"  # Lcom/angry/mod/SwitchStyle$ViewState;

    .line 887
    invoke-direct {p0, p1}, Lcom/angry/mod/SwitchStyle$ViewState;->copy(Lcom/angry/mod/SwitchStyle$ViewState;)V

    return-void
.end method

.method private copy(Lcom/angry/mod/SwitchStyle$ViewState;)V
    .registers 3
    .param p1, "source"  # Lcom/angry/mod/SwitchStyle$ViewState;

    .line 894
    iget v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    iput v0, p0, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    .line 895
    iget v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    iput v0, p0, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    .line 896
    iget v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    iput v0, p0, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    .line 897
    iget v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    iput v0, p0, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    .line 898
    return-void
.end method
