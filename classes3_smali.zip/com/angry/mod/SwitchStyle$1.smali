.class Lcom/angry/mod/SwitchStyle$1;
.super Ljava/lang/Object;
.source "SwitchStyle.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/angry/mod/SwitchStyle;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/angry/mod/SwitchStyle;


# direct methods
.method constructor <init>(Lcom/angry/mod/SwitchStyle;)V
    .registers 2
    .param p1, "this$0"  # Lcom/angry/mod/SwitchStyle;

    .line 760
    iput-object p1, p0, Lcom/angry/mod/SwitchStyle$1;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    .line 763
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$1;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0}, Lcom/angry/mod/SwitchStyle;->access$100(Lcom/angry/mod/SwitchStyle;)Z

    move-result v0

    if-nez v0, :cond_d

    .line 764
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle$1;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v0}, Lcom/angry/mod/SwitchStyle;->access$200(Lcom/angry/mod/SwitchStyle;)V

    .line 766
    :cond_d
    return-void
.end method
