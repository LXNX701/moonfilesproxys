.class Lcom/angry/mod/LoginActivity$1;
.super Ljava/lang/Object;
.source "LoginActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/LoginActivity;-><init>(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/angry/mod/LoginActivity;


# direct methods
.method constructor <init>(Lcom/angry/mod/LoginActivity;)V
    .registers 2
    .param p1, "this$0"  # Lcom/angry/mod/LoginActivity;

    .line 74
    iput-object p1, p0, Lcom/angry/mod/LoginActivity$1;->this$0:Lcom/angry/mod/LoginActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 77
    :try_start_0
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const-string v1, "su"

    invoke-virtual {v0, v1}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_9} :catch_a

    .line 80
    goto :goto_12

    .line 78
    :catch_a
    move-exception v0

    .line 79
    .local v0, "e":Ljava/io/IOException;
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    invoke-static {v1}, Landroid/os/Process;->killProcess(I)V

    .line 81
    .end local v0  # "e":Ljava/io/IOException;
    :goto_12
    return-void
.end method
