.class public Lcom/angry/mod/Floater;
.super Ljava/lang/Object;
.source "Floater.java"


# static fields
.field private static DarkBackground:I

.field public static LightPurple:I

.field public static SCREEN_HEIGHT:I

.field public static SCREEN_WIDTH:I

.field private static TextColor:I

.field private static context:Landroid/content/Context;

.field public static funcsListLayout:Landroid/widget/LinearLayout;

.field private static googleSansFont:Landroid/graphics/Typeface;

.field private static utils:Lcom/angry/mod/Utils;


# instance fields
.field private closeButton:Landroid/widget/Button;

.field private collapsedRelative:Landroid/widget/RelativeLayout;

.field private drawView:Lcom/angry/mod/ESPView;

.field private funcsList:Landroid/widget/ScrollView;

.field private injectButton:Landroid/widget/Button;

.field private isInjected:Z

.field private isLongPressTriggered:Z

.field private logoImagem:Landroid/widget/ImageView;

.field private longPressHandler:Landroid/os/Handler;

.field private longPressRunnable:Ljava/lang/Runnable;

.field private menuLayout:Landroid/widget/LinearLayout;

.field private rootFrame:Landroid/widget/FrameLayout;

.field private rootRelative:Landroid/widget/RelativeLayout;

.field private tabBaixo:Landroid/widget/LinearLayout;

.field private tabBaixoRelative:Landroid/widget/RelativeLayout;

.field private tabCima:Landroid/widget/LinearLayout;

.field private tabCimaRelative:Landroid/widget/RelativeLayout;

.field private tituloText:Landroid/widget/TextView;

.field private windowManager:Landroid/view/WindowManager;

.field private windowManagerDrawViewParams:Landroid/view/WindowManager$LayoutParams;

.field private windowManagerParams:Landroid/view/WindowManager$LayoutParams;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 51
    const/4 v0, 0x0

    sput v0, Lcom/angry/mod/Floater;->SCREEN_WIDTH:I

    .line 52
    sput v0, Lcom/angry/mod/Floater;->SCREEN_HEIGHT:I

    .line 64
    const v0, -0x9ff77f

    sput v0, Lcom/angry/mod/Floater;->LightPurple:I

    .line 65
    const v0, -0x33eeeeef  # -3.8028356E7f

    sput v0, Lcom/angry/mod/Floater;->DarkBackground:I

    .line 66
    const/4 v0, -0x1

    sput v0, Lcom/angry/mod/Floater;->TextColor:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 4
    .param p1, "globContext"  # Landroid/content/Context;

    .line 96
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 90
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/angry/mod/Floater;->isInjected:Z

    .line 92
    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    iput-object v1, p0, Lcom/angry/mod/Floater;->longPressHandler:Landroid/os/Handler;

    .line 94
    iput-boolean v0, p0, Lcom/angry/mod/Floater;->isLongPressTriggered:Z

    .line 97
    sput-object p1, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    .line 98
    new-instance v0, Lcom/angry/mod/Utils;

    sget-object v1, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v0, v1}, Lcom/angry/mod/Utils;-><init>(Landroid/content/Context;)V

    sput-object v0, Lcom/angry/mod/Floater;->utils:Lcom/angry/mod/Utils;

    .line 100
    :try_start_1a
    sget-object v0, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v1, "fonts/GoogleSans-Regular.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/angry/mod/Floater;->googleSansFont:Landroid/graphics/Typeface;
    :try_end_28
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_28} :catch_29

    .line 103
    goto :goto_2e

    .line 101
    :catch_29
    move-exception v0

    .line 102
    .local v0, "e":Ljava/lang/Exception;
    sget-object v1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    sput-object v1, Lcom/angry/mod/Floater;->googleSansFont:Landroid/graphics/Typeface;

    .line 104
    .end local v0  # "e":Ljava/lang/Exception;
    :goto_2e
    invoke-virtual {p0}, Lcom/angry/mod/Floater;->onCreate()V

    .line 105
    return-void
.end method

.method public static native ChangesID(II)V
.end method

.method public static native Functions()V
.end method

.method public static Height()I
    .registers 1

    .line 60
    sget v0, Lcom/angry/mod/Floater;->SCREEN_HEIGHT:I

    if-nez v0, :cond_7

    const/16 v0, 0x438

    return v0

    .line 61
    :cond_7
    return v0
.end method

.method public static native PxbftKZXivSr(Lcom/angry/mod/ESPView;Landroid/graphics/Canvas;II)V
.end method

.method public static Width()I
    .registers 1

    .line 55
    sget v0, Lcom/angry/mod/Floater;->SCREEN_WIDTH:I

    if-nez v0, :cond_7

    const/16 v0, 0x780

    return v0

    .line 56
    :cond_7
    return v0
.end method

.method static synthetic access$000(Lcom/angry/mod/Floater;)Z
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-boolean v0, p0, Lcom/angry/mod/Floater;->isInjected:Z

    return v0
.end method

.method static synthetic access$002(Lcom/angry/mod/Floater;Z)Z
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;
    .param p1, "x1"  # Z

    .line 40
    iput-boolean p1, p0, Lcom/angry/mod/Floater;->isInjected:Z

    return p1
.end method

.method static synthetic access$100()Landroid/content/Context;
    .registers 1

    .line 40
    sget-object v0, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    return-object v0
.end method

.method static synthetic access$1000(Lcom/angry/mod/Floater;)Landroid/widget/FrameLayout;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-object v0, p0, Lcom/angry/mod/Floater;->rootFrame:Landroid/widget/FrameLayout;

    return-object v0
.end method

.method static synthetic access$1100(Lcom/angry/mod/Floater;)Landroid/view/WindowManager;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-object v0, p0, Lcom/angry/mod/Floater;->windowManager:Landroid/view/WindowManager;

    return-object v0
.end method

.method static synthetic access$1200(Lcom/angry/mod/Floater;)Landroid/widget/ImageView;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-object v0, p0, Lcom/angry/mod/Floater;->logoImagem:Landroid/widget/ImageView;

    return-object v0
.end method

.method static synthetic access$200(Lcom/angry/mod/Floater;)Landroid/widget/Button;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-object v0, p0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$300(Lcom/angry/mod/Floater;)Landroid/widget/Button;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-object v0, p0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$400(Lcom/angry/mod/Floater;)Landroid/widget/RelativeLayout;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-object v0, p0, Lcom/angry/mod/Floater;->collapsedRelative:Landroid/widget/RelativeLayout;

    return-object v0
.end method

.method static synthetic access$500(Lcom/angry/mod/Floater;)Landroid/widget/LinearLayout;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-object v0, p0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    return-object v0
.end method

.method static synthetic access$600(Lcom/angry/mod/Floater;)Landroid/view/WindowManager$LayoutParams;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-object v0, p0, Lcom/angry/mod/Floater;->windowManagerParams:Landroid/view/WindowManager$LayoutParams;

    return-object v0
.end method

.method static synthetic access$700(Lcom/angry/mod/Floater;)Z
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-boolean v0, p0, Lcom/angry/mod/Floater;->isLongPressTriggered:Z

    return v0
.end method

.method static synthetic access$702(Lcom/angry/mod/Floater;Z)Z
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;
    .param p1, "x1"  # Z

    .line 40
    iput-boolean p1, p0, Lcom/angry/mod/Floater;->isLongPressTriggered:Z

    return p1
.end method

.method static synthetic access$800(Lcom/angry/mod/Floater;)Ljava/lang/Runnable;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-object v0, p0, Lcom/angry/mod/Floater;->longPressRunnable:Ljava/lang/Runnable;

    return-object v0
.end method

.method static synthetic access$802(Lcom/angry/mod/Floater;Ljava/lang/Runnable;)Ljava/lang/Runnable;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;
    .param p1, "x1"  # Ljava/lang/Runnable;

    .line 40
    iput-object p1, p0, Lcom/angry/mod/Floater;->longPressRunnable:Ljava/lang/Runnable;

    return-object p1
.end method

.method static synthetic access$900(Lcom/angry/mod/Floater;)Landroid/os/Handler;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/Floater;

    .line 40
    iget-object v0, p0, Lcom/angry/mod/Floater;->longPressHandler:Landroid/os/Handler;

    return-object v0
.end method

.method public static addCategory(Ljava/lang/String;)V
    .registers 2
    .param p0, "name"  # Ljava/lang/String;

    .line 504
    const/16 v0, 0x16

    invoke-static {p0, v0}, Lcom/angry/mod/Floater;->addCategory(Ljava/lang/String;I)V

    .line 505
    return-void
.end method

.method public static addCategory(Ljava/lang/String;I)V
    .registers 10
    .param p0, "name"  # Ljava/lang/String;
    .param p1, "height"  # I

    .line 508
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    if-eq v0, v1, :cond_1c

    .line 509
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/angry/mod/Floater$5;

    invoke-direct {v1, p0, p1}, Lcom/angry/mod/Floater$5;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 515
    return-void

    .line 520
    :cond_1c
    :try_start_1c
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    sget-object v1, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/4 v2, 0x4

    new-array v3, v2, [I

    const/4 v4, 0x0

    aput v4, v3, v4

    sget v5, Lcom/angry/mod/Floater;->LightPurple:I

    const/4 v6, 0x1

    aput v5, v3, v6

    const/4 v7, 0x2

    aput v5, v3, v7

    const/4 v5, 0x3

    aput v4, v3, v5

    invoke-direct {v0, v1, v3}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 529
    .local v0, "gradient":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v0, v4}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 530
    const/4 v1, 0x6

    invoke-static {v1}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 532
    new-instance v1, Landroid/widget/TextView;

    sget-object v3, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v1, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 533
    .local v1, "tv":Landroid/widget/TextView;
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 534
    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 535
    const/16 v3, 0x11

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setGravity(I)V

    .line 536
    const/high16 v3, 0x41200000  # 10.0f

    invoke-virtual {v1, v7, v3}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 537
    const/4 v3, -0x1

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 538
    sget-object v4, Lcom/angry/mod/Floater;->googleSansFont:Landroid/graphics/Typeface;

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 539
    invoke-virtual {v1, v6}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 541
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    .line 542
    invoke-static {p1}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v5

    invoke-direct {v4, v3, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v3, v4

    .line 543
    .local v3, "params":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {v2}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v4

    invoke-static {v2}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v5

    .line 544
    invoke-static {v2}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v6

    invoke-static {v2}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v2

    .line 543
    invoke-virtual {v3, v4, v5, v6, v2}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 545
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 547
    sget-object v2, Lcom/angry/mod/Floater;->funcsListLayout:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_8a

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    :try_end_8a
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_8a} :catch_8b

    .line 550
    .end local v0  # "gradient":Landroid/graphics/drawable/GradientDrawable;
    .end local v1  # "tv":Landroid/widget/TextView;
    .end local v3  # "params":Landroid/widget/LinearLayout$LayoutParams;
    :cond_8a
    goto :goto_8f

    .line 548
    :catch_8b
    move-exception v0

    .line 549
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 551
    .end local v0  # "e":Ljava/lang/Exception;
    :goto_8f
    return-void
.end method

.method public static addSeekBar(Ljava/lang/String;IILjava/lang/String;I)V
    .registers 13
    .param p0, "name"  # Ljava/lang/String;
    .param p1, "value"  # I
    .param p2, "max"  # I
    .param p3, "type"  # Ljava/lang/String;
    .param p4, "ID"  # I

    .line 658
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 659
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/angry/mod/Floater$9;

    move-object v2, v1

    move-object v3, p0

    move v4, p1

    move v5, p2

    move-object v6, p3

    move v7, p4

    invoke-direct/range {v2 .. v7}, Lcom/angry/mod/Floater$9;-><init>(Ljava/lang/String;IILjava/lang/String;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 665
    return-void

    .line 669
    :cond_22
    :try_start_22
    new-instance v0, Landroid/widget/LinearLayout;

    sget-object v1, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 670
    .local v0, "layout":Landroid/widget/LinearLayout;
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    const/4 v3, -0x1

    invoke-direct {v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 673
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 674
    const/16 v4, 0xc

    invoke-static {v4}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v5

    const/16 v6, 0xa

    invoke-static {v6}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v6

    invoke-static {v4}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v4

    const/4 v7, 0x0

    invoke-virtual {v0, v5, v6, v4, v7}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 676
    new-instance v4, Landroid/widget/TextView;

    sget-object v5, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v4, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 677
    .local v4, "text":Landroid/widget/TextView;
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v5, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 680
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, ": "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 681
    const/4 v2, 0x2

    const/high16 v5, 0x41400000  # 12.0f

    invoke-virtual {v4, v2, v5}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 682
    sget v2, Lcom/angry/mod/Floater;->TextColor:I

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 683
    sget-object v2, Lcom/angry/mod/Floater;->googleSansFont:Landroid/graphics/Typeface;

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 684
    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 686
    new-instance v1, Landroid/widget/SeekBar;

    sget-object v2, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    .line 687
    .local v1, "seek":Landroid/widget/SeekBar;
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 688
    const/16 v5, 0x14

    invoke-static {v5}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v5

    invoke-direct {v2, v3, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 687
    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 689
    invoke-virtual {v1, p1}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 690
    invoke-virtual {v1, p2}, Landroid/widget/SeekBar;->setMax(I)V

    .line 692
    nop

    .line 693
    invoke-virtual {v1}, Landroid/widget/SeekBar;->getThumb()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    sget v3, Lcom/angry/mod/Floater;->LightPurple:I

    sget-object v5, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {v2, v3, v5}, Landroid/graphics/drawable/Drawable;->setColorFilter(ILandroid/graphics/PorterDuff$Mode;)V

    .line 694
    invoke-virtual {v1}, Landroid/widget/SeekBar;->getProgressDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    sget v3, Lcom/angry/mod/Floater;->LightPurple:I

    sget-object v5, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {v2, v3, v5}, Landroid/graphics/drawable/Drawable;->setColorFilter(ILandroid/graphics/PorterDuff$Mode;)V

    .line 697
    move v2, p4

    .line 698
    .local v2, "finalID":I
    move-object v3, p0

    .line 699
    .local v3, "finalName":Ljava/lang/String;
    move-object v5, p3

    .line 700
    .local v5, "finalType":Ljava/lang/String;
    new-instance v6, Lcom/angry/mod/Floater$10;

    invoke-direct {v6, v4, v3, v5, v2}, Lcom/angry/mod/Floater$10;-><init>(Landroid/widget/TextView;Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v1, v6}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 712
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 713
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 715
    sget-object v6, Lcom/angry/mod/Floater;->funcsListLayout:Landroid/widget/LinearLayout;

    if-eqz v6, :cond_d5

    invoke-virtual {v6, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    :try_end_d5
    .catch Ljava/lang/Exception; {:try_start_22 .. :try_end_d5} :catch_d6

    .line 719
    .end local v0  # "layout":Landroid/widget/LinearLayout;
    .end local v1  # "seek":Landroid/widget/SeekBar;
    .end local v2  # "finalID":I
    .end local v3  # "finalName":Ljava/lang/String;
    .end local v4  # "text":Landroid/widget/TextView;
    .end local v5  # "finalType":Ljava/lang/String;
    :cond_d5
    goto :goto_da

    .line 717
    :catch_d6
    move-exception v0

    .line 718
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 720
    .end local v0  # "e":Ljava/lang/Exception;
    :goto_da
    return-void
.end method

.method public static addSwitch(Ljava/lang/String;I)V
    .registers 3
    .param p0, "name"  # Ljava/lang/String;
    .param p1, "ID"  # I

    .line 587
    const/16 v0, 0x24

    invoke-static {p0, p1, v0}, Lcom/angry/mod/Floater;->addSwitch(Ljava/lang/String;II)V

    .line 588
    return-void
.end method

.method public static addSwitch(Ljava/lang/String;II)V
    .registers 14
    .param p0, "name"  # Ljava/lang/String;
    .param p1, "ID"  # I
    .param p2, "height"  # I

    .line 591
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    if-eq v0, v1, :cond_1c

    .line 592
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/angry/mod/Floater$7;

    invoke-direct {v1, p0, p1, p2}, Lcom/angry/mod/Floater$7;-><init>(Ljava/lang/String;II)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 598
    return-void

    .line 602
    :cond_1c
    :try_start_1c
    new-instance v0, Landroid/widget/LinearLayout;

    sget-object v1, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 603
    .local v0, "container":Landroid/widget/LinearLayout;
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 604
    invoke-static {p2}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v2

    const/4 v3, -0x1

    invoke-direct {v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 603
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 605
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 606
    const/16 v2, 0x10

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 607
    const/16 v2, 0xc

    invoke-static {v2}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v2

    const/16 v3, 0x8

    invoke-static {v3}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v3

    invoke-virtual {v0, v2, v1, v3, v1}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 609
    new-instance v2, Landroid/widget/TextView;

    sget-object v3, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v2, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 610
    .local v2, "text":Landroid/widget/TextView;
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x2

    const/high16 v5, 0x3f800000  # 1.0f

    invoke-direct {v3, v1, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 612
    .local v3, "textParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 613
    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 614
    sget v4, Lcom/angry/mod/Floater;->TextColor:I

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 615
    const/high16 v4, 0x41400000  # 12.0f

    const/4 v5, 0x2

    invoke-virtual {v2, v5, v4}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 616
    sget-object v4, Lcom/angry/mod/Floater;->googleSansFont:Landroid/graphics/Typeface;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 617
    const/4 v4, 0x1

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 619
    new-instance v6, Landroid/widget/CheckBox;

    sget-object v7, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v6, v7}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 620
    .local v6, "checkBox":Landroid/widget/CheckBox;
    const/16 v7, 0x28

    invoke-static {v7}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v7

    .line 621
    .local v7, "checkBoxSize":I
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v8, v7, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 623
    .local v8, "checkBoxParams":Landroid/widget/LinearLayout$LayoutParams;
    const v9, 0x800005

    iput v9, v8, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 624
    invoke-virtual {v6, v8}, Landroid/widget/CheckBox;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 626
    nop

    .line 627
    new-array v9, v5, [[I

    const v10, 0x10100a0

    filled-new-array {v10}, [I

    move-result-object v10

    aput-object v10, v9, v1

    new-array v10, v1, [I

    aput-object v10, v9, v4

    .line 631
    .local v9, "states":[[I
    new-array v5, v5, [I

    sget v10, Lcom/angry/mod/Floater;->LightPurple:I

    aput v10, v5, v1

    const-string v1, "#888888"

    .line 633
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    aput v1, v5, v4

    move-object v1, v5

    .line 635
    .local v1, "colors":[I
    new-instance v4, Landroid/content/res/ColorStateList;

    invoke-direct {v4, v9, v1}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    .line 636
    .local v4, "colorStateList":Landroid/content/res/ColorStateList;
    invoke-virtual {v6, v4}, Landroid/widget/CheckBox;->setButtonTintList(Landroid/content/res/ColorStateList;)V

    .line 639
    .end local v1  # "colors":[I
    .end local v4  # "colorStateList":Landroid/content/res/ColorStateList;
    .end local v9  # "states":[[I
    move v1, p1

    .line 640
    .local v1, "finalID":I
    new-instance v4, Lcom/angry/mod/Floater$8;

    invoke-direct {v4, v1}, Lcom/angry/mod/Floater$8;-><init>(I)V

    invoke-virtual {v6, v4}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 647
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 648
    invoke-virtual {v0, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 650
    sget-object v4, Lcom/angry/mod/Floater;->funcsListLayout:Landroid/widget/LinearLayout;

    if-eqz v4, :cond_c8

    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    :try_end_c8
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_c8} :catch_c9

    .line 654
    .end local v0  # "container":Landroid/widget/LinearLayout;
    .end local v1  # "finalID":I
    .end local v2  # "text":Landroid/widget/TextView;
    .end local v3  # "textParams":Landroid/widget/LinearLayout$LayoutParams;
    .end local v6  # "checkBox":Landroid/widget/CheckBox;
    .end local v7  # "checkBoxSize":I
    .end local v8  # "checkBoxParams":Landroid/widget/LinearLayout$LayoutParams;
    :cond_c8
    goto :goto_cd

    .line 652
    :catch_c9
    move-exception v0

    .line 653
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 655
    .end local v0  # "e":Ljava/lang/Exception;
    :goto_cd
    return-void
.end method

.method public static addText(Ljava/lang/String;)V
    .registers 7
    .param p0, "text"  # Ljava/lang/String;

    .line 554
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    if-eq v0, v1, :cond_1c

    .line 555
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/angry/mod/Floater$6;

    invoke-direct {v1, p0}, Lcom/angry/mod/Floater$6;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 561
    return-void

    .line 565
    :cond_1c
    :try_start_1c
    new-instance v0, Landroid/widget/TextView;

    sget-object v1, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 566
    .local v0, "tv":Landroid/widget/TextView;
    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 567
    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 568
    const/16 v1, 0xc

    invoke-static {v1}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v2

    const/16 v3, 0xa

    invoke-static {v3}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v4

    invoke-static {v1}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v1

    invoke-static {v3}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v3

    invoke-virtual {v0, v2, v4, v1, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 569
    const/high16 v1, 0x41400000  # 12.0f

    const/4 v2, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 570
    sget v1, Lcom/angry/mod/Floater;->TextColor:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 571
    sget-object v1, Lcom/angry/mod/Floater;->googleSansFont:Landroid/graphics/Typeface;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 573
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x2

    invoke-direct {v1, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 576
    .local v1, "params":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v3, 0x4

    invoke-static {v3}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v4

    invoke-static {v2}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v5

    .line 577
    invoke-static {v3}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v3

    invoke-static {v2}, Lcom/angry/mod/Floater;->convertDPStatic(I)I

    move-result v2

    .line 576
    invoke-virtual {v1, v4, v5, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 578
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 580
    sget-object v2, Lcom/angry/mod/Floater;->funcsListLayout:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_77

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    :try_end_77
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_77} :catch_78

    .line 583
    .end local v0  # "tv":Landroid/widget/TextView;
    .end local v1  # "params":Landroid/widget/LinearLayout$LayoutParams;
    :cond_77
    goto :goto_7c

    .line 581
    :catch_78
    move-exception v0

    .line 582
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 584
    .end local v0  # "e":Ljava/lang/Exception;
    :goto_7c
    return-void
.end method

.method private convertDP(I)I
    .registers 5
    .param p1, "value"  # I

    .line 108
    int-to-float v0, p1

    sget-object v1, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    .line 109
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    .line 108
    const/4 v2, 0x1

    invoke-static {v2, v0, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    float-to-int v0, v0

    return v0
.end method

.method private static convertDPStatic(I)I
    .registers 4
    .param p0, "value"  # I

    .line 113
    int-to-float v0, p0

    sget-object v1, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    .line 114
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    .line 113
    const/4 v2, 0x1

    invoke-static {v2, v0, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    float-to-int v0, v0

    return v0
.end method

.method private createCircularImageView(Ljava/lang/String;I)Landroid/widget/ImageView;
    .registers 7
    .param p1, "base64Icon"  # Ljava/lang/String;
    .param p2, "size"  # I

    .line 138
    new-instance v0, Landroid/widget/ImageView;

    sget-object v1, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 139
    .local v0, "imageView":Landroid/widget/ImageView;
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, p2, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 142
    if-eqz p1, :cond_2f

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2f

    .line 143
    const/4 v1, 0x0

    invoke-static {p1, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v2

    .line 144
    .local v2, "decodedBytes":[B
    array-length v3, v2

    invoke-static {v2, v1, v3}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 145
    .local v1, "bitmap":Landroid/graphics/Bitmap;
    if-nez v1, :cond_2e

    .line 146
    sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p2, p2, v3}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 147
    sget v3, Lcom/angry/mod/Floater;->LightPurple:I

    invoke-virtual {v1, v3}, Landroid/graphics/Bitmap;->eraseColor(I)V

    .line 149
    .end local v2  # "decodedBytes":[B
    :cond_2e
    goto :goto_3a

    .line 150
    .end local v1  # "bitmap":Landroid/graphics/Bitmap;
    :cond_2f
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p2, p2, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 151
    .restart local v1  # "bitmap":Landroid/graphics/Bitmap;
    sget v2, Lcom/angry/mod/Floater;->LightPurple:I

    invoke-virtual {v1, v2}, Landroid/graphics/Bitmap;->eraseColor(I)V

    .line 154
    :goto_3a
    const/4 v2, 0x1

    invoke-static {v1, p2, p2, v2}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 155
    .local v2, "squaredBitmap":Landroid/graphics/Bitmap;
    invoke-direct {p0, v2}, Lcom/angry/mod/Floater;->getCircularBitmap(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 157
    nop

    .line 158
    const/4 v3, 0x6

    invoke-direct {p0, v3}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setElevation(F)V

    .line 161
    return-object v0
.end method

.method private createOnTouchListener()Landroid/view/View$OnTouchListener;
    .registers 2

    .line 428
    new-instance v0, Lcom/angry/mod/Floater$4;

    invoke-direct {v0, p0}, Lcom/angry/mod/Floater$4;-><init>(Lcom/angry/mod/Floater;)V

    return-object v0
.end method

.method public static native ftKZXivSr(Landroid/content/Context;)V
.end method

.method public static native getBase64Icon()Ljava/lang/String;
.end method

.method private getCircularBitmap(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    .registers 9
    .param p1, "bitmap"  # Landroid/graphics/Bitmap;

    .line 125
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    .line 126
    .local v0, "size":I
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v0, v0, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 127
    .local v1, "output":Landroid/graphics/Bitmap;
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 128
    .local v2, "canvas":Landroid/graphics/Canvas;
    new-instance v3, Landroid/graphics/Paint;

    invoke-direct {v3}, Landroid/graphics/Paint;-><init>()V

    .line 129
    .local v3, "paint":Landroid/graphics/Paint;
    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 130
    const/4 v4, -0x1

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 131
    div-int/lit8 v4, v0, 0x2

    int-to-float v4, v4

    div-int/lit8 v5, v0, 0x2

    int-to-float v5, v5

    div-int/lit8 v6, v0, 0x2

    int-to-float v6, v6

    invoke-virtual {v2, v4, v5, v6, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 132
    new-instance v4, Landroid/graphics/PorterDuffXfermode;

    sget-object v5, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v4, v5}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    .line 133
    const/4 v4, 0x0

    invoke-virtual {v2, p1, v4, v4, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 134
    return-object v1
.end method

.method private getLayoutType()I
    .registers 3

    .line 118
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_9

    const/16 v0, 0x7f6

    return v0

    .line 119
    :cond_9
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    if-lt v0, v1, :cond_12

    const/16 v0, 0x7d2

    return v0

    .line 120
    :cond_12
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_1b

    const/16 v0, 0x7d5

    return v0

    .line 121
    :cond_1b
    const/16 v0, 0x7d3

    return v0
.end method

.method public static native isLoggedIn()Z
.end method


# virtual methods
.method public onCreate()V
    .registers 1

    .line 423
    invoke-virtual {p0}, Lcom/angry/mod/Floater;->onCreateSystemWindow()V

    .line 424
    invoke-virtual {p0}, Lcom/angry/mod/Floater;->onCreateTemplate()V

    .line 425
    return-void
.end method

.method public onCreateSystemWindow()V
    .registers 12

    .line 167
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_9

    .line 168
    const/16 v0, 0x7f6

    .local v0, "LAYOUT_FLAG":I
    goto :goto_b

    .line 170
    .end local v0  # "LAYOUT_FLAG":I
    :cond_9
    const/16 v0, 0x7d2

    .line 173
    .restart local v0  # "LAYOUT_FLAG":I
    :goto_b
    new-instance v7, Landroid/view/WindowManager$LayoutParams;

    const/4 v2, -0x2

    const/4 v3, -0x2

    const/16 v5, 0x8

    const/4 v6, -0x3

    move-object v1, v7

    move v4, v0

    invoke-direct/range {v1 .. v6}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    iput-object v7, p0, Lcom/angry/mod/Floater;->windowManagerParams:Landroid/view/WindowManager$LayoutParams;

    .line 179
    const/16 v1, 0x33

    iput v1, v7, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 180
    iget-object v1, p0, Lcom/angry/mod/Floater;->windowManagerParams:Landroid/view/WindowManager$LayoutParams;

    const/4 v7, 0x0

    iput v7, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 181
    iget-object v1, p0, Lcom/angry/mod/Floater;->windowManagerParams:Landroid/view/WindowManager$LayoutParams;

    const/16 v2, 0x64

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 183
    sget-object v1, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    const-string v2, "window"

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/WindowManager;

    iput-object v1, p0, Lcom/angry/mod/Floater;->windowManager:Landroid/view/WindowManager;

    .line 185
    new-instance v1, Landroid/graphics/Point;

    invoke-direct {v1}, Landroid/graphics/Point;-><init>()V

    move-object v8, v1

    .line 186
    .local v8, "size":Landroid/graphics/Point;
    nop

    .line 187
    iget-object v1, p0, Lcom/angry/mod/Floater;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v1

    invoke-virtual {v1, v8}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    .line 191
    iget v1, v8, Landroid/graphics/Point;->x:I

    sput v1, Lcom/angry/mod/Floater;->SCREEN_WIDTH:I

    .line 192
    iget v1, v8, Landroid/graphics/Point;->y:I

    sput v1, Lcom/angry/mod/Floater;->SCREEN_HEIGHT:I

    .line 194
    new-instance v1, Lcom/angry/mod/ESPView;

    sget-object v2, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v1, v2}, Lcom/angry/mod/ESPView;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lcom/angry/mod/Floater;->drawView:Lcom/angry/mod/ESPView;

    .line 196
    const/16 v9, 0x518

    .line 201
    .local v9, "flags":I
    new-instance v10, Landroid/view/WindowManager$LayoutParams;

    const/4 v2, -0x1

    const/4 v3, -0x1

    const/4 v6, -0x3

    move-object v1, v10

    move v4, v0

    move v5, v9

    invoke-direct/range {v1 .. v6}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    iput-object v10, p0, Lcom/angry/mod/Floater;->windowManagerDrawViewParams:Landroid/view/WindowManager$LayoutParams;

    .line 208
    const v1, 0x800033

    iput v1, v10, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 209
    iget-object v1, p0, Lcom/angry/mod/Floater;->windowManagerDrawViewParams:Landroid/view/WindowManager$LayoutParams;

    iput v7, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 210
    iget-object v1, p0, Lcom/angry/mod/Floater;->windowManagerDrawViewParams:Landroid/view/WindowManager$LayoutParams;

    iput v7, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 211
    iget-object v1, p0, Lcom/angry/mod/Floater;->windowManagerDrawViewParams:Landroid/view/WindowManager$LayoutParams;

    const v2, 0x3f4ccccd  # 0.8f

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->alpha:F

    .line 213
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1c

    if-lt v1, v2, :cond_83

    .line 214
    iget-object v1, p0, Lcom/angry/mod/Floater;->windowManagerDrawViewParams:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x1

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->layoutInDisplayCutoutMode:I

    .line 218
    :cond_83
    iget-object v1, p0, Lcom/angry/mod/Floater;->windowManager:Landroid/view/WindowManager;

    iget-object v2, p0, Lcom/angry/mod/Floater;->drawView:Lcom/angry/mod/ESPView;

    iget-object v3, p0, Lcom/angry/mod/Floater;->windowManagerDrawViewParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v1, v2, v3}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 219
    return-void
.end method

.method public onCreateTemplate()V
    .registers 19

    .line 223
    move-object/from16 v0, p0

    new-instance v1, Landroid/widget/FrameLayout;

    sget-object v2, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v1, v0, Lcom/angry/mod/Floater;->rootFrame:Landroid/widget/FrameLayout;

    .line 224
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x2

    invoke-direct {v2, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 228
    new-instance v1, Landroid/widget/RelativeLayout;

    sget-object v2, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    iput-object v1, v0, Lcom/angry/mod/Floater;->rootRelative:Landroid/widget/RelativeLayout;

    .line 229
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2}, Landroid/widget/RelativeLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 233
    new-instance v1, Landroid/widget/RelativeLayout;

    sget-object v2, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    iput-object v1, v0, Lcom/angry/mod/Floater;->collapsedRelative:Landroid/widget/RelativeLayout;

    .line 234
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2}, Landroid/widget/RelativeLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 237
    iget-object v1, v0, Lcom/angry/mod/Floater;->collapsedRelative:Landroid/widget/RelativeLayout;

    const v2, 0x3f733333  # 0.95f

    invoke-virtual {v1, v2}, Landroid/widget/RelativeLayout;->setAlpha(F)V

    .line 238
    iget-object v1, v0, Lcom/angry/mod/Floater;->collapsedRelative:Landroid/widget/RelativeLayout;

    const/4 v4, 0x0

    invoke-virtual {v1, v4}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 240
    invoke-static {}, Lcom/angry/mod/Floater;->getBase64Icon()Ljava/lang/String;

    move-result-object v1

    const/16 v5, 0x34

    invoke-direct {v0, v5}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v5

    invoke-direct {v0, v1, v5}, Lcom/angry/mod/Floater;->createCircularImageView(Ljava/lang/String;I)Landroid/widget/ImageView;

    move-result-object v1

    iput-object v1, v0, Lcom/angry/mod/Floater;->logoImagem:Landroid/widget/ImageView;

    .line 242
    new-instance v1, Landroid/widget/LinearLayout;

    sget-object v5, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v1, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v1, v0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    .line 243
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 244
    const/16 v6, 0xc8

    invoke-direct {v0, v6}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v6

    invoke-direct {v5, v6, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 243
    invoke-virtual {v1, v5}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 246
    iget-object v1, v0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    const/16 v5, 0x8

    invoke-virtual {v1, v5}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 247
    iget-object v1, v0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setAlpha(F)V

    .line 248
    iget-object v1, v0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 250
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 251
    .local v1, "menuBackground":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v1, v4}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 252
    sget v6, Lcom/angry/mod/Floater;->DarkBackground:I

    invoke-virtual {v1, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 253
    const/16 v6, 0xc

    invoke-direct {v0, v6}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v1, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 254
    iget-object v7, v0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v7, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 256
    nop

    .line 257
    iget-object v7, v0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    invoke-direct {v0, v5}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v8

    int-to-float v8, v8

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setElevation(F)V

    .line 260
    new-instance v7, Landroid/widget/LinearLayout;

    sget-object v8, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v7, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v7, v0, Lcom/angry/mod/Floater;->tabCima:Landroid/widget/LinearLayout;

    .line 261
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 263
    const/16 v9, 0x23

    invoke-direct {v0, v9}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v10

    const/4 v11, -0x1

    invoke-direct {v8, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 261
    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 265
    new-instance v7, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v7}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 266
    .local v7, "topTabBg":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v7, v4}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 267
    sget v8, Lcom/angry/mod/Floater;->LightPurple:I

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 268
    new-array v8, v5, [F

    .line 269
    invoke-direct {v0, v6}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v10

    int-to-float v10, v10

    aput v10, v8, v4

    invoke-direct {v0, v6}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v10

    int-to-float v10, v10

    aput v10, v8, v2

    invoke-direct {v0, v6}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v10

    int-to-float v10, v10

    const/4 v12, 0x2

    aput v10, v8, v12

    invoke-direct {v0, v6}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v10

    int-to-float v10, v10

    const/4 v13, 0x3

    aput v10, v8, v13

    const/4 v10, 0x4

    const/4 v14, 0x0

    aput v14, v8, v10

    const/4 v15, 0x5

    aput v14, v8, v15

    const/16 v16, 0x6

    aput v14, v8, v16

    const/16 v17, 0x7

    aput v14, v8, v17

    .line 268
    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 271
    iget-object v8, v0, Lcom/angry/mod/Floater;->tabCima:Landroid/widget/LinearLayout;

    invoke-virtual {v8, v7}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 273
    new-instance v8, Landroid/widget/RelativeLayout;

    sget-object v15, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v8, v15}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    iput-object v8, v0, Lcom/angry/mod/Floater;->tabCimaRelative:Landroid/widget/RelativeLayout;

    .line 274
    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    .line 276
    invoke-direct {v0, v9}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v10

    invoke-direct {v15, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 274
    invoke-virtual {v8, v15}, Landroid/widget/RelativeLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 277
    iget-object v8, v0, Lcom/angry/mod/Floater;->tabCimaRelative:Landroid/widget/RelativeLayout;

    const/16 v10, 0x11

    invoke-virtual {v8, v10}, Landroid/widget/RelativeLayout;->setGravity(I)V

    .line 279
    new-instance v8, Landroid/widget/TextView;

    sget-object v15, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v8, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v8, v0, Lcom/angry/mod/Floater;->tituloText:Landroid/widget/TextView;

    .line 280
    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    .line 282
    invoke-direct {v0, v9}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v6

    invoke-direct {v15, v3, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 280
    invoke-virtual {v8, v15}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 283
    iget-object v6, v0, Lcom/angry/mod/Floater;->tituloText:Landroid/widget/TextView;

    const-string v8, "ANGRY MOD"

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 284
    iget-object v6, v0, Lcom/angry/mod/Floater;->tituloText:Landroid/widget/TextView;

    invoke-virtual {v6, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 285
    iget-object v6, v0, Lcom/angry/mod/Floater;->tituloText:Landroid/widget/TextView;

    sget-object v8, Lcom/angry/mod/Floater;->googleSansFont:Landroid/graphics/Typeface;

    invoke-static {v8, v2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v8

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 286
    iget-object v6, v0, Lcom/angry/mod/Floater;->tituloText:Landroid/widget/TextView;

    const/high16 v8, 0x41700000  # 15.0f

    invoke-virtual {v6, v12, v8}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 287
    iget-object v6, v0, Lcom/angry/mod/Floater;->tituloText:Landroid/widget/TextView;

    invoke-virtual {v6, v10}, Landroid/widget/TextView;->setGravity(I)V

    .line 288
    iget-object v6, v0, Lcom/angry/mod/Floater;->tituloText:Landroid/widget/TextView;

    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 290
    new-instance v6, Landroid/widget/ScrollView;

    sget-object v8, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v6, v8}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    iput-object v6, v0, Lcom/angry/mod/Floater;->funcsList:Landroid/widget/ScrollView;

    .line 291
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 293
    const/16 v15, 0xbe

    invoke-direct {v0, v15}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v15

    invoke-direct {v8, v11, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 291
    invoke-virtual {v6, v8}, Landroid/widget/ScrollView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 294
    iget-object v6, v0, Lcom/angry/mod/Floater;->funcsList:Landroid/widget/ScrollView;

    invoke-virtual {v6, v2}, Landroid/widget/ScrollView;->setVerticalScrollBarEnabled(Z)V

    .line 295
    iget-object v6, v0, Lcom/angry/mod/Floater;->funcsList:Landroid/widget/ScrollView;

    invoke-virtual {v6, v4}, Landroid/widget/ScrollView;->setBackgroundColor(I)V

    .line 297
    new-instance v6, Landroid/widget/LinearLayout;

    sget-object v8, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v6, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    sput-object v6, Lcom/angry/mod/Floater;->funcsListLayout:Landroid/widget/LinearLayout;

    .line 298
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v8, v11, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v8}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 301
    sget-object v3, Lcom/angry/mod/Floater;->funcsListLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 302
    sget-object v3, Lcom/angry/mod/Floater;->funcsListLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 304
    new-instance v3, Landroid/widget/LinearLayout;

    sget-object v6, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v3, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v3, v0, Lcom/angry/mod/Floater;->tabBaixo:Landroid/widget/LinearLayout;

    .line 305
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 307
    invoke-direct {v0, v9}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v8

    invoke-direct {v6, v11, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 305
    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 309
    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 310
    .local v3, "bottomTabBg":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 311
    new-array v6, v5, [F

    aput v14, v6, v4

    aput v14, v6, v2

    aput v14, v6, v12

    aput v14, v6, v13

    .line 312
    const/16 v2, 0xc

    invoke-direct {v0, v2}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v8

    int-to-float v8, v8

    const/4 v14, 0x4

    aput v8, v6, v14

    invoke-direct {v0, v2}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v8

    int-to-float v8, v8

    const/4 v14, 0x5

    aput v8, v6, v14

    invoke-direct {v0, v2}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v8

    int-to-float v8, v8

    aput v8, v6, v16

    invoke-direct {v0, v2}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v2

    int-to-float v2, v2

    aput v2, v6, v17

    .line 311
    invoke-virtual {v3, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 314
    sget v2, Lcom/angry/mod/Floater;->LightPurple:I

    invoke-virtual {v3, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 315
    iget-object v2, v0, Lcom/angry/mod/Floater;->tabBaixo:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 317
    new-instance v2, Landroid/widget/RelativeLayout;

    sget-object v6, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v2, v6}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    iput-object v2, v0, Lcom/angry/mod/Floater;->tabBaixoRelative:Landroid/widget/RelativeLayout;

    .line 318
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 320
    invoke-direct {v0, v9}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v8

    invoke-direct {v6, v11, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 318
    invoke-virtual {v2, v6}, Landroid/widget/RelativeLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 322
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 323
    .local v2, "buttonBg":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v2, v4}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 324
    invoke-direct {v0, v5}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v2, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 325
    sget v6, Lcom/angry/mod/Floater;->LightPurple:I

    invoke-virtual {v2, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 327
    new-instance v6, Landroid/widget/Button;

    sget-object v8, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v6, v8}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    iput-object v6, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    .line 328
    new-instance v6, Landroid/widget/RelativeLayout$LayoutParams;

    .line 329
    const/16 v8, 0x50

    invoke-direct {v0, v8}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v9

    .line 330
    const/16 v14, 0x1c

    invoke-direct {v0, v14}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v15

    invoke-direct {v6, v9, v15}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    .line 331
    .local v6, "injectBtnParams":Landroid/widget/RelativeLayout$LayoutParams;
    const/16 v9, 0xb

    invoke-virtual {v6, v9}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 332
    invoke-direct {v0, v5}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v15

    iput v15, v6, Landroid/widget/RelativeLayout$LayoutParams;->rightMargin:I

    .line 333
    invoke-direct {v0, v13}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v15

    iput v15, v6, Landroid/widget/RelativeLayout$LayoutParams;->topMargin:I

    .line 334
    iget-object v15, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    invoke-virtual {v15, v6}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 335
    iget-object v15, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    const-string v13, "INJECT"

    invoke-virtual {v15, v13}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 336
    iget-object v13, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    invoke-virtual {v13, v11}, Landroid/widget/Button;->setTextColor(I)V

    .line 337
    iget-object v13, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    const/high16 v15, 0x41200000  # 10.0f

    invoke-virtual {v13, v12, v15}, Landroid/widget/Button;->setTextSize(IF)V

    .line 338
    iget-object v13, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    sget-object v12, Lcom/angry/mod/Floater;->googleSansFont:Landroid/graphics/Typeface;

    invoke-virtual {v13, v12}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    .line 339
    iget-object v12, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    invoke-virtual {v12, v2}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 340
    iget-object v12, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    invoke-virtual {v12, v4}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 341
    iget-object v12, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    invoke-virtual {v12, v4, v4, v4, v4}, Landroid/widget/Button;->setPadding(IIII)V

    .line 342
    iget-object v12, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    invoke-virtual {v12, v4}, Landroid/widget/Button;->setIncludeFontPadding(Z)V

    .line 343
    iget-object v12, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    invoke-virtual {v12, v10}, Landroid/widget/Button;->setGravity(I)V

    .line 345
    new-instance v12, Landroid/widget/Button;

    sget-object v13, Lcom/angry/mod/Floater;->context:Landroid/content/Context;

    invoke-direct {v12, v13}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    iput-object v12, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    .line 346
    new-instance v12, Landroid/widget/RelativeLayout$LayoutParams;

    .line 347
    invoke-direct {v0, v8}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v8

    .line 348
    invoke-direct {v0, v14}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v13

    invoke-direct {v12, v8, v13}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    move-object v8, v12

    .line 349
    .local v8, "closeBtnParams":Landroid/widget/RelativeLayout$LayoutParams;
    invoke-virtual {v8, v9}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 350
    invoke-direct {v0, v5}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v9

    iput v9, v8, Landroid/widget/RelativeLayout$LayoutParams;->rightMargin:I

    .line 351
    const/4 v9, 0x3

    invoke-direct {v0, v9}, Lcom/angry/mod/Floater;->convertDP(I)I

    move-result v9

    iput v9, v8, Landroid/widget/RelativeLayout$LayoutParams;->topMargin:I

    .line 352
    iget-object v9, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    invoke-virtual {v9, v8}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 353
    iget-object v9, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    const-string v12, "CLOSE"

    invoke-virtual {v9, v12}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 354
    iget-object v9, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    invoke-virtual {v9, v11}, Landroid/widget/Button;->setTextColor(I)V

    .line 355
    iget-object v9, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    const/4 v11, 0x2

    invoke-virtual {v9, v11, v15}, Landroid/widget/Button;->setTextSize(IF)V

    .line 356
    iget-object v9, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    sget-object v11, Lcom/angry/mod/Floater;->googleSansFont:Landroid/graphics/Typeface;

    invoke-virtual {v9, v11}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    .line 357
    iget-object v9, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    invoke-virtual {v9, v2}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 358
    iget-object v9, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    invoke-virtual {v9, v4}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 359
    iget-object v9, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    invoke-virtual {v9, v4, v4, v4, v4}, Landroid/widget/Button;->setPadding(IIII)V

    .line 360
    iget-object v9, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    invoke-virtual {v9, v4}, Landroid/widget/Button;->setIncludeFontPadding(Z)V

    .line 361
    iget-object v4, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    invoke-virtual {v4, v10}, Landroid/widget/Button;->setGravity(I)V

    .line 362
    iget-object v4, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 364
    iget-object v4, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    new-instance v5, Lcom/angry/mod/Floater$1;

    invoke-direct {v5, v0}, Lcom/angry/mod/Floater$1;-><init>(Lcom/angry/mod/Floater;)V

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 377
    iget-object v4, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    new-instance v5, Lcom/angry/mod/Floater$2;

    invoke-direct {v5, v0}, Lcom/angry/mod/Floater$2;-><init>(Lcom/angry/mod/Floater;)V

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 385
    iget-object v4, v0, Lcom/angry/mod/Floater;->tabBaixoRelative:Landroid/widget/RelativeLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->injectButton:Landroid/widget/Button;

    invoke-virtual {v4, v5}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    .line 386
    iget-object v4, v0, Lcom/angry/mod/Floater;->tabBaixoRelative:Landroid/widget/RelativeLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->closeButton:Landroid/widget/Button;

    invoke-virtual {v4, v5}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    .line 387
    iget-object v4, v0, Lcom/angry/mod/Floater;->tabBaixo:Landroid/widget/LinearLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->tabBaixoRelative:Landroid/widget/RelativeLayout;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 389
    iget-object v4, v0, Lcom/angry/mod/Floater;->rootFrame:Landroid/widget/FrameLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->rootRelative:Landroid/widget/RelativeLayout;

    invoke-virtual {v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 390
    iget-object v4, v0, Lcom/angry/mod/Floater;->rootRelative:Landroid/widget/RelativeLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->collapsedRelative:Landroid/widget/RelativeLayout;

    invoke-virtual {v4, v5}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    .line 391
    iget-object v4, v0, Lcom/angry/mod/Floater;->collapsedRelative:Landroid/widget/RelativeLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->logoImagem:Landroid/widget/ImageView;

    invoke-virtual {v4, v5}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    .line 392
    iget-object v4, v0, Lcom/angry/mod/Floater;->rootRelative:Landroid/widget/RelativeLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v5}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    .line 394
    iget-object v4, v0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->tabCima:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 395
    iget-object v4, v0, Lcom/angry/mod/Floater;->tabCima:Landroid/widget/LinearLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->tabCimaRelative:Landroid/widget/RelativeLayout;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 396
    iget-object v4, v0, Lcom/angry/mod/Floater;->tabCimaRelative:Landroid/widget/RelativeLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->tituloText:Landroid/widget/TextView;

    invoke-virtual {v4, v5}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    .line 397
    iget-object v4, v0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->funcsList:Landroid/widget/ScrollView;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 398
    iget-object v4, v0, Lcom/angry/mod/Floater;->funcsList:Landroid/widget/ScrollView;

    sget-object v5, Lcom/angry/mod/Floater;->funcsListLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v5}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 399
    iget-object v4, v0, Lcom/angry/mod/Floater;->menuLayout:Landroid/widget/LinearLayout;

    iget-object v5, v0, Lcom/angry/mod/Floater;->tabBaixo:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 401
    iget-object v4, v0, Lcom/angry/mod/Floater;->windowManager:Landroid/view/WindowManager;

    iget-object v5, v0, Lcom/angry/mod/Floater;->rootFrame:Landroid/widget/FrameLayout;

    iget-object v9, v0, Lcom/angry/mod/Floater;->windowManagerParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v4, v5, v9}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 403
    iget-object v4, v0, Lcom/angry/mod/Floater;->rootFrame:Landroid/widget/FrameLayout;

    invoke-direct/range {p0 .. p0}, Lcom/angry/mod/Floater;->createOnTouchListener()Landroid/view/View$OnTouchListener;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/FrameLayout;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 404
    iget-object v4, v0, Lcom/angry/mod/Floater;->logoImagem:Landroid/widget/ImageView;

    invoke-direct/range {p0 .. p0}, Lcom/angry/mod/Floater;->createOnTouchListener()Landroid/view/View$OnTouchListener;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 406
    iget-object v4, v0, Lcom/angry/mod/Floater;->logoImagem:Landroid/widget/ImageView;

    new-instance v5, Lcom/angry/mod/Floater$3;

    invoke-direct {v5, v0}, Lcom/angry/mod/Floater$3;-><init>(Lcom/angry/mod/Floater;)V

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 420
    return-void
.end method
