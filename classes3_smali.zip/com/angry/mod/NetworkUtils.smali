.class public Lcom/angry/mod/NetworkUtils;
.super Ljava/lang/Object;
.source "NetworkUtils.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static checkVPNByCapabilities(Landroid/content/Context;)Z
    .registers 10
    .param p0, "context"  # Landroid/content/Context;

    .line 21
    const/4 v0, 0x0

    :try_start_1
    const-string v1, "connectivity"

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/ConnectivityManager;

    .line 22
    .local v1, "cm":Landroid/net/ConnectivityManager;
    if-nez v1, :cond_c

    return v0

    .line 24
    :cond_c
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x17

    const/4 v4, 0x4

    if-lt v2, v3, :cond_26

    .line 25
    invoke-virtual {v1}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v2

    .line 26
    .local v2, "activeNetwork":Landroid/net/Network;
    if-nez v2, :cond_1a

    return v0

    .line 28
    :cond_1a
    invoke-virtual {v1, v2}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v3

    .line 29
    .local v3, "caps":Landroid/net/NetworkCapabilities;
    if-nez v3, :cond_21

    return v0

    .line 31
    :cond_21
    invoke-virtual {v3, v4}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v0

    return v0

    .line 34
    .end local v2  # "activeNetwork":Landroid/net/Network;
    .end local v3  # "caps":Landroid/net/NetworkCapabilities;
    :cond_26
    nop

    .line 35
    invoke-virtual {v1}, Landroid/net/ConnectivityManager;->getAllNetworks()[Landroid/net/Network;

    move-result-object v2

    .line 36
    .local v2, "networks":[Landroid/net/Network;
    array-length v3, v2

    const/4 v5, 0x0

    :goto_2d
    if-ge v5, v3, :cond_43

    aget-object v6, v2, v5

    .line 37
    .local v6, "network":Landroid/net/Network;
    invoke-virtual {v1, v6}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v7

    .line 38
    .local v7, "caps":Landroid/net/NetworkCapabilities;
    if-eqz v7, :cond_3f

    invoke-virtual {v7, v4}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v8
    :try_end_3b
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_3b} :catch_42

    if-eqz v8, :cond_3f

    .line 39
    const/4 v0, 0x1

    return v0

    .line 36
    .end local v6  # "network":Landroid/net/Network;
    .end local v7  # "caps":Landroid/net/NetworkCapabilities;
    :cond_3f
    add-int/lit8 v5, v5, 0x1

    goto :goto_2d

    .line 43
    .end local v1  # "cm":Landroid/net/ConnectivityManager;
    .end local v2  # "networks":[Landroid/net/Network;
    :catch_42
    move-exception v1

    :cond_43
    nop

    .line 44
    return v0
.end method

.method private static checkVPNByInterfaceName()Z
    .registers 5

    .line 49
    :try_start_0
    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    move-result-object v0

    .line 50
    .local v0, "interfaces":Ljava/util/Enumeration;, "Ljava/util/Enumeration<Ljava/net/NetworkInterface;>;"
    :goto_4
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_66

    .line 51
    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/net/NetworkInterface;

    .line 52
    .local v1, "iface":Ljava/net/NetworkInterface;
    invoke-virtual {v1}, Ljava/net/NetworkInterface;->isUp()Z

    move-result v2

    if-eqz v2, :cond_65

    invoke-virtual {v1}, Ljava/net/NetworkInterface;->isLoopback()Z

    move-result v2

    if-nez v2, :cond_65

    .line 53
    invoke-virtual {v1}, Ljava/net/NetworkInterface;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    .line 54
    .local v2, "name":Ljava/lang/String;
    const-string v3, "tun0"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_63

    const-string v3, "tun1"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_63

    const-string v3, "tun2"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_63

    const-string v3, "tap0"

    .line 55
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_63

    const-string v3, "ppp0"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_63

    const-string v3, "wg0"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_63

    const-string v3, "tun"

    .line 56
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_65

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3
    :try_end_60
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_60} :catch_67

    const/4 v4, 0x5

    if-gt v3, v4, :cond_65

    .line 57
    :cond_63
    const/4 v3, 0x1

    return v3

    .line 60
    .end local v1  # "iface":Ljava/net/NetworkInterface;
    .end local v2  # "name":Ljava/lang/String;
    :cond_65
    goto :goto_4

    .line 50
    .end local v0  # "interfaces":Ljava/util/Enumeration;, "Ljava/util/Enumeration<Ljava/net/NetworkInterface;>;"
    :cond_66
    goto :goto_68

    .line 61
    :catch_67
    move-exception v0

    :goto_68
    nop

    .line 62
    const/4 v0, 0x0

    return v0
.end method

.method public static isVPNConnected(Landroid/content/Context;)Z
    .registers 2
    .param p0, "context"  # Landroid/content/Context;

    .line 16
    invoke-static {p0}, Lcom/angry/mod/NetworkUtils;->checkVPNByCapabilities(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_f

    invoke-static {}, Lcom/angry/mod/NetworkUtils;->checkVPNByInterfaceName()Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_f

    :cond_d
    const/4 v0, 0x0

    goto :goto_10

    :cond_f
    :goto_f
    const/4 v0, 0x1

    :goto_10
    return v0
.end method
