.class Lcom/angry/mod/Floater$8;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater;->addSwitch(Ljava/lang/String;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$finalID:I


# direct methods
.method constructor <init>(I)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 640
    iput p1, p0, Lcom/angry/mod/Floater$8;->val$finalID:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .registers 4
    .param p1, "buttonView"  # Landroid/widget/CompoundButton;
    .param p2, "isChecked"  # Z

    .line 643
    iget v0, p0, Lcom/angry/mod/Floater$8;->val$finalID:I

    invoke-static {v0, p2}, Lcom/angry/mod/Floater;->ChangesID(II)V

    .line 644
    return-void
.end method
