.class public Lcom/angry/mod/LoginActivity;
.super Ljava/lang/Object;
.source "LoginActivity.java"


# static fields
.field private static final USER_ICON_BASE64:Ljava/lang/String; = "iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABTUlEQVRIS73UISxFcRTH8Y8oSUZgYyNJxmY2KhNEGpEmkT2ZpBFpRMGobGZjksTGRmCSJLK/vWvP8+7//nE58e6c8/2f3/md2yQt5jCC0Wr6EY6xWVTeVJSAMwzk5J1jMNajCLCDqYJH7GI6LycGmMFWwoQhZRbbjXJjgJTXZz1zp4gB7tCROME9Or87wQ26EgG36P4uIOgf9pASQf+why8Rkyh4fyOlO+bzbqLIprEbyNjRWygChCYxN0VvIBSnAEJe2MUkhqvPPsFenvdrZU0FJK4ifcmt6EM/WrCP07ryIUzgGRe4xFM9otEEwTnBQfXxgqvqx140N8gJf9fgqI+oB7z+WIvPhR99awGLWC0JsIS1Whe14aGk5lmbdjxmE4zhoGTAOA4zQJnyZO98lykDVLBc8gQrqPwb4M+XHNQJV7mOnl9KdY2F6vV7A9ESNhl4JmGYAAAAAElFTkSuQmCC"

.field private static appContext:Landroid/content/Context;

.field private static container:Landroid/widget/FrameLayout;

.field private static dotIndex:I

.field private static googleSansFont:Landroid/graphics/Typeface;

.field private static isLoading:Z

.field private static loadingHandler:Landroid/os/Handler;

.field private static loadingRunnable:Ljava/lang/Runnable;

.field private static loginButton:Landroid/widget/Button;

.field private static statusTextView:Landroid/widget/TextView;

.field private static usuarioImagem:Landroid/widget/ImageView;


# instance fields
.field private data_username:Ljava/lang/String;

.field private etUser:Landroid/widget/EditText;

.field private sharedPreferences:Landroid/content/SharedPreferences;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 31
    const-string v0, "Utility"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 45
    const/4 v0, 0x0

    sput v0, Lcom/angry/mod/LoginActivity;->dotIndex:I

    .line 46
    sput-boolean v0, Lcom/angry/mod/LoginActivity;->isLoading:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 6
    .param p1, "context"  # Landroid/content/Context;

    .line 53
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 54
    sput-object p1, Lcom/angry/mod/LoginActivity;->appContext:Landroid/content/Context;

    .line 57
    :try_start_5
    invoke-virtual {p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v1, "fonts/GoogleSans-Regular.ttf"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lcom/angry/mod/LoginActivity;->googleSansFont:Landroid/graphics/Typeface;
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_11} :catch_12

    .line 60
    goto :goto_17

    .line 58
    :catch_12
    move-exception v0

    .line 59
    .local v0, "e":Ljava/lang/Exception;
    sget-object v1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    sput-object v1, Lcom/angry/mod/LoginActivity;->googleSansFont:Landroid/graphics/Typeface;

    .line 62
    .end local v0  # "e":Ljava/lang/Exception;
    :goto_17
    move-object v0, p1

    check-cast v0, Landroid/app/Activity;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 63
    move-object v0, p1

    check-cast v0, Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v2, 0x400

    invoke-virtual {v0, v2}, Landroid/view/Window;->addFlags(I)V

    .line 65
    const-string v0, "LoginPrefs"

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, Lcom/angry/mod/LoginActivity;->sharedPreferences:Landroid/content/SharedPreferences;

    .line 66
    const-string v1, "username"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/angry/mod/LoginActivity;->data_username:Ljava/lang/String;

    .line 68
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct {v0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    sput-object v0, Lcom/angry/mod/LoginActivity;->container:Landroid/widget/FrameLayout;

    .line 69
    const v1, -0xe5e5d2

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setBackgroundColor(I)V

    .line 71
    invoke-virtual {p0, p1}, Lcom/angry/mod/LoginActivity;->ShowLoginScreen(Landroid/content/Context;)V

    .line 72
    move-object v0, p1

    check-cast v0, Landroid/app/Activity;

    sget-object v1, Lcom/angry/mod/LoginActivity;->container:Landroid/widget/FrameLayout;

    invoke-virtual {v0, v1}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    .line 74
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v1, Lcom/angry/mod/LoginActivity$1;

    invoke-direct {v1, p0}, Lcom/angry/mod/LoginActivity$1;-><init>(Lcom/angry/mod/LoginActivity;)V

    const-wide/16 v2, 0x7d0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 83
    return-void
.end method

.method public static ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .registers 7
    .param p0, "context"  # Landroid/content/Context;
    .param p1, "message"  # Ljava/lang/String;
    .param p2, "level"  # Ljava/lang/String;

    .line 326
    sget-object v0, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    if-eqz v0, :cond_23

    .line 327
    invoke-static {}, Lcom/angry/mod/LoginActivity;->stopLoadingAnimation()V

    .line 328
    sget-object v0, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    const v1, -0x55ff01

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 329
    sget-object v0, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 331
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v1, Lcom/angry/mod/LoginActivity$4;

    invoke-direct {v1}, Lcom/angry/mod/LoginActivity$4;-><init>()V

    const-wide/16 v2, 0xbb8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 343
    :cond_23
    return-void
.end method

.method public static ShowInfoBox2(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3
    .param p0, "context"  # Landroid/content/Context;
    .param p1, "message"  # Ljava/lang/String;
    .param p2, "level"  # Ljava/lang/String;

    .line 346
    invoke-static {p0, p1, p2}, Lcom/angry/mod/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 347
    return-void
.end method

.method static synthetic access$000()Z
    .registers 1

    .line 28
    sget-boolean v0, Lcom/angry/mod/LoginActivity;->isLoading:Z

    return v0
.end method

.method static synthetic access$100()Landroid/widget/TextView;
    .registers 1

    .line 28
    sget-object v0, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$200()I
    .registers 1

    .line 28
    sget v0, Lcom/angry/mod/LoginActivity;->dotIndex:I

    return v0
.end method

.method static synthetic access$202(I)I
    .registers 1
    .param p0, "x0"  # I

    .line 28
    sput p0, Lcom/angry/mod/LoginActivity;->dotIndex:I

    return p0
.end method

.method static synthetic access$300()Landroid/os/Handler;
    .registers 1

    .line 28
    sget-object v0, Lcom/angry/mod/LoginActivity;->loadingHandler:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic access$400(Lcom/angry/mod/LoginActivity;)Landroid/widget/EditText;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/LoginActivity;

    .line 28
    iget-object v0, p0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    return-object v0
.end method

.method static synthetic access$500(Lcom/angry/mod/LoginActivity;)Landroid/content/SharedPreferences;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/LoginActivity;

    .line 28
    iget-object v0, p0, Lcom/angry/mod/LoginActivity;->sharedPreferences:Landroid/content/SharedPreferences;

    return-object v0
.end method

.method static synthetic access$600()Landroid/widget/Button;
    .registers 1

    .line 28
    sget-object v0, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$700()V
    .registers 0

    .line 28
    invoke-static {}, Lcom/angry/mod/LoginActivity;->startLoadingAnimation()V

    return-void
.end method

.method private decodeBase64ToBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 5
    .param p1, "base64Str"  # Ljava/lang/String;

    .line 87
    const/4 v0, 0x0

    :try_start_1
    invoke-static {p1, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    .line 88
    .local v1, "decodedBytes":[B
    array-length v2, v1

    invoke-static {v1, v0, v2}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v0
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_a} :catch_b

    return-object v0

    .line 89
    .end local v1  # "decodedBytes":[B
    :catch_b
    move-exception v1

    .line 90
    .local v1, "e":Ljava/lang/Exception;
    new-array v2, v0, [B

    invoke-static {v2, v0, v0}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v0

    return-object v0
.end method

.method public static showProgressBar(Z)V
    .registers 3
    .param p0, "show"  # Z

    .line 318
    sget-object v0, Lcom/angry/mod/LoginActivity;->appContext:Landroid/content/Context;

    if-nez v0, :cond_5

    return-void

    .line 320
    :cond_5
    sget-object v0, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    if-eqz v0, :cond_e

    .line 321
    xor-int/lit8 v1, p0, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 323
    :cond_e
    return-void
.end method

.method private static startLoadingAnimation()V
    .registers 2

    .line 95
    sget-object v0, Lcom/angry/mod/LoginActivity;->loadingHandler:Landroid/os/Handler;

    if-nez v0, :cond_b

    .line 96
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    sput-object v0, Lcom/angry/mod/LoginActivity;->loadingHandler:Landroid/os/Handler;

    .line 98
    :cond_b
    const/4 v0, 0x1

    sput-boolean v0, Lcom/angry/mod/LoginActivity;->isLoading:Z

    .line 99
    const/4 v0, 0x0

    sput v0, Lcom/angry/mod/LoginActivity;->dotIndex:I

    .line 100
    new-instance v0, Lcom/angry/mod/LoginActivity$2;

    invoke-direct {v0}, Lcom/angry/mod/LoginActivity$2;-><init>()V

    sput-object v0, Lcom/angry/mod/LoginActivity;->loadingRunnable:Ljava/lang/Runnable;

    .line 114
    sget-object v1, Lcom/angry/mod/LoginActivity;->loadingHandler:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 115
    return-void
.end method

.method private static stopLoadingAnimation()V
    .registers 2

    .line 118
    const/4 v0, 0x0

    sput-boolean v0, Lcom/angry/mod/LoginActivity;->isLoading:Z

    .line 119
    sget-object v0, Lcom/angry/mod/LoginActivity;->loadingHandler:Landroid/os/Handler;

    if-eqz v0, :cond_e

    sget-object v1, Lcom/angry/mod/LoginActivity;->loadingRunnable:Ljava/lang/Runnable;

    if-eqz v1, :cond_e

    .line 120
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 122
    :cond_e
    return-void
.end method


# virtual methods
.method public ShowLoginScreen(Landroid/content/Context;)V
    .registers 36
    .param p1, "context"  # Landroid/content/Context;

    .line 125
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABTUlEQVRIS73UISxFcRTH8Y8oSUZgYyNJxmY2KhNEGpEmkT2ZpBFpRMGobGZjksTGRmCSJLK/vWvP8+7//nE58e6c8/2f3/md2yQt5jCC0Wr6EY6xWVTeVJSAMwzk5J1jMNajCLCDqYJH7GI6LycGmMFWwoQhZRbbjXJjgJTXZz1zp4gB7tCROME9Or87wQ26EgG36P4uIOgf9pASQf+why8Rkyh4fyOlO+bzbqLIprEbyNjRWygChCYxN0VvIBSnAEJe2MUkhqvPPsFenvdrZU0FJK4ifcmt6EM/WrCP07ryIUzgGRe4xFM9otEEwTnBQfXxgqvqx140N8gJf9fgqI+oB7z+WIvPhR99awGLWC0JsIS1Whe14aGk5lmbdjxmE4zhoGTAOA4zQJnyZO98lykDVLBc8gQrqPwb4M+XHNQJV7mOnl9KdY2F6vV7A9ESNhl4JmGYAAAAAElFTkSuQmCC"

    invoke-direct {v0, v2}, Lcom/angry/mod/LoginActivity;->decodeBase64ToBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 127
    .local v2, "UserIcon":Landroid/graphics/Bitmap;
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 128
    .local v3, "principalLayout":Landroid/widget/LinearLayout;
    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, -0x1

    invoke-direct {v4, v5, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 129
    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 130
    const/16 v6, 0x11

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 131
    sget-object v7, Lcom/angry/mod/LoginActivity;->container:Landroid/widget/FrameLayout;

    invoke-virtual {v7, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 133
    new-instance v7, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v7}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 134
    .local v7, "lineBackground":Landroid/graphics/drawable/GradientDrawable;
    const v8, -0x55ff01

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 135
    const/16 v9, 0x8

    new-array v10, v9, [F

    .line 136
    invoke-static {v1, v9}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v11

    int-to-float v11, v11

    const/4 v12, 0x0

    aput v11, v10, v12

    invoke-static {v1, v9}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v11

    int-to-float v11, v11

    aput v11, v10, v4

    .line 137
    invoke-static {v1, v9}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v11

    int-to-float v11, v11

    const/4 v13, 0x2

    aput v11, v10, v13

    invoke-static {v1, v9}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v11

    int-to-float v11, v11

    const/4 v14, 0x3

    aput v11, v10, v14

    const/4 v11, 0x4

    const/4 v15, 0x0

    aput v15, v10, v11

    const/4 v9, 0x5

    aput v15, v10, v9

    const/16 v17, 0x6

    aput v15, v10, v17

    const/16 v18, 0x7

    aput v15, v10, v18

    .line 135
    invoke-virtual {v7, v10}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 142
    new-instance v10, Landroid/view/View;

    invoke-direct {v10, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 143
    .local v10, "lineView":Landroid/view/View;
    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v9, 0x170

    invoke-static {v1, v9}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v1, v14}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v12

    invoke-direct {v15, v9, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v9, v15

    .line 144
    .local v9, "lineParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v10, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 145
    invoke-virtual {v10, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 146
    invoke-virtual {v3, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 148
    new-instance v12, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v12}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 149
    .local v12, "tableBackground":Landroid/graphics/drawable/GradientDrawable;
    const v15, -0xe1e5d2

    invoke-virtual {v12, v15}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 150
    invoke-static {v1, v11}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v15

    int-to-float v15, v15

    invoke-virtual {v12, v15}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 152
    new-instance v15, Landroid/widget/LinearLayout;

    invoke-direct {v15, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 153
    .local v15, "tableLayout":Landroid/widget/LinearLayout;
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    .line 154
    const/16 v14, 0x172

    invoke-static {v1, v14}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v14

    const/4 v13, -0x2

    invoke-direct {v11, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 157
    .local v11, "tableParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v15, v11}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 158
    invoke-virtual {v15, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 159
    const/16 v14, 0xd

    invoke-static {v1, v14}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v14

    int-to-float v14, v14

    invoke-virtual {v15, v14}, Landroid/widget/LinearLayout;->setElevation(F)V

    .line 160
    invoke-virtual {v15, v12}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 161
    invoke-virtual {v3, v15}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 163
    new-instance v14, Landroid/widget/LinearLayout;

    invoke-direct {v14, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 164
    .local v14, "titleContainer":Landroid/widget/LinearLayout;
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v5, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 165
    .local v4, "titleContainerParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v14, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 166
    invoke-virtual {v14, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 168
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 169
    .local v6, "rText":Landroid/widget/TextView;
    const-string v13, "ANGRY "

    invoke-virtual {v6, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 170
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 171
    const/high16 v13, 0x41c80000  # 25.0f

    const/4 v8, 0x2

    invoke-virtual {v6, v8, v13}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 172
    sget-object v8, Lcom/angry/mod/LoginActivity;->googleSansFont:Landroid/graphics/Typeface;

    const/4 v13, 0x1

    invoke-static {v8, v13}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v8

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 174
    new-instance v8, Landroid/widget/TextView;

    invoke-direct {v8, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 175
    .local v8, "modsText":Landroid/widget/TextView;
    const-string v13, " MOD OFFICIAL"

    invoke-virtual {v8, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 176
    invoke-virtual {v8, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 177
    const/high16 v5, 0x41c80000  # 25.0f

    const/4 v13, 0x2

    invoke-virtual {v8, v13, v5}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 178
    sget-object v5, Lcom/angry/mod/LoginActivity;->googleSansFont:Landroid/graphics/Typeface;

    const/4 v13, 0x1

    invoke-static {v5, v13}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v5

    invoke-virtual {v8, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 180
    invoke-virtual {v14, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 181
    invoke-virtual {v14, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 182
    invoke-virtual {v15, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 184
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 185
    .local v5, "avisoText":Landroid/widget/TextView;
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v3

    move-object/from16 v24, v4

    const/4 v3, -0x1

    const/4 v4, -0x2

    .end local v3  # "principalLayout":Landroid/widget/LinearLayout;
    .end local v4  # "titleContainerParams":Landroid/widget/LinearLayout$LayoutParams;
    .local v23, "principalLayout":Landroid/widget/LinearLayout;
    .local v24, "titleContainerParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-direct {v13, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v3, v13

    .line 186
    .local v3, "avisoParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v5, v3}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 187
    const-string v4, "Log in to continue"

    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 188
    const v4, -0x55ff01

    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 189
    const/high16 v4, 0x41700000  # 15.0f

    const/4 v13, 0x2

    invoke-virtual {v5, v13, v4}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 190
    const/16 v4, 0x11

    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setGravity(I)V

    .line 191
    sget-object v4, Lcom/angry/mod/LoginActivity;->googleSansFont:Landroid/graphics/Typeface;

    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 192
    invoke-virtual {v15, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 194
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 195
    .local v4, "formLayout":Landroid/widget/LinearLayout;
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v22, v3

    move-object/from16 v25, v5

    const/4 v3, -0x1

    const/4 v5, -0x2

    .end local v3  # "avisoParams":Landroid/widget/LinearLayout$LayoutParams;
    .end local v5  # "avisoText":Landroid/widget/TextView;
    .local v22, "avisoParams":Landroid/widget/LinearLayout$LayoutParams;
    .local v25, "avisoText":Landroid/widget/TextView;
    invoke-direct {v13, v3, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v3, v13

    .line 196
    .local v3, "formParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v4, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 197
    const/4 v5, 0x1

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 198
    invoke-virtual {v15, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 200
    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 201
    .local v5, "usuarioLayout":Landroid/widget/LinearLayout;
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v3

    move-object/from16 v27, v6

    const/4 v3, -0x1

    const/4 v6, -0x2

    .end local v3  # "formParams":Landroid/widget/LinearLayout$LayoutParams;
    .end local v6  # "rText":Landroid/widget/TextView;
    .local v26, "formParams":Landroid/widget/LinearLayout$LayoutParams;
    .local v27, "rText":Landroid/widget/TextView;
    invoke-direct {v13, v3, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v3, v13

    .line 202
    .local v3, "usuarioLayoutParams":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v6, 0xa

    invoke-static {v1, v6}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v13

    iput v13, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 203
    invoke-static {v1, v6}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v13

    iput v13, v3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 204
    invoke-static {v1, v6}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v6

    iput v6, v3, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 205
    invoke-virtual {v5, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 206
    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 207
    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 209
    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 210
    .local v6, "logoEditBackground":Landroid/graphics/drawable/GradientDrawable;
    const v13, -0x55ff01

    invoke-virtual {v6, v13}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 211
    move-object/from16 v28, v3

    const/4 v13, 0x1

    .end local v3  # "usuarioLayoutParams":Landroid/widget/LinearLayout$LayoutParams;
    .local v28, "usuarioLayoutParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {v1, v13}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v3

    const v13, -0xb5eb74

    invoke-virtual {v6, v3, v13}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 212
    const/16 v3, 0x8

    new-array v13, v3, [F

    .line 213
    move-object/from16 v29, v4

    const/4 v3, 0x5

    .end local v4  # "formLayout":Landroid/widget/LinearLayout;
    .local v29, "formLayout":Landroid/widget/LinearLayout;
    invoke-static {v1, v3}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    int-to-float v4, v4

    const/16 v20, 0x0

    aput v4, v13, v20

    invoke-static {v1, v3}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    int-to-float v4, v4

    const/16 v20, 0x1

    aput v4, v13, v20

    const/4 v4, 0x2

    const/16 v19, 0x0

    aput v19, v13, v4

    const/4 v4, 0x3

    aput v19, v13, v4

    const/4 v4, 0x4

    aput v19, v13, v4

    aput v19, v13, v3

    .line 216
    invoke-static {v1, v3}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    int-to-float v4, v4

    aput v4, v13, v17

    invoke-static {v1, v3}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    int-to-float v3, v4

    aput v3, v13, v18

    .line 212
    invoke-virtual {v6, v13}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 219
    new-instance v3, Landroid/widget/ImageView;

    invoke-direct {v3, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    sput-object v3, Lcom/angry/mod/LoginActivity;->usuarioImagem:Landroid/widget/ImageView;

    .line 220
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x23

    invoke-static {v1, v4}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v13

    move-object/from16 v30, v7

    .end local v7  # "lineBackground":Landroid/graphics/drawable/GradientDrawable;
    .local v30, "lineBackground":Landroid/graphics/drawable/GradientDrawable;
    invoke-static {v1, v4}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v7

    invoke-direct {v3, v13, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 221
    .local v3, "usuarioImagemParams":Landroid/widget/LinearLayout$LayoutParams;
    sget-object v7, Lcom/angry/mod/LoginActivity;->usuarioImagem:Landroid/widget/ImageView;

    invoke-virtual {v7, v3}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 222
    sget-object v7, Lcom/angry/mod/LoginActivity;->usuarioImagem:Landroid/widget/ImageView;

    invoke-virtual {v7, v2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 223
    sget-object v7, Lcom/angry/mod/LoginActivity;->usuarioImagem:Landroid/widget/ImageView;

    invoke-virtual {v7, v6}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 224
    sget-object v7, Lcom/angry/mod/LoginActivity;->usuarioImagem:Landroid/widget/ImageView;

    const/16 v13, 0x8

    invoke-static {v1, v13}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    move-object/from16 v31, v2

    .end local v2  # "UserIcon":Landroid/graphics/Bitmap;
    .local v31, "UserIcon":Landroid/graphics/Bitmap;
    invoke-static {v1, v13}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v2

    move-object/from16 v32, v3

    .end local v3  # "usuarioImagemParams":Landroid/widget/LinearLayout$LayoutParams;
    .local v32, "usuarioImagemParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {v1, v13}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v3

    move-object/from16 v33, v6

    .end local v6  # "logoEditBackground":Landroid/graphics/drawable/GradientDrawable;
    .local v33, "logoEditBackground":Landroid/graphics/drawable/GradientDrawable;
    invoke-static {v1, v13}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v7, v4, v2, v3, v6}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 225
    sget-object v2, Lcom/angry/mod/LoginActivity;->usuarioImagem:Landroid/widget/ImageView;

    invoke-virtual {v5, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 227
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 228
    .local v2, "editBackground":Landroid/graphics/drawable/GradientDrawable;
    const v3, -0xd5e5b6

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 229
    const/4 v3, 0x1

    invoke-static {v1, v3}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    const v6, -0x55ff01

    invoke-virtual {v2, v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 230
    const/16 v4, 0x8

    new-array v6, v4, [F

    const/4 v4, 0x0

    const/4 v7, 0x0

    aput v7, v6, v4

    aput v7, v6, v3

    .line 232
    const/4 v3, 0x5

    invoke-static {v1, v3}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    int-to-float v4, v4

    const/4 v7, 0x2

    aput v4, v6, v7

    invoke-static {v1, v3}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    int-to-float v4, v4

    const/4 v7, 0x3

    aput v4, v6, v7

    .line 233
    invoke-static {v1, v3}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    int-to-float v4, v4

    const/4 v7, 0x4

    aput v4, v6, v7

    invoke-static {v1, v3}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    int-to-float v4, v4

    aput v4, v6, v3

    const/4 v3, 0x0

    aput v3, v6, v17

    aput v3, v6, v18

    .line 230
    invoke-virtual {v2, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 237
    new-instance v3, Landroid/widget/EditText;

    invoke-direct {v3, v1}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    iput-object v3, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    .line 238
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x23

    invoke-static {v1, v4}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v6

    const/high16 v4, 0x3f800000  # 1.0f

    const/4 v7, 0x0

    invoke-direct {v3, v7, v6, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 239
    .local v3, "usuarioEditParams":Landroid/widget/LinearLayout$LayoutParams;
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    invoke-virtual {v6, v3}, Landroid/widget/EditText;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 240
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    const-string v7, "Enter your Access Key"

    invoke-virtual {v6, v7}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    .line 241
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    iget-object v7, v0, Lcom/angry/mod/LoginActivity;->data_username:Ljava/lang/String;

    invoke-virtual {v6, v7}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 242
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    const v7, -0x4c6225

    invoke-virtual {v6, v7}, Landroid/widget/EditText;->setHintTextColor(I)V

    .line 243
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    const/4 v7, -0x1

    invoke-virtual {v6, v7}, Landroid/widget/EditText;->setTextColor(I)V

    .line 244
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    const/high16 v7, 0x41500000  # 13.0f

    const/4 v13, 0x2

    invoke-virtual {v6, v13, v7}, Landroid/widget/EditText;->setTextSize(IF)V

    .line 245
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    invoke-virtual {v6, v2}, Landroid/widget/EditText;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 246
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    const/16 v13, 0x8

    invoke-static {v1, v13}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v7

    const/4 v13, 0x0

    invoke-virtual {v6, v7, v13, v13, v13}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 247
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    invoke-virtual {v6}, Landroid/widget/EditText;->setSingleLine()V

    .line 248
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    sget-object v7, Lcom/angry/mod/LoginActivity;->googleSansFont:Landroid/graphics/Typeface;

    invoke-virtual {v6, v7}, Landroid/widget/EditText;->setTypeface(Landroid/graphics/Typeface;)V

    .line 249
    iget-object v6, v0, Lcom/angry/mod/LoginActivity;->etUser:Landroid/widget/EditText;

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 251
    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 252
    .local v6, "entrarLayout":Landroid/widget/LinearLayout;
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x2

    const/4 v13, -0x1

    invoke-direct {v7, v13, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v4, v7

    .line 253
    .local v4, "entrarLayoutParams":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v7, 0xf

    invoke-static {v1, v7}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v13

    iput v13, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 254
    invoke-static {v1, v7}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v13

    iput v13, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 255
    invoke-static {v1, v7}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v13

    iput v13, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 256
    invoke-static {v1, v7}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v7

    iput v7, v4, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 257
    invoke-virtual {v6, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 258
    const/4 v7, 0x0

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 259
    const/16 v7, 0x10

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 260
    invoke-virtual {v15, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 262
    new-instance v7, Landroid/widget/TextView;

    invoke-direct {v7, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    sput-object v7, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    .line 263
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v18, v2

    move-object/from16 v19, v3

    const/4 v2, -0x2

    const/high16 v3, 0x3f800000  # 1.0f

    const/4 v13, 0x0

    .end local v2  # "editBackground":Landroid/graphics/drawable/GradientDrawable;
    .end local v3  # "usuarioEditParams":Landroid/widget/LinearLayout$LayoutParams;
    .local v18, "editBackground":Landroid/graphics/drawable/GradientDrawable;
    .local v19, "usuarioEditParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-direct {v7, v13, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v2, v7

    .line 264
    .local v2, "statusParams":Landroid/widget/LinearLayout$LayoutParams;
    sget-object v3, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 265
    sget-object v3, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    const v7, -0x55ff01

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 266
    sget-object v3, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    const/high16 v7, 0x41400000  # 12.0f

    const/4 v13, 0x2

    invoke-virtual {v3, v13, v7}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 267
    sget-object v3, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    const/16 v7, 0x13

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setGravity(I)V

    .line 268
    sget-object v3, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    const-string v7, ""

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 269
    sget-object v3, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    sget-object v7, Lcom/angry/mod/LoginActivity;->googleSansFont:Landroid/graphics/Typeface;

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 271
    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 272
    .local v3, "entrarButtonBackground":Landroid/graphics/drawable/GradientDrawable;
    const v7, -0xb5eb74

    invoke-virtual {v3, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 273
    const/16 v7, 0x8

    invoke-static {v1, v7}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v3, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 275
    new-instance v7, Landroid/widget/Button;

    invoke-direct {v7, v1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    sput-object v7, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    .line 276
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v13, 0x50

    invoke-static {v1, v13}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v13

    move-object/from16 v16, v2

    const/16 v2, 0x23

    .end local v2  # "statusParams":Landroid/widget/LinearLayout$LayoutParams;
    .local v16, "statusParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {v1, v2}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v2

    invoke-direct {v7, v13, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v2, v7

    .line 277
    .local v2, "entrarButtonParams":Landroid/widget/LinearLayout$LayoutParams;
    sget-object v7, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    invoke-virtual {v7, v2}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 278
    sget-object v7, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    const-string v13, "Login"

    invoke-virtual {v7, v13}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 279
    sget-object v7, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    const/4 v13, -0x1

    invoke-virtual {v7, v13}, Landroid/widget/Button;->setTextColor(I)V

    .line 280
    sget-object v7, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    move-object/from16 v17, v2

    const/high16 v2, 0x41500000  # 13.0f

    const/4 v13, 0x2

    .end local v2  # "entrarButtonParams":Landroid/widget/LinearLayout$LayoutParams;
    .local v17, "entrarButtonParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v7, v13, v2}, Landroid/widget/Button;->setTextSize(IF)V

    .line 281
    sget-object v2, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    sget-object v7, Lcom/angry/mod/LoginActivity;->googleSansFont:Landroid/graphics/Typeface;

    invoke-virtual {v2, v7}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    .line 282
    sget-object v2, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    const/4 v7, 0x0

    invoke-virtual {v2, v7}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 283
    sget-object v2, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 284
    sget-object v2, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    const/4 v7, 0x2

    invoke-static {v1, v7}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v13

    move-object/from16 v20, v3

    .end local v3  # "entrarButtonBackground":Landroid/graphics/drawable/GradientDrawable;
    .local v20, "entrarButtonBackground":Landroid/graphics/drawable/GradientDrawable;
    invoke-static {v1, v7}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v3

    move-object/from16 v21, v4

    .end local v4  # "entrarLayoutParams":Landroid/widget/LinearLayout$LayoutParams;
    .local v21, "entrarLayoutParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {v1, v7}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v4

    invoke-static {v1, v7}, Lcom/angry/mod/Utils;->dp(Landroid/content/Context;I)I

    move-result v7

    invoke-virtual {v2, v13, v3, v4, v7}, Landroid/widget/Button;->setPadding(IIII)V

    .line 286
    sget-object v2, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    new-instance v3, Lcom/angry/mod/LoginActivity$3;

    invoke-direct {v3, v0, v1}, Lcom/angry/mod/LoginActivity$3;-><init>(Lcom/angry/mod/LoginActivity;Landroid/content/Context;)V

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 313
    sget-object v2, Lcom/angry/mod/LoginActivity;->statusTextView:Landroid/widget/TextView;

    invoke-virtual {v6, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 314
    sget-object v2, Lcom/angry/mod/LoginActivity;->loginButton:Landroid/widget/Button;

    invoke-virtual {v6, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 315
    return-void
.end method

.method public init(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 8
    .param p1, "mContext"  # Landroid/content/Context;
    .param p2, "titulo"  # Ljava/lang/String;
    .param p3, "nome"  # Ljava/lang/String;
    .param p4, "dialogoCima"  # Ljava/lang/String;
    .param p5, "dialogoBaixo"  # Ljava/lang/String;
    .param p6, "vendedores"  # Ljava/lang/String;
    .param p7, "namemod"  # Ljava/lang/String;

    .line 349
    return-void
.end method
