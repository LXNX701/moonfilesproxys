.class Lcom/angry/mod/Utils;
.super Ljava/lang/Object;
.source "Utils.java"


# instance fields
.field context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2
    .param p1, "globContext"  # Landroid/content/Context;

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    iput-object p1, p0, Lcom/angry/mod/Utils;->context:Landroid/content/Context;

    .line 28
    return-void
.end method

.method static SHA256(Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    .param p0, "data"  # Ljava/lang/String;

    .line 72
    :try_start_0
    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    .line 73
    .local v0, "md":Ljava/security/MessageDigest;
    invoke-virtual {v0}, Ljava/security/MessageDigest;->reset()V

    .line 74
    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/security/MessageDigest;->update([B)V

    .line 75
    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v1

    invoke-static {v1}, Lcom/angry/mod/Utils;->bytesToHex([B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v1
    :try_end_1e
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_1e} :catch_1f

    return-object v1

    .line 76
    .end local v0  # "md":Ljava/security/MessageDigest;
    :catch_1f
    move-exception v0

    .line 77
    .local v0, "ex":Ljava/security/NoSuchAlgorithmException;
    const/4 v1, 0x0

    return-object v1
.end method

.method private static bytesToHex([B)Ljava/lang/String;
    .registers 7
    .param p0, "bytes"  # [B

    .line 47
    const-string v0, "0123456789abcdef"

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    .line 48
    .local v0, "hexArray":[C
    array-length v1, p0

    mul-int/lit8 v1, v1, 0x2

    new-array v1, v1, [C

    .line 49
    .local v1, "hexChars":[C
    const/4 v2, 0x0

    .local v2, "j":I
    :goto_c
    array-length v3, p0

    if-ge v2, v3, :cond_28

    .line 50
    aget-byte v3, p0, v2

    and-int/lit16 v3, v3, 0xff

    .line 51
    .local v3, "v":I
    mul-int/lit8 v4, v2, 0x2

    ushr-int/lit8 v5, v3, 0x4

    aget-char v5, v0, v5

    aput-char v5, v1, v4

    .line 52
    mul-int/lit8 v4, v2, 0x2

    add-int/lit8 v4, v4, 0x1

    and-int/lit8 v5, v3, 0xf

    aget-char v5, v0, v5

    aput-char v5, v1, v4

    .line 49
    .end local v3  # "v":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_c

    .line 54
    .end local v2  # "j":I
    :cond_28
    new-instance v2, Ljava/lang/String;

    invoke-direct {v2, v1}, Ljava/lang/String;-><init>([C)V

    return-object v2
.end method

.method static clearCache(Landroid/content/Context;)V
    .registers 2
    .param p0, "context"  # Landroid/content/Context;

    .line 83
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v0

    .line 84
    .local v0, "dir":Ljava/io/File;
    invoke-static {v0}, Lcom/angry/mod/Utils;->deleteFilesInDir(Ljava/io/File;)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_7} :catch_8

    .end local v0  # "dir":Ljava/io/File;
    goto :goto_9

    .line 85
    :catch_8
    move-exception v0

    :goto_9
    nop

    .line 86
    return-void
.end method

.method private static deleteFilesInDir(Ljava/io/File;)V
    .registers 6
    .param p0, "dir"  # Ljava/io/File;

    .line 89
    invoke-virtual {p0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_6
    if-ge v2, v1, :cond_19

    aget-object v3, v0, v2

    .line 90
    .local v3, "file":Ljava/io/File;
    invoke-virtual {v3}, Ljava/io/File;->isDirectory()Z

    move-result v4

    if-eqz v4, :cond_13

    .line 91
    invoke-static {v3}, Lcom/angry/mod/Utils;->deleteFilesInDir(Ljava/io/File;)V

    .line 93
    :cond_13
    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    .line 89
    .end local v3  # "file":Ljava/io/File;
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    .line 95
    :cond_19
    return-void
.end method

.method public static dp(Landroid/content/Context;I)I
    .registers 5
    .param p0, "context"  # Landroid/content/Context;
    .param p1, "i"  # I

    .line 33
    int-to-float v0, p1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v2, v0, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    float-to-int v0, v0

    return v0
.end method

.method static fromBase64(Ljava/lang/String;)[B
    .registers 2
    .param p0, "s"  # Ljava/lang/String;

    .line 135
    const/4 v0, 0x2

    invoke-static {p0, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v0

    return-object v0
.end method

.method static fromBase64String(Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    .param p0, "s"  # Ljava/lang/String;

    .line 139
    new-instance v0, Ljava/lang/String;

    const/4 v1, 0x2

    invoke-static {p0, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v0, v1, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    return-object v0
.end method

.method public static isPackageInstalled(Landroid/content/Context;Ljava/lang/String;)Z
    .registers 5
    .param p0, "context"  # Landroid/content/Context;
    .param p1, "packageName"  # Ljava/lang/String;

    .line 37
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    .line 39
    .local v0, "packageManager":Landroid/content/pm/PackageManager;
    const/4 v1, 0x1

    :try_start_5
    invoke-virtual {v0, p1, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_8
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_5 .. :try_end_8} :catch_9

    .line 40
    return v1

    .line 41
    :catch_9
    move-exception v1

    .line 42
    .local v1, "e":Landroid/content/pm/PackageManager$NameNotFoundException;
    const/4 v2, 0x0

    return v2
.end method

.method static loaderDecrypt([B)[B
    .registers 4
    .param p0, "srcdata"  # [B

    .line 99
    :try_start_0
    new-instance v0, Ljavax/crypto/spec/SecretKeySpec;

    const-string v1, "22P9ULFDKPJ70G46"

    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    const-string v2, "AES"

    invoke-direct {v0, v1, v2}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    .line 100
    .local v0, "skey":Ljavax/crypto/spec/SecretKeySpec;
    const-string v1, "AES/ECB/PKCS5Padding"

    invoke-static {v1}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object v1

    .line 101
    .local v1, "cipher":Ljavax/crypto/Cipher;
    const/4 v2, 0x2

    invoke-virtual {v1, v2, v0}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    .line 102
    invoke-virtual {v1, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object v2
    :try_end_1b
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_1b} :catch_30
    .catch Ljava/security/InvalidKeyException; {:try_start_0 .. :try_end_1b} :catch_2b
    .catch Ljavax/crypto/NoSuchPaddingException; {:try_start_0 .. :try_end_1b} :catch_26
    .catch Ljavax/crypto/BadPaddingException; {:try_start_0 .. :try_end_1b} :catch_21
    .catch Ljavax/crypto/IllegalBlockSizeException; {:try_start_0 .. :try_end_1b} :catch_1c

    return-object v2

    .line 111
    .end local v0  # "skey":Ljavax/crypto/spec/SecretKeySpec;
    .end local v1  # "cipher":Ljavax/crypto/Cipher;
    :catch_1c
    move-exception v0

    .line 112
    .local v0, "e":Ljavax/crypto/IllegalBlockSizeException;
    invoke-virtual {v0}, Ljavax/crypto/IllegalBlockSizeException;->printStackTrace()V

    goto :goto_35

    .line 109
    .end local v0  # "e":Ljavax/crypto/IllegalBlockSizeException;
    :catch_21
    move-exception v0

    .line 110
    .local v0, "e":Ljavax/crypto/BadPaddingException;
    invoke-virtual {v0}, Ljavax/crypto/BadPaddingException;->printStackTrace()V

    .end local v0  # "e":Ljavax/crypto/BadPaddingException;
    goto :goto_34

    .line 107
    :catch_26
    move-exception v0

    .line 108
    .local v0, "e":Ljavax/crypto/NoSuchPaddingException;
    invoke-virtual {v0}, Ljavax/crypto/NoSuchPaddingException;->printStackTrace()V

    .end local v0  # "e":Ljavax/crypto/NoSuchPaddingException;
    goto :goto_34

    .line 105
    :catch_2b
    move-exception v0

    .line 106
    .local v0, "e":Ljava/security/InvalidKeyException;
    invoke-virtual {v0}, Ljava/security/InvalidKeyException;->printStackTrace()V

    .end local v0  # "e":Ljava/security/InvalidKeyException;
    goto :goto_34

    .line 103
    :catch_30
    move-exception v0

    .line 104
    .local v0, "e":Ljava/security/NoSuchAlgorithmException;
    invoke-virtual {v0}, Ljava/security/NoSuchAlgorithmException;->printStackTrace()V

    .line 113
    .end local v0  # "e":Ljava/security/NoSuchAlgorithmException;
    :goto_34
    nop

    .line 114
    :goto_35
    const/4 v0, 0x0

    return-object v0
.end method

.method static profileDecrypt(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 7
    .param p0, "data"  # Ljava/lang/String;
    .param p1, "sign"  # Ljava/lang/String;

    .line 118
    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    .line 119
    .local v0, "key":[C
    invoke-static {p0}, Lcom/angry/mod/Utils;->fromBase64String(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    .line 120
    .local v1, "out":[C
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_d
    array-length v3, v1

    if-ge v2, v3, :cond_1e

    .line 121
    array-length v3, v0

    rem-int v3, v2, v3

    aget-char v3, v0, v3

    aget-char v4, v1, v2

    xor-int/2addr v3, v4

    int-to-char v3, v3

    aput-char v3, v1, v2

    .line 120
    add-int/lit8 v2, v2, 0x1

    goto :goto_d

    .line 123
    .end local v2  # "i":I
    :cond_1e
    new-instance v2, Ljava/lang/String;

    invoke-direct {v2, v1}, Ljava/lang/String;-><init>([C)V

    return-object v2
.end method

.method static readStream(Ljava/io/InputStream;)Ljava/lang/String;
    .registers 5
    .param p0, "in"  # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 59
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 60
    .local v0, "response":Ljava/lang/StringBuilder;
    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-direct {v2, p0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 61
    .local v1, "reader":Ljava/io/BufferedReader;
    :try_start_f
    const-string v2, ""

    .line 63
    .local v2, "line":Ljava/lang/String;
    :goto_11
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    move-object v2, v3

    if-eqz v3, :cond_1c

    .line 64
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_1b
    .catchall {:try_start_f .. :try_end_1b} :catchall_24

    goto :goto_11

    .line 66
    .end local v2  # "line":Ljava/lang/String;
    :cond_1c
    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V

    .line 67
    .end local v1  # "reader":Ljava/io/BufferedReader;
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 60
    .restart local v1  # "reader":Ljava/io/BufferedReader;
    :catchall_24
    move-exception v2

    :try_start_25
    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_28
    .catchall {:try_start_25 .. :try_end_28} :catchall_29

    goto :goto_2d

    :catchall_29
    move-exception v3

    invoke-virtual {v2, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2d
    throw v2
.end method

.method static toBase64(Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    .param p0, "s"  # Ljava/lang/String;

    .line 127
    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const/4 v1, 0x2

    invoke-static {v0, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static toBase64([B)Ljava/lang/String;
    .registers 2
    .param p0, "s"  # [B

    .line 131
    const/4 v0, 0x2

    invoke-static {p0, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public FixDP(I)I
    .registers 5
    .param p1, "i"  # I

    .line 30
    int-to-float v0, p1

    iget-object v1, p0, Lcom/angry/mod/Utils;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v2, v0, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    float-to-int v0, v0

    return v0
.end method
