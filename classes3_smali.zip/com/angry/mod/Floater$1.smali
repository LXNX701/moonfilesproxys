.class Lcom/angry/mod/Floater$1;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater;->onCreateTemplate()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/angry/mod/Floater;


# direct methods
.method constructor <init>(Lcom/angry/mod/Floater;)V
    .registers 2
    .param p1, "this$0"  # Lcom/angry/mod/Floater;

    .line 364
    iput-object p1, p0, Lcom/angry/mod/Floater$1;->this$0:Lcom/angry/mod/Floater;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 4
    .param p1, "view"  # Landroid/view/View;

    .line 367
    iget-object v0, p0, Lcom/angry/mod/Floater$1;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$000(Lcom/angry/mod/Floater;)Z

    move-result v0

    if-nez v0, :cond_2d

    .line 368
    invoke-static {}, Lcom/angry/mod/Floater;->Functions()V

    .line 369
    invoke-static {}, Lcom/angry/mod/Floater;->access$100()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/angry/mod/Floater;->ftKZXivSr(Landroid/content/Context;)V

    .line 370
    iget-object v0, p0, Lcom/angry/mod/Floater$1;->this$0:Lcom/angry/mod/Floater;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/angry/mod/Floater;->access$002(Lcom/angry/mod/Floater;Z)Z

    .line 371
    iget-object v0, p0, Lcom/angry/mod/Floater$1;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$200(Lcom/angry/mod/Floater;)Landroid/widget/Button;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 372
    iget-object v0, p0, Lcom/angry/mod/Floater$1;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$300(Lcom/angry/mod/Floater;)Landroid/widget/Button;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 374
    :cond_2d
    return-void
.end method
