.class public Lcom/angry/mod/Prefs;
.super Ljava/lang/Object;
.source "Prefs.java"


# static fields
.field private static final DEFAULT_BOOLEAN_VALUE:Z = false

.field private static final DEFAULT_DOUBLE_VALUE:D = -1.0

.field private static final DEFAULT_FLOAT_VALUE:F = -1.0f

.field private static final DEFAULT_INT_VALUE:I = -0x1

.field private static final DEFAULT_LONG_VALUE:J = -0x1L

.field private static final DEFAULT_STRING_VALUE:Ljava/lang/String; = ""

.field private static final LENGTH:Ljava/lang/String; = "_length"

.field private static prefsInstance:Lcom/angry/mod/Prefs;


# instance fields
.field private sharedPreferences:Landroid/content/SharedPreferences;


# direct methods
.method private constructor <init>(Landroid/content/Context;)V
    .registers 5
    .param p1, "context"  # Landroid/content/Context;

    .line 59
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 60
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 61
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "_preferences"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 60
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    .line 64
    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .registers 5
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "preferencesName"  # Ljava/lang/String;

    .line 66
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 67
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, p2, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    .line 71
    return-void
.end method

.method public static CustomToast(Ljava/lang/String;Landroid/content/Context;)V
    .registers 11
    .param p0, "name"  # Ljava/lang/String;
    .param p1, "mthis"  # Landroid/content/Context;

    .line 32
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 33
    .local v0, "ln":Landroid/widget/LinearLayout;
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 34
    const/16 v1, 0xc

    invoke-static {v1, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v3

    invoke-static {v1, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v4

    invoke-static {v1, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v5

    invoke-static {v1, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v1

    invoke-virtual {v0, v3, v4, v5, v1}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 35
    const v1, 0x3f666666  # 0.9f

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setAlpha(F)V

    .line 37
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 38
    .local v1, "mGrad":Landroid/graphics/drawable/GradientDrawable;
    const-string v3, "#FFFFFF"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 39
    const/16 v3, 0x8

    new-array v3, v3, [F

    const/4 v4, 0x5

    invoke-static {v4, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v5

    int-to-float v5, v5

    const/4 v6, 0x0

    aput v5, v3, v6

    invoke-static {v4, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v5

    int-to-float v5, v5

    const/4 v7, 0x1

    aput v5, v3, v7

    invoke-static {v4, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v5

    int-to-float v5, v5

    const/4 v8, 0x2

    aput v5, v3, v8

    invoke-static {v4, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v5

    int-to-float v5, v5

    const/4 v8, 0x3

    aput v5, v3, v8

    invoke-static {v4, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v5

    int-to-float v5, v5

    const/4 v8, 0x4

    aput v5, v3, v8

    invoke-static {v4, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v5

    int-to-float v5, v5

    aput v5, v3, v4

    invoke-static {v4, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v5

    int-to-float v5, v5

    const/4 v8, 0x6

    aput v5, v3, v8

    invoke-static {v4, p1}, Lcom/angry/mod/Prefs;->dp(ILandroid/content/Context;)I

    move-result v4

    int-to-float v4, v4

    const/4 v5, 0x7

    aput v4, v3, v5

    invoke-virtual {v1, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 41
    new-instance v3, Landroid/graphics/drawable/RippleDrawable;

    new-instance v4, Landroid/content/res/ColorStateList;

    new-array v5, v7, [[I

    new-array v8, v6, [I

    aput-object v8, v5, v6

    filled-new-array {v2}, [I

    move-result-object v6

    invoke-direct {v4, v5, v6}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    const/4 v5, 0x0

    invoke-direct {v3, v4, v1, v5}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 42
    .local v3, "Efeito":Landroid/graphics/drawable/RippleDrawable;
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 45
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 46
    .local v4, "tv":Landroid/widget/TextView;
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    invoke-direct {v5, v6, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 47
    invoke-virtual {v4, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 48
    const-string v2, "#000000"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 50
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 53
    new-instance v2, Landroid/widget/Toast;

    invoke-direct {v2, p1}, Landroid/widget/Toast;-><init>(Landroid/content/Context;)V

    .line 54
    .local v2, "toast":Landroid/widget/Toast;
    invoke-virtual {v2, v7}, Landroid/widget/Toast;->setDuration(I)V

    .line 55
    invoke-virtual {v2, v0}, Landroid/widget/Toast;->setView(Landroid/view/View;)V

    .line 56
    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 57
    return-void
.end method

.method public static dp(ILandroid/content/Context;)I
    .registers 5
    .param p0, "dp"  # I
    .param p1, "_context"  # Landroid/content/Context;

    .line 26
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 27
    .local v0, "scale":F
    int-to-float v1, p0

    mul-float v1, v1, v0

    const/high16 v2, 0x3f000000  # 0.5f

    add-float/2addr v1, v2

    float-to-int v1, v1

    return v1
.end method

.method public static with(Landroid/content/Context;)Lcom/angry/mod/Prefs;
    .registers 2
    .param p0, "context"  # Landroid/content/Context;

    .line 74
    sget-object v0, Lcom/angry/mod/Prefs;->prefsInstance:Lcom/angry/mod/Prefs;

    if-nez v0, :cond_b

    .line 75
    new-instance v0, Lcom/angry/mod/Prefs;

    invoke-direct {v0, p0}, Lcom/angry/mod/Prefs;-><init>(Landroid/content/Context;)V

    sput-object v0, Lcom/angry/mod/Prefs;->prefsInstance:Lcom/angry/mod/Prefs;

    .line 77
    :cond_b
    sget-object v0, Lcom/angry/mod/Prefs;->prefsInstance:Lcom/angry/mod/Prefs;

    return-object v0
.end method

.method public static with(Landroid/content/Context;Ljava/lang/String;)Lcom/angry/mod/Prefs;
    .registers 3
    .param p0, "context"  # Landroid/content/Context;
    .param p1, "preferencesName"  # Ljava/lang/String;

    .line 88
    sget-object v0, Lcom/angry/mod/Prefs;->prefsInstance:Lcom/angry/mod/Prefs;

    if-nez v0, :cond_b

    .line 89
    new-instance v0, Lcom/angry/mod/Prefs;

    invoke-direct {v0, p0, p1}, Lcom/angry/mod/Prefs;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    sput-object v0, Lcom/angry/mod/Prefs;->prefsInstance:Lcom/angry/mod/Prefs;

    .line 91
    :cond_b
    sget-object v0, Lcom/angry/mod/Prefs;->prefsInstance:Lcom/angry/mod/Prefs;

    return-object v0
.end method

.method public static with(Landroid/content/Context;Ljava/lang/String;Z)Lcom/angry/mod/Prefs;
    .registers 4
    .param p0, "context"  # Landroid/content/Context;
    .param p1, "preferencesName"  # Ljava/lang/String;
    .param p2, "forceInstantiation"  # Z

    .line 96
    if-eqz p2, :cond_9

    .line 97
    new-instance v0, Lcom/angry/mod/Prefs;

    invoke-direct {v0, p0, p1}, Lcom/angry/mod/Prefs;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    sput-object v0, Lcom/angry/mod/Prefs;->prefsInstance:Lcom/angry/mod/Prefs;

    .line 99
    :cond_9
    sget-object v0, Lcom/angry/mod/Prefs;->prefsInstance:Lcom/angry/mod/Prefs;

    return-object v0
.end method

.method public static with(Landroid/content/Context;Z)Lcom/angry/mod/Prefs;
    .registers 3
    .param p0, "context"  # Landroid/content/Context;
    .param p1, "forceInstantiation"  # Z

    .line 81
    if-eqz p1, :cond_9

    .line 82
    new-instance v0, Lcom/angry/mod/Prefs;

    invoke-direct {v0, p0}, Lcom/angry/mod/Prefs;-><init>(Landroid/content/Context;)V

    sput-object v0, Lcom/angry/mod/Prefs;->prefsInstance:Lcom/angry/mod/Prefs;

    .line 84
    :cond_9
    sget-object v0, Lcom/angry/mod/Prefs;->prefsInstance:Lcom/angry/mod/Prefs;

    return-object v0
.end method


# virtual methods
.method public clear()V
    .registers 2

    .line 221
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 222
    return-void
.end method

.method public contains(Ljava/lang/String;)Z
    .registers 3
    .param p1, "key"  # Ljava/lang/String;

    .line 217
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, p1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;
    .registers 4
    .param p1, "key"  # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 197
    .local p2, "defValue":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public putStringSet(Ljava/lang/String;Ljava/util/Set;)V
    .registers 4
    .param p1, "key"  # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 193
    .local p2, "value":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 194
    return-void
.end method

.method public read(Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    .param p1, "what"  # Ljava/lang/String;

    .line 105
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    const-string v1, ""

    invoke-interface {v0, p1, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public read(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    .param p1, "what"  # Ljava/lang/String;
    .param p2, "defaultString"  # Ljava/lang/String;

    .line 109
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public readBoolean(Ljava/lang/String;)Z
    .registers 3
    .param p1, "what"  # Ljava/lang/String;

    .line 179
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/angry/mod/Prefs;->readBoolean(Ljava/lang/String;Z)Z

    move-result v0

    return v0
.end method

.method public readBoolean(Ljava/lang/String;Z)Z
    .registers 4
    .param p1, "what"  # Ljava/lang/String;
    .param p2, "defaultBoolean"  # Z

    .line 183
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    return v0
.end method

.method public readDouble(Ljava/lang/String;)D
    .registers 4
    .param p1, "what"  # Ljava/lang/String;

    .line 133
    invoke-virtual {p0, p1}, Lcom/angry/mod/Prefs;->contains(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_9

    .line 134
    const-wide/high16 v0, -0x4010000000000000L  # -1.0

    return-wide v0

    .line 135
    :cond_9
    invoke-virtual {p0, p1}, Lcom/angry/mod/Prefs;->readLong(Ljava/lang/String;)J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v0

    return-wide v0
.end method

.method public readDouble(Ljava/lang/String;D)D
    .registers 6
    .param p1, "what"  # Ljava/lang/String;
    .param p2, "defaultDouble"  # D

    .line 139
    invoke-virtual {p0, p1}, Lcom/angry/mod/Prefs;->contains(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_7

    .line 140
    return-wide p2

    .line 141
    :cond_7
    invoke-virtual {p0, p1}, Lcom/angry/mod/Prefs;->readLong(Ljava/lang/String;)J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v0

    return-wide v0
.end method

.method public readFloat(Ljava/lang/String;)F
    .registers 4
    .param p1, "what"  # Ljava/lang/String;

    .line 151
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    const/high16 v1, -0x40800000  # -1.0f

    invoke-interface {v0, p1, v1}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v0

    return v0
.end method

.method public readFloat(Ljava/lang/String;F)F
    .registers 4
    .param p1, "what"  # Ljava/lang/String;
    .param p2, "defaultFloat"  # F

    .line 155
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v0

    return v0
.end method

.method public readInt(Ljava/lang/String;)I
    .registers 4
    .param p1, "what"  # Ljava/lang/String;

    .line 119
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    const/4 v1, -0x1

    invoke-interface {v0, p1, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public readInt(Ljava/lang/String;I)I
    .registers 4
    .param p1, "what"  # Ljava/lang/String;
    .param p2, "defaultInt"  # I

    .line 123
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public readLong(Ljava/lang/String;)J
    .registers 5
    .param p1, "what"  # Ljava/lang/String;

    .line 165
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    const-wide/16 v1, -0x1

    invoke-interface {v0, p1, v1, v2}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    return-wide v0
.end method

.method public readLong(Ljava/lang/String;J)J
    .registers 6
    .param p1, "what"  # Ljava/lang/String;
    .param p2, "defaultLong"  # J

    .line 169
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0, p1, p2, p3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    return-wide v0
.end method

.method public remove(Ljava/lang/String;)V
    .registers 7
    .param p1, "key"  # Ljava/lang/String;

    .line 203
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "_length"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/angry/mod/Prefs;->contains(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_7e

    .line 205
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/angry/mod/Prefs;->readInt(Ljava/lang/String;)I

    move-result v0

    .line 206
    .local v0, "stringSetLength":I
    if-ltz v0, :cond_7e

    .line 207
    iget-object v2, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 208
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_4f
    if-ge v1, v0, :cond_7e

    .line 209
    iget-object v2, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "]"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 208
    add-int/lit8 v1, v1, 0x1

    goto :goto_4f

    .line 213
    .end local v0  # "stringSetLength":I
    .end local v1  # "i":I
    :cond_7e
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 214
    return-void
.end method

.method public write(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4
    .param p1, "where"  # Ljava/lang/String;
    .param p2, "what"  # Ljava/lang/String;

    .line 113
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 114
    return-void
.end method

.method public writeBoolean(Ljava/lang/String;Z)V
    .registers 4
    .param p1, "where"  # Ljava/lang/String;
    .param p2, "what"  # Z

    .line 187
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 188
    return-void
.end method

.method public writeDouble(Ljava/lang/String;D)V
    .registers 6
    .param p1, "where"  # Ljava/lang/String;
    .param p2, "what"  # D

    .line 145
    invoke-static {p2, p3}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v0

    invoke-virtual {p0, p1, v0, v1}, Lcom/angry/mod/Prefs;->writeLong(Ljava/lang/String;J)V

    .line 146
    return-void
.end method

.method public writeFloat(Ljava/lang/String;F)V
    .registers 4
    .param p1, "where"  # Ljava/lang/String;
    .param p2, "what"  # F

    .line 159
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 160
    return-void
.end method

.method public writeInt(Ljava/lang/String;I)V
    .registers 4
    .param p1, "where"  # Ljava/lang/String;
    .param p2, "what"  # I

    .line 127
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 128
    return-void
.end method

.method public writeLong(Ljava/lang/String;J)V
    .registers 5
    .param p1, "where"  # Ljava/lang/String;
    .param p2, "what"  # J

    .line 173
    iget-object v0, p0, Lcom/angry/mod/Prefs;->sharedPreferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 174
    return-void
.end method
