.class Lcom/angry/mod/Floater$10;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater;->addSeekBar(Ljava/lang/String;IILjava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$finalID:I

.field final synthetic val$finalName:Ljava/lang/String;

.field final synthetic val$finalType:Ljava/lang/String;

.field final synthetic val$text:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Landroid/widget/TextView;Ljava/lang/String;Ljava/lang/String;I)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 700
    iput-object p1, p0, Lcom/angry/mod/Floater$10;->val$text:Landroid/widget/TextView;

    iput-object p2, p0, Lcom/angry/mod/Floater$10;->val$finalName:Ljava/lang/String;

    iput-object p3, p0, Lcom/angry/mod/Floater$10;->val$finalType:Ljava/lang/String;

    iput p4, p0, Lcom/angry/mod/Floater$10;->val$finalID:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .registers 7
    .param p1, "seekBar"  # Landroid/widget/SeekBar;
    .param p2, "i"  # I
    .param p3, "b"  # Z

    .line 703
    iget-object v0, p0, Lcom/angry/mod/Floater$10;->val$text:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/angry/mod/Floater$10;->val$finalName:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/angry/mod/Floater$10;->val$finalType:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 704
    iget v0, p0, Lcom/angry/mod/Floater$10;->val$finalID:I

    invoke-static {v0, p2}, Lcom/angry/mod/Floater;->ChangesID(II)V

    .line 705
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2
    .param p1, "seekBar"  # Landroid/widget/SeekBar;

    .line 707
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2
    .param p1, "seekBar"  # Landroid/widget/SeekBar;

    .line 709
    return-void
.end method
