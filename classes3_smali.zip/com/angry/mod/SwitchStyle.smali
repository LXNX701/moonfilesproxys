.class public Lcom/angry/mod/SwitchStyle;
.super Landroid/view/View;
.source "SwitchStyle.java"

# interfaces
.implements Landroid/widget/Checkable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/angry/mod/SwitchStyle$ViewState;,
        Lcom/angry/mod/SwitchStyle$OnCheckedChangeListener;
    }
.end annotation


# static fields
.field private static final DEFAULT_HEIGHT:I

.field private static final DEFAULT_WIDTH:I


# instance fields
.field private final ANIMATE_STATE_DRAGING:I

.field private final ANIMATE_STATE_NONE:I

.field private final ANIMATE_STATE_PENDING_DRAG:I

.field private final ANIMATE_STATE_PENDING_RESET:I

.field private final ANIMATE_STATE_PENDING_SETTLE:I

.field private final ANIMATE_STATE_SWITCH:I

.field private afterState:Lcom/angry/mod/SwitchStyle$ViewState;

.field private animateState:I

.field private animatorListener:Landroid/animation/Animator$AnimatorListener;

.field private animatorUpdateListener:Landroid/animation/ValueAnimator$AnimatorUpdateListener;

.field private final argbEvaluator:Landroid/animation/ArgbEvaluator;

.field private background:I

.field private beforeState:Lcom/angry/mod/SwitchStyle$ViewState;

.field private borderWidth:I

.field private bottom:F

.field private buttonEdgeFrame:Z

.field private buttonMaxX:F

.field private buttonMinX:F

.field private buttonPaint:Landroid/graphics/Paint;

.field private buttonRadius:F

.field private centerX:F

.field private centerY:F

.field private checkLineColor:I

.field private checkLineLength:F

.field private checkLineWidth:I

.field private checkedButtonColor:I

.field private checkedColor:I

.field private checkedLineOffsetX:F

.field private checkedLineOffsetY:F

.field private enableEffect:Z

.field private height:F

.field private isChecked:Z

.field private isEventBroadcast:Z

.field private isTouchingDown:Z

.field private isUiInited:Z

.field private left:F

.field private onCheckedChangeListener:Lcom/angry/mod/SwitchStyle$OnCheckedChangeListener;

.field private paint:Landroid/graphics/Paint;

.field private postPendingDrag:Ljava/lang/Runnable;

.field private rect:Landroid/graphics/RectF;

.field private right:F

.field private shadowColor:I

.field private shadowEffect:Z

.field private shadowOffset:I

.field private shadowRadius:I

.field private showIndicator:Z

.field private top:F

.field private touchDownTime:J

.field private uncheckButtonColor:I

.field private uncheckCircleColor:I

.field private uncheckCircleOffsetX:F

.field private uncheckCircleRadius:F

.field private uncheckCircleWidth:I

.field private uncheckColor:I

.field private valueAnimator:Landroid/animation/ValueAnimator;

.field private viewRadius:F

.field private viewState:Lcom/angry/mod/SwitchStyle$ViewState;

.field private width:F


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 21
    const/high16 v0, 0x42380000  # 46.0f

    invoke-static {v0}, Lcom/angry/mod/SwitchStyle;->dp2pxInt(F)I

    move-result v0

    sput v0, Lcom/angry/mod/SwitchStyle;->DEFAULT_WIDTH:I

    .line 22
    const/high16 v0, 0x41c80000  # 25.0f

    invoke-static {v0}, Lcom/angry/mod/SwitchStyle;->dp2pxInt(F)I

    move-result v0

    sput v0, Lcom/angry/mod/SwitchStyle;->DEFAULT_HEIGHT:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 5
    .param p1, "context"  # Landroid/content/Context;

    .line 32
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 24
    const/4 v0, 0x0

    iput v0, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_NONE:I

    .line 25
    const/4 v1, 0x1

    iput v1, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_DRAG:I

    .line 26
    const/4 v2, 0x2

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_DRAGING:I

    .line 27
    const/4 v2, 0x3

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_RESET:I

    .line 28
    const/4 v2, 0x4

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_SETTLE:I

    .line 29
    const/4 v2, 0x5

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_SWITCH:I

    .line 728
    iput-boolean v1, p0, Lcom/angry/mod/SwitchStyle;->buttonEdgeFrame:Z

    .line 740
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lcom/angry/mod/SwitchStyle;->rect:Landroid/graphics/RectF;

    .line 741
    iput v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    .line 745
    new-instance v1, Landroid/animation/ArgbEvaluator;

    invoke-direct {v1}, Landroid/animation/ArgbEvaluator;-><init>()V

    iput-object v1, p0, Lcom/angry/mod/SwitchStyle;->argbEvaluator:Landroid/animation/ArgbEvaluator;

    .line 752
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isTouchingDown:Z

    .line 753
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isUiInited:Z

    .line 754
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isEventBroadcast:Z

    .line 760
    new-instance v0, Lcom/angry/mod/SwitchStyle$1;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$1;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->postPendingDrag:Ljava/lang/Runnable;

    .line 769
    new-instance v0, Lcom/angry/mod/SwitchStyle$2;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$2;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->animatorUpdateListener:Landroid/animation/ValueAnimator$AnimatorUpdateListener;

    .line 833
    new-instance v0, Lcom/angry/mod/SwitchStyle$3;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$3;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->animatorListener:Landroid/animation/Animator$AnimatorListener;

    .line 33
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/angry/mod/SwitchStyle;->init(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 34
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 6
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "attrs"  # Landroid/util/AttributeSet;

    .line 37
    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 24
    const/4 v0, 0x0

    iput v0, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_NONE:I

    .line 25
    const/4 v1, 0x1

    iput v1, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_DRAG:I

    .line 26
    const/4 v2, 0x2

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_DRAGING:I

    .line 27
    const/4 v2, 0x3

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_RESET:I

    .line 28
    const/4 v2, 0x4

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_SETTLE:I

    .line 29
    const/4 v2, 0x5

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_SWITCH:I

    .line 728
    iput-boolean v1, p0, Lcom/angry/mod/SwitchStyle;->buttonEdgeFrame:Z

    .line 740
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lcom/angry/mod/SwitchStyle;->rect:Landroid/graphics/RectF;

    .line 741
    iput v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    .line 745
    new-instance v1, Landroid/animation/ArgbEvaluator;

    invoke-direct {v1}, Landroid/animation/ArgbEvaluator;-><init>()V

    iput-object v1, p0, Lcom/angry/mod/SwitchStyle;->argbEvaluator:Landroid/animation/ArgbEvaluator;

    .line 752
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isTouchingDown:Z

    .line 753
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isUiInited:Z

    .line 754
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isEventBroadcast:Z

    .line 760
    new-instance v0, Lcom/angry/mod/SwitchStyle$1;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$1;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->postPendingDrag:Ljava/lang/Runnable;

    .line 769
    new-instance v0, Lcom/angry/mod/SwitchStyle$2;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$2;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->animatorUpdateListener:Landroid/animation/ValueAnimator$AnimatorUpdateListener;

    .line 833
    new-instance v0, Lcom/angry/mod/SwitchStyle$3;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$3;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->animatorListener:Landroid/animation/Animator$AnimatorListener;

    .line 38
    invoke-direct {p0, p1, p2}, Lcom/angry/mod/SwitchStyle;->init(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 39
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 7
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "attrs"  # Landroid/util/AttributeSet;
    .param p3, "defStyleAttr"  # I

    .line 42
    invoke-direct {p0, p1, p2, p3}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 24
    const/4 v0, 0x0

    iput v0, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_NONE:I

    .line 25
    const/4 v1, 0x1

    iput v1, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_DRAG:I

    .line 26
    const/4 v2, 0x2

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_DRAGING:I

    .line 27
    const/4 v2, 0x3

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_RESET:I

    .line 28
    const/4 v2, 0x4

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_SETTLE:I

    .line 29
    const/4 v2, 0x5

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_SWITCH:I

    .line 728
    iput-boolean v1, p0, Lcom/angry/mod/SwitchStyle;->buttonEdgeFrame:Z

    .line 740
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lcom/angry/mod/SwitchStyle;->rect:Landroid/graphics/RectF;

    .line 741
    iput v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    .line 745
    new-instance v1, Landroid/animation/ArgbEvaluator;

    invoke-direct {v1}, Landroid/animation/ArgbEvaluator;-><init>()V

    iput-object v1, p0, Lcom/angry/mod/SwitchStyle;->argbEvaluator:Landroid/animation/ArgbEvaluator;

    .line 752
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isTouchingDown:Z

    .line 753
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isUiInited:Z

    .line 754
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isEventBroadcast:Z

    .line 760
    new-instance v0, Lcom/angry/mod/SwitchStyle$1;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$1;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->postPendingDrag:Ljava/lang/Runnable;

    .line 769
    new-instance v0, Lcom/angry/mod/SwitchStyle$2;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$2;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->animatorUpdateListener:Landroid/animation/ValueAnimator$AnimatorUpdateListener;

    .line 833
    new-instance v0, Lcom/angry/mod/SwitchStyle$3;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$3;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->animatorListener:Landroid/animation/Animator$AnimatorListener;

    .line 43
    invoke-direct {p0, p1, p2}, Lcom/angry/mod/SwitchStyle;->init(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 44
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .registers 8
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "attrs"  # Landroid/util/AttributeSet;
    .param p3, "defStyleAttr"  # I
    .param p4, "defStyleRes"  # I

    .line 48
    invoke-direct {p0, p1, p2, p3, p4}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    .line 24
    const/4 v0, 0x0

    iput v0, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_NONE:I

    .line 25
    const/4 v1, 0x1

    iput v1, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_DRAG:I

    .line 26
    const/4 v2, 0x2

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_DRAGING:I

    .line 27
    const/4 v2, 0x3

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_RESET:I

    .line 28
    const/4 v2, 0x4

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_PENDING_SETTLE:I

    .line 29
    const/4 v2, 0x5

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->ANIMATE_STATE_SWITCH:I

    .line 728
    iput-boolean v1, p0, Lcom/angry/mod/SwitchStyle;->buttonEdgeFrame:Z

    .line 740
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lcom/angry/mod/SwitchStyle;->rect:Landroid/graphics/RectF;

    .line 741
    iput v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    .line 745
    new-instance v1, Landroid/animation/ArgbEvaluator;

    invoke-direct {v1}, Landroid/animation/ArgbEvaluator;-><init>()V

    iput-object v1, p0, Lcom/angry/mod/SwitchStyle;->argbEvaluator:Landroid/animation/ArgbEvaluator;

    .line 752
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isTouchingDown:Z

    .line 753
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isUiInited:Z

    .line 754
    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isEventBroadcast:Z

    .line 760
    new-instance v0, Lcom/angry/mod/SwitchStyle$1;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$1;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->postPendingDrag:Ljava/lang/Runnable;

    .line 769
    new-instance v0, Lcom/angry/mod/SwitchStyle$2;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$2;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->animatorUpdateListener:Landroid/animation/ValueAnimator$AnimatorUpdateListener;

    .line 833
    new-instance v0, Lcom/angry/mod/SwitchStyle$3;

    invoke-direct {v0, p0}, Lcom/angry/mod/SwitchStyle$3;-><init>(Lcom/angry/mod/SwitchStyle;)V

    iput-object v0, p0, Lcom/angry/mod/SwitchStyle;->animatorListener:Landroid/animation/Animator$AnimatorListener;

    .line 49
    invoke-direct {p0, p1, p2}, Lcom/angry/mod/SwitchStyle;->init(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 50
    return-void
.end method

.method static synthetic access$100(Lcom/angry/mod/SwitchStyle;)Z
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->isInAnimating()Z

    move-result v0

    return v0
.end method

.method static synthetic access$1000(Lcom/angry/mod/SwitchStyle;)I
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->uncheckColor:I

    return v0
.end method

.method static synthetic access$1100(Lcom/angry/mod/SwitchStyle;)I
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->checkedColor:I

    return v0
.end method

.method static synthetic access$1200(Lcom/angry/mod/SwitchStyle;)F
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    return v0
.end method

.method static synthetic access$1300(Lcom/angry/mod/SwitchStyle;)I
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->checkLineColor:I

    return v0
.end method

.method static synthetic access$1400(Lcom/angry/mod/SwitchStyle;)V
    .registers 1
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->broadcastEvent()V

    return-void
.end method

.method static synthetic access$1500(Lcom/angry/mod/SwitchStyle;)Z
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isChecked:Z

    return v0
.end method

.method static synthetic access$1502(Lcom/angry/mod/SwitchStyle;Z)Z
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;
    .param p1, "x1"  # Z

    .line 20
    iput-boolean p1, p0, Lcom/angry/mod/SwitchStyle;->isChecked:Z

    return p1
.end method

.method static synthetic access$200(Lcom/angry/mod/SwitchStyle;)V
    .registers 1
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->pendingDragState()V

    return-void
.end method

.method static synthetic access$300(Lcom/angry/mod/SwitchStyle;)I
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    return v0
.end method

.method static synthetic access$302(Lcom/angry/mod/SwitchStyle;I)I
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;
    .param p1, "x1"  # I

    .line 20
    iput p1, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    return p1
.end method

.method static synthetic access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    return-object v0
.end method

.method static synthetic access$500(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->beforeState:Lcom/angry/mod/SwitchStyle$ViewState;

    return-object v0
.end method

.method static synthetic access$600(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    return-object v0
.end method

.method static synthetic access$700(Lcom/angry/mod/SwitchStyle;)Landroid/animation/ArgbEvaluator;
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->argbEvaluator:Landroid/animation/ArgbEvaluator;

    return-object v0
.end method

.method static synthetic access$800(Lcom/angry/mod/SwitchStyle;)F
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->buttonMinX:F

    return v0
.end method

.method static synthetic access$900(Lcom/angry/mod/SwitchStyle;)F
    .registers 2
    .param p0, "x0"  # Lcom/angry/mod/SwitchStyle;

    .line 20
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->buttonMaxX:F

    return v0
.end method

.method private broadcastEvent()V
    .registers 3

    .line 494
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->onCheckedChangeListener:Lcom/angry/mod/SwitchStyle$OnCheckedChangeListener;

    if-eqz v0, :cond_e

    .line 495
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/angry/mod/SwitchStyle;->isEventBroadcast:Z

    .line 496
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isChecked()Z

    move-result v1

    invoke-interface {v0, p0, v1}, Lcom/angry/mod/SwitchStyle$OnCheckedChangeListener;->onCheckedChanged(Lcom/angry/mod/SwitchStyle;Z)V

    .line 498
    :cond_e
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isEventBroadcast:Z

    .line 499
    return-void
.end method

.method private static dp2px(F)F
    .registers 4
    .param p0, "dp"  # F

    .line 653
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    .line 654
    .local v0, "r":Landroid/content/res/Resources;
    const/4 v1, 0x1

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    invoke-static {v1, p0, v2}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v1

    return v1
.end method

.method private static dp2pxInt(F)I
    .registers 2
    .param p0, "dp"  # F

    .line 658
    invoke-static {p0}, Lcom/angry/mod/SwitchStyle;->dp2px(F)F

    move-result v0

    float-to-int v0, v0

    return v0
.end method

.method private drawArc(Landroid/graphics/Canvas;FFFFFFLandroid/graphics/Paint;)V
    .registers 18
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "left"  # F
    .param p3, "top"  # F
    .param p4, "right"  # F
    .param p5, "bottom"  # F
    .param p6, "startAngle"  # F
    .param p7, "sweepAngle"  # F
    .param p8, "paint"  # Landroid/graphics/Paint;

    .line 414
    nop

    .line 415
    const/4 v7, 0x1

    move-object v0, p1

    move v1, p2

    move v2, p3

    move v3, p4

    move v4, p5

    move v5, p6

    move/from16 v6, p7

    move-object/from16 v8, p8

    invoke-virtual/range {v0 .. v8}, Landroid/graphics/Canvas;->drawArc(FFFFFFZLandroid/graphics/Paint;)V

    .line 422
    return-void
.end method

.method private drawButton(Landroid/graphics/Canvas;FF)V
    .registers 6
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "x"  # F
    .param p3, "y"  # F

    .line 440
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->buttonRadius:F

    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->buttonPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, p3, v0, v1}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 442
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 443
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 444
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    const v1, -0x222223

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 445
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->buttonEdgeFrame:Z

    if-eqz v0, :cond_27

    .line 446
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->buttonRadius:F

    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, p3, v0, v1}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 448
    :cond_27
    return-void
.end method

.method private drawRoundRect(Landroid/graphics/Canvas;FFFFFLandroid/graphics/Paint;)V
    .registers 16
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "left"  # F
    .param p3, "top"  # F
    .param p4, "right"  # F
    .param p5, "bottom"  # F
    .param p6, "backgroundRadius"  # F
    .param p7, "paint"  # Landroid/graphics/Paint;

    .line 429
    nop

    .line 430
    move-object v0, p1

    move v1, p2

    move v2, p3

    move v3, p4

    move v4, p5

    move v5, p6

    move v6, p6

    move-object v7, p7

    invoke-virtual/range {v0 .. v7}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 437
    return-void
.end method

.method private drawUncheckIndicator(Landroid/graphics/Canvas;)V
    .registers 10
    .param p1, "canvas"  # Landroid/graphics/Canvas;

    .line 389
    iget v2, p0, Lcom/angry/mod/SwitchStyle;->uncheckCircleColor:I

    iget v0, p0, Lcom/angry/mod/SwitchStyle;->uncheckCircleWidth:I

    int-to-float v3, v0

    iget v0, p0, Lcom/angry/mod/SwitchStyle;->right:F

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->uncheckCircleOffsetX:F

    sub-float v4, v0, v1

    iget v5, p0, Lcom/angry/mod/SwitchStyle;->centerY:F

    iget v6, p0, Lcom/angry/mod/SwitchStyle;->uncheckCircleRadius:F

    iget-object v7, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    move-object v0, p0

    move-object v1, p1

    invoke-virtual/range {v0 .. v7}, Lcom/angry/mod/SwitchStyle;->drawUncheckIndicator(Landroid/graphics/Canvas;IFFFFLandroid/graphics/Paint;)V

    .line 395
    return-void
.end method

.method private init(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 13
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "attrs"  # Landroid/util/AttributeSet;

    .line 129
    const/4 v0, 0x0

    .line 131
    .local v0, "typedArray":Landroid/content/res/TypedArray;
    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Lcom/angry/mod/SwitchStyle;->optBoolean(Landroid/content/res/TypedArray;IZ)Z

    move-result v3

    iput-boolean v3, p0, Lcom/angry/mod/SwitchStyle;->shadowEffect:Z

    .line 135
    const v3, 0xaaaaaa

    invoke-static {v0, v1, v3}, Lcom/angry/mod/SwitchStyle;->optColor(Landroid/content/res/TypedArray;II)I

    move-result v3

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->uncheckCircleColor:I

    .line 139
    nop

    .line 141
    const/high16 v3, 0x3fc00000  # 1.5f

    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->dp2pxInt(F)I

    move-result v4

    .line 139
    invoke-static {v0, v1, v4}, Lcom/angry/mod/SwitchStyle;->optPixelSize(Landroid/content/res/TypedArray;II)I

    move-result v4

    iput v4, p0, Lcom/angry/mod/SwitchStyle;->uncheckCircleWidth:I

    .line 143
    const/high16 v4, 0x41200000  # 10.0f

    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->dp2px(F)F

    move-result v4

    iput v4, p0, Lcom/angry/mod/SwitchStyle;->uncheckCircleOffsetX:F

    .line 145
    nop

    .line 147
    const/high16 v4, 0x40800000  # 4.0f

    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->dp2px(F)F

    move-result v4

    .line 145
    invoke-static {v0, v1, v4}, Lcom/angry/mod/SwitchStyle;->optPixelSize(Landroid/content/res/TypedArray;IF)F

    move-result v4

    iput v4, p0, Lcom/angry/mod/SwitchStyle;->uncheckCircleRadius:F

    .line 149
    const/4 v4, 0x0

    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->dp2px(F)F

    move-result v5

    iput v5, p0, Lcom/angry/mod/SwitchStyle;->checkedLineOffsetX:F

    .line 150
    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->dp2px(F)F

    move-result v5

    iput v5, p0, Lcom/angry/mod/SwitchStyle;->checkedLineOffsetY:F

    .line 152
    nop

    .line 154
    const/high16 v5, 0x40200000  # 2.5f

    invoke-static {v5}, Lcom/angry/mod/SwitchStyle;->dp2pxInt(F)I

    move-result v5

    .line 152
    invoke-static {v0, v1, v5}, Lcom/angry/mod/SwitchStyle;->optPixelSize(Landroid/content/res/TypedArray;II)I

    move-result v5

    iput v5, p0, Lcom/angry/mod/SwitchStyle;->shadowRadius:I

    .line 156
    nop

    .line 158
    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->dp2pxInt(F)I

    move-result v3

    .line 156
    invoke-static {v0, v1, v3}, Lcom/angry/mod/SwitchStyle;->optPixelSize(Landroid/content/res/TypedArray;II)I

    move-result v3

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->shadowOffset:I

    .line 160
    const/high16 v3, -0x1000000

    invoke-static {v0, v1, v3}, Lcom/angry/mod/SwitchStyle;->optColor(Landroid/content/res/TypedArray;II)I

    move-result v5

    iput v5, p0, Lcom/angry/mod/SwitchStyle;->shadowColor:I

    .line 164
    nop

    .line 165
    const-string v5, "#ff000000"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    .line 164
    invoke-static {v0, v6, v3}, Lcom/angry/mod/SwitchStyle;->optColor(Landroid/content/res/TypedArray;II)I

    move-result v3

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->uncheckColor:I

    .line 169
    sget v3, Lcom/angry/mod/Floater;->LightPurple:I

    sget v6, Lcom/angry/mod/Floater;->LightPurple:I

    invoke-static {v0, v3, v6}, Lcom/angry/mod/SwitchStyle;->optColor(Landroid/content/res/TypedArray;II)I

    move-result v3

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->checkedColor:I

    .line 173
    nop

    .line 175
    const/high16 v3, 0x3f800000  # 1.0f

    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->dp2pxInt(F)I

    move-result v3

    .line 173
    invoke-static {v0, v1, v3}, Lcom/angry/mod/SwitchStyle;->optPixelSize(Landroid/content/res/TypedArray;II)I

    move-result v3

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->borderWidth:I

    .line 177
    invoke-static {v0, v1, v1}, Lcom/angry/mod/SwitchStyle;->optColor(Landroid/content/res/TypedArray;II)I

    move-result v3

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->checkLineColor:I

    .line 181
    nop

    .line 183
    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->dp2pxInt(F)I

    move-result v3

    .line 181
    invoke-static {v0, v1, v3}, Lcom/angry/mod/SwitchStyle;->optPixelSize(Landroid/content/res/TypedArray;II)I

    move-result v3

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->checkLineWidth:I

    .line 185
    const/high16 v3, 0x40c00000  # 6.0f

    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->dp2px(F)F

    move-result v3

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->checkLineLength:F

    .line 187
    const/4 v3, -0x1

    invoke-static {v0, v1, v3}, Lcom/angry/mod/SwitchStyle;->optColor(Landroid/content/res/TypedArray;II)I

    move-result v6

    .line 191
    .local v6, "buttonColor":I
    nop

    .line 192
    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    .line 191
    invoke-static {v0, v5, v6}, Lcom/angry/mod/SwitchStyle;->optColor(Landroid/content/res/TypedArray;II)I

    move-result v5

    iput v5, p0, Lcom/angry/mod/SwitchStyle;->uncheckButtonColor:I

    .line 196
    sget v5, Lcom/angry/mod/Floater;->LightPurple:I

    invoke-static {v0, v5, v6}, Lcom/angry/mod/SwitchStyle;->optColor(Landroid/content/res/TypedArray;II)I

    move-result v5

    iput v5, p0, Lcom/angry/mod/SwitchStyle;->checkedButtonColor:I

    .line 200
    const/16 v5, 0x12c

    invoke-static {v0, v1, v5}, Lcom/angry/mod/SwitchStyle;->optInt(Landroid/content/res/TypedArray;II)I

    move-result v5

    .line 204
    .local v5, "effectDuration":I
    invoke-static {v0, v1, v1}, Lcom/angry/mod/SwitchStyle;->optBoolean(Landroid/content/res/TypedArray;IZ)Z

    move-result v7

    iput-boolean v7, p0, Lcom/angry/mod/SwitchStyle;->isChecked:Z

    .line 208
    invoke-static {v0, v1, v2}, Lcom/angry/mod/SwitchStyle;->optBoolean(Landroid/content/res/TypedArray;IZ)Z

    move-result v7

    iput-boolean v7, p0, Lcom/angry/mod/SwitchStyle;->showIndicator:Z

    .line 212
    invoke-static {v0, v1, v3}, Lcom/angry/mod/SwitchStyle;->optColor(Landroid/content/res/TypedArray;II)I

    move-result v3

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->background:I

    .line 216
    invoke-static {v0, v1, v2}, Lcom/angry/mod/SwitchStyle;->optBoolean(Landroid/content/res/TypedArray;IZ)Z

    move-result v3

    iput-boolean v3, p0, Lcom/angry/mod/SwitchStyle;->enableEffect:Z

    .line 220
    if-eqz v0, :cond_d9

    .line 221
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 224
    :cond_d9
    new-instance v3, Landroid/graphics/Paint;

    invoke-direct {v3, v2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v3, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    .line 225
    new-instance v3, Landroid/graphics/Paint;

    invoke-direct {v3, v2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v3, p0, Lcom/angry/mod/SwitchStyle;->buttonPaint:Landroid/graphics/Paint;

    .line 226
    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 228
    iget-boolean v3, p0, Lcom/angry/mod/SwitchStyle;->shadowEffect:Z

    if-eqz v3, :cond_fb

    .line 229
    iget-object v3, p0, Lcom/angry/mod/SwitchStyle;->buttonPaint:Landroid/graphics/Paint;

    iget v7, p0, Lcom/angry/mod/SwitchStyle;->shadowRadius:I

    int-to-float v7, v7

    iget v8, p0, Lcom/angry/mod/SwitchStyle;->shadowOffset:I

    int-to-float v8, v8

    iget v9, p0, Lcom/angry/mod/SwitchStyle;->shadowColor:I

    invoke-virtual {v3, v7, v4, v8, v9}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 235
    :cond_fb
    new-instance v3, Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {v3}, Lcom/angry/mod/SwitchStyle$ViewState;-><init>()V

    iput-object v3, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    .line 236
    new-instance v3, Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {v3}, Lcom/angry/mod/SwitchStyle$ViewState;-><init>()V

    iput-object v3, p0, Lcom/angry/mod/SwitchStyle;->beforeState:Lcom/angry/mod/SwitchStyle$ViewState;

    .line 237
    new-instance v3, Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {v3}, Lcom/angry/mod/SwitchStyle$ViewState;-><init>()V

    iput-object v3, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    .line 239
    const/4 v3, 0x2

    new-array v3, v3, [F

    fill-array-data v3, :array_140

    invoke-static {v3}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v3

    iput-object v3, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    .line 240
    int-to-long v7, v5

    invoke-virtual {v3, v7, v8}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 241
    iget-object v3, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v3, v1}, Landroid/animation/ValueAnimator;->setRepeatCount(I)V

    .line 243
    iget-object v3, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    iget-object v4, p0, Lcom/angry/mod/SwitchStyle;->animatorUpdateListener:Landroid/animation/ValueAnimator$AnimatorUpdateListener;

    invoke-virtual {v3, v4}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 244
    iget-object v3, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    iget-object v4, p0, Lcom/angry/mod/SwitchStyle;->animatorListener:Landroid/animation/Animator$AnimatorListener;

    invoke-virtual {v3, v4}, Landroid/animation/ValueAnimator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 246
    invoke-super {p0, v2}, Landroid/view/View;->setClickable(Z)V

    .line 247
    invoke-virtual {p0, v1, v1, v1, v1}, Lcom/angry/mod/SwitchStyle;->setPadding(IIII)V

    .line 248
    nop

    .line 249
    const/4 v1, 0x0

    invoke-virtual {p0, v2, v1}, Lcom/angry/mod/SwitchStyle;->setLayerType(ILandroid/graphics/Paint;)V

    .line 251
    return-void

    nop

    :array_140
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private isDragState()Z
    .registers 3

    .line 589
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_7

    const/4 v0, 0x1

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    :goto_8
    return v0
.end method

.method private isInAnimating()Z
    .registers 2

    .line 580
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    if-eqz v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method private isPendingDragState()Z
    .registers 4

    .line 584
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_a

    const/4 v2, 0x3

    if-ne v0, v2, :cond_9

    goto :goto_a

    :cond_9
    const/4 v1, 0x0

    :cond_a
    :goto_a
    return v1
.end method

.method private static optBoolean(Landroid/content/res/TypedArray;IZ)Z
    .registers 4
    .param p0, "typedArray"  # Landroid/content/res/TypedArray;
    .param p1, "index"  # I
    .param p2, "def"  # Z

    .line 692
    if-nez p0, :cond_3

    return p2

    .line 693
    :cond_3
    invoke-virtual {p0, p1, p2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    return v0
.end method

.method private static optColor(Landroid/content/res/TypedArray;II)I
    .registers 4
    .param p0, "typedArray"  # Landroid/content/res/TypedArray;
    .param p1, "index"  # I
    .param p2, "def"  # I

    .line 685
    if-nez p0, :cond_3

    return p2

    .line 686
    :cond_3
    invoke-virtual {p0, p1, p2}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v0

    return v0
.end method

.method private static optInt(Landroid/content/res/TypedArray;II)I
    .registers 4
    .param p0, "typedArray"  # Landroid/content/res/TypedArray;
    .param p1, "index"  # I
    .param p2, "def"  # I

    .line 664
    if-nez p0, :cond_3

    return p2

    .line 665
    :cond_3
    invoke-virtual {p0, p1, p2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    return v0
.end method

.method private static optPixelSize(Landroid/content/res/TypedArray;IF)F
    .registers 4
    .param p0, "typedArray"  # Landroid/content/res/TypedArray;
    .param p1, "index"  # I
    .param p2, "def"  # F

    .line 671
    if-nez p0, :cond_3

    return p2

    .line 672
    :cond_3
    invoke-virtual {p0, p1, p2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v0

    return v0
.end method

.method private static optPixelSize(Landroid/content/res/TypedArray;II)I
    .registers 4
    .param p0, "typedArray"  # Landroid/content/res/TypedArray;
    .param p1, "index"  # I
    .param p2, "def"  # I

    .line 678
    if-nez p0, :cond_3

    return p2

    .line 679
    :cond_3
    invoke-virtual {p0, p1, p2}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v0

    return v0
.end method

.method private pendingCancelDragState()V
    .registers 3

    .line 619
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->isDragState()Z

    move-result v0

    if-nez v0, :cond_c

    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->isPendingDragState()Z

    move-result v0

    if-eqz v0, :cond_39

    .line 620
    :cond_c
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_19

    .line 621
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    .line 624
    :cond_19
    const/4 v0, 0x3

    iput v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    .line 625
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->beforeState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-static {v0, v1}, Lcom/angry/mod/SwitchStyle$ViewState;->access$000(Lcom/angry/mod/SwitchStyle$ViewState;Lcom/angry/mod/SwitchStyle$ViewState;)V

    .line 627
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_2f

    .line 628
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {p0, v0}, Lcom/angry/mod/SwitchStyle;->setCheckedViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V

    goto :goto_34

    .line 630
    :cond_2f
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {p0, v0}, Lcom/angry/mod/SwitchStyle;->setUncheckViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V

    .line 632
    :goto_34
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    .line 634
    :cond_39
    return-void
.end method

.method private pendingDragState()V
    .registers 3

    .line 593
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->isInAnimating()Z

    move-result v0

    if-eqz v0, :cond_7

    return-void

    .line 594
    :cond_7
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isTouchingDown:Z

    if-nez v0, :cond_c

    return-void

    .line 596
    :cond_c
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_19

    .line 597
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    .line 600
    :cond_19
    const/4 v0, 0x1

    iput v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    .line 602
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->beforeState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-static {v0, v1}, Lcom/angry/mod/SwitchStyle$ViewState;->access$000(Lcom/angry/mod/SwitchStyle$ViewState;Lcom/angry/mod/SwitchStyle$ViewState;)V

    .line 603
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-static {v0, v1}, Lcom/angry/mod/SwitchStyle$ViewState;->access$000(Lcom/angry/mod/SwitchStyle$ViewState;Lcom/angry/mod/SwitchStyle$ViewState;)V

    .line 605
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_43

    .line 606
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->checkedColor:I

    iput v1, v0, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    .line 607
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->buttonMaxX:F

    iput v1, v0, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    .line 608
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->checkedColor:I

    iput v1, v0, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    goto :goto_55

    .line 610
    :cond_43
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->uncheckColor:I

    iput v1, v0, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    .line 611
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->buttonMinX:F

    iput v1, v0, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    .line 612
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    iput v1, v0, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    .line 615
    :goto_55
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    .line 616
    return-void
.end method

.method private pendingSettleState()V
    .registers 3

    .line 637
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_d

    .line 638
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    .line 641
    :cond_d
    const/4 v0, 0x4

    iput v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    .line 642
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->beforeState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-static {v0, v1}, Lcom/angry/mod/SwitchStyle$ViewState;->access$000(Lcom/angry/mod/SwitchStyle$ViewState;Lcom/angry/mod/SwitchStyle$ViewState;)V

    .line 644
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_23

    .line 645
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {p0, v0}, Lcom/angry/mod/SwitchStyle;->setCheckedViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V

    goto :goto_28

    .line 647
    :cond_23
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {p0, v0}, Lcom/angry/mod/SwitchStyle;->setUncheckViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V

    .line 649
    :goto_28
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    .line 650
    return-void
.end method

.method private setCheckedViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V
    .registers 4
    .param p1, "viewState"  # Lcom/angry/mod/SwitchStyle$ViewState;

    .line 313
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    iput v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    .line 314
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->checkedColor:I

    iput v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    .line 315
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->checkLineColor:I

    iput v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    .line 316
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->buttonMaxX:F

    iput v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    .line 317
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->buttonPaint:Landroid/graphics/Paint;

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->checkedButtonColor:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 318
    return-void
.end method

.method private setUncheckViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V
    .registers 4
    .param p1, "viewState"  # Lcom/angry/mod/SwitchStyle$ViewState;

    .line 305
    const/4 v0, 0x0

    iput v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    .line 306
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->uncheckColor:I

    iput v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    .line 307
    const/4 v0, 0x0

    iput v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    .line 308
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->buttonMinX:F

    iput v0, p1, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    .line 309
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->buttonPaint:Landroid/graphics/Paint;

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->uncheckButtonColor:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 310
    return-void
.end method

.method private toggle(ZZ)V
    .registers 5
    .param p1, "animate"  # Z
    .param p2, "broadcast"  # Z

    .line 451
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isEnabled()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    .line 453
    :cond_7
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isEventBroadcast:Z

    if-nez v0, :cond_70

    .line 456
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isUiInited:Z

    if-nez v0, :cond_1b

    .line 457
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isChecked:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isChecked:Z

    .line 458
    if-eqz p2, :cond_1a

    .line 459
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->broadcastEvent()V

    .line 461
    :cond_1a
    return-void

    .line 464
    :cond_1b
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_28

    .line 465
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    .line 468
    :cond_28
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->enableEffect:Z

    if-eqz v0, :cond_50

    if-nez p1, :cond_2f

    goto :goto_50

    .line 482
    :cond_2f
    const/4 v0, 0x5

    iput v0, p0, Lcom/angry/mod/SwitchStyle;->animateState:I

    .line 483
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->beforeState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-static {v0, v1}, Lcom/angry/mod/SwitchStyle$ViewState;->access$000(Lcom/angry/mod/SwitchStyle$ViewState;Lcom/angry/mod/SwitchStyle$ViewState;)V

    .line 485
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_45

    .line 486
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {p0, v0}, Lcom/angry/mod/SwitchStyle;->setUncheckViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V

    goto :goto_4a

    .line 488
    :cond_45
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->afterState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {p0, v0}, Lcom/angry/mod/SwitchStyle;->setCheckedViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V

    .line 490
    :goto_4a
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->valueAnimator:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    .line 491
    return-void

    .line 469
    :cond_50
    :goto_50
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isChecked:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isChecked:Z

    .line 470
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_62

    .line 471
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {p0, v0}, Lcom/angry/mod/SwitchStyle;->setCheckedViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V

    goto :goto_67

    .line 473
    :cond_62
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {p0, v0}, Lcom/angry/mod/SwitchStyle;->setUncheckViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V

    .line 475
    :goto_67
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->postInvalidate()V

    .line 476
    if-eqz p2, :cond_6f

    .line 477
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->broadcastEvent()V

    .line 479
    :cond_6f
    return-void

    .line 454
    :cond_70
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "should NOT switch the state in method: [onCheckedChanged]!"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method protected drawCheckedIndicator(Landroid/graphics/Canvas;)V
    .registers 12
    .param p1, "canvas"  # Landroid/graphics/Canvas;

    .line 367
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v3, v0, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    iget v0, p0, Lcom/angry/mod/SwitchStyle;->checkLineWidth:I

    int-to-float v4, v0

    iget v0, p0, Lcom/angry/mod/SwitchStyle;->left:F

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    add-float v2, v0, v1

    iget v5, p0, Lcom/angry/mod/SwitchStyle;->checkedLineOffsetX:F

    sub-float v5, v2, v5

    iget v2, p0, Lcom/angry/mod/SwitchStyle;->centerY:F

    iget v6, p0, Lcom/angry/mod/SwitchStyle;->checkLineLength:F

    sub-float v7, v2, v6

    add-float/2addr v0, v1

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->checkedLineOffsetY:F

    sub-float/2addr v0, v1

    add-float v8, v2, v6

    iget-object v9, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    move-object v1, p0

    move-object v2, p1

    move v6, v7

    move v7, v0

    invoke-virtual/range {v1 .. v9}, Lcom/angry/mod/SwitchStyle;->drawCheckedIndicator(Landroid/graphics/Canvas;IFFFFFLandroid/graphics/Paint;)V

    .line 373
    return-void
.end method

.method protected drawCheckedIndicator(Landroid/graphics/Canvas;IFFFFFLandroid/graphics/Paint;)V
    .registers 15
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "color"  # I
    .param p3, "lineWidth"  # F
    .param p4, "sx"  # F
    .param p5, "sy"  # F
    .param p6, "ex"  # F
    .param p7, "ey"  # F
    .param p8, "paint"  # Landroid/graphics/Paint;

    .line 380
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p8, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 381
    invoke-virtual {p8, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 382
    invoke-virtual {p8, p3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 383
    move-object v0, p1

    move v1, p4

    move v2, p5

    move v3, p6

    move v4, p7

    move-object v5, p8

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 386
    return-void
.end method

.method protected drawUncheckIndicator(Landroid/graphics/Canvas;IFFFFLandroid/graphics/Paint;)V
    .registers 9
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "color"  # I
    .param p3, "lineWidth"  # F
    .param p4, "centerX"  # F
    .param p5, "centerY"  # F
    .param p6, "radius"  # F
    .param p7, "paint"  # Landroid/graphics/Paint;

    .line 403
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p7, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 404
    invoke-virtual {p7, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 405
    const/4 v0, 0x0

    invoke-virtual {p7, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 406
    invoke-virtual {p1, p4, p5, p6, p7}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 407
    return-void
.end method

.method public isChecked()Z
    .registers 2

    .line 82
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->isChecked:Z

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 15
    .param p1, "canvas"  # Landroid/graphics/Canvas;

    .line 322
    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 324
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 325
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 326
    iget v4, p0, Lcom/angry/mod/SwitchStyle;->left:F

    iget v5, p0, Lcom/angry/mod/SwitchStyle;->top:F

    iget v6, p0, Lcom/angry/mod/SwitchStyle;->right:F

    iget v7, p0, Lcom/angry/mod/SwitchStyle;->bottom:F

    iget v8, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    iget-object v9, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    move-object v2, p0

    move-object v3, p1

    invoke-direct/range {v2 .. v9}, Lcom/angry/mod/SwitchStyle;->drawRoundRect(Landroid/graphics/Canvas;FFFFFLandroid/graphics/Paint;)V

    .line 330
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 331
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->uncheckColor:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 332
    iget v4, p0, Lcom/angry/mod/SwitchStyle;->left:F

    iget v5, p0, Lcom/angry/mod/SwitchStyle;->top:F

    iget v6, p0, Lcom/angry/mod/SwitchStyle;->right:F

    iget v7, p0, Lcom/angry/mod/SwitchStyle;->bottom:F

    iget v8, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    iget-object v9, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    invoke-direct/range {v2 .. v9}, Lcom/angry/mod/SwitchStyle;->drawRoundRect(Landroid/graphics/Canvas;FFFFFLandroid/graphics/Paint;)V

    .line 336
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->showIndicator:Z

    if-eqz v0, :cond_45

    .line 337
    invoke-direct {p0, p1}, Lcom/angry/mod/SwitchStyle;->drawUncheckIndicator(Landroid/graphics/Canvas;)V

    .line 340
    :cond_45
    iget-object v0, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v0, v0, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    const/high16 v1, 0x3f000000  # 0.5f

    mul-float v0, v0, v1

    .line 341
    .local v0, "des":F
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 342
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    iget-object v2, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v2, v2, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 343
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    iget v2, p0, Lcom/angry/mod/SwitchStyle;->borderWidth:I

    int-to-float v2, v2

    const/high16 v3, 0x40000000  # 2.0f

    mul-float v4, v0, v3

    add-float/2addr v2, v4

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 344
    iget v1, p0, Lcom/angry/mod/SwitchStyle;->left:F

    add-float v6, v1, v0

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->top:F

    add-float v7, v1, v0

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->right:F

    sub-float v8, v1, v0

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->bottom:F

    sub-float v9, v1, v0

    iget v10, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    iget-object v11, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    move-object v4, p0

    move-object v5, p1

    invoke-direct/range {v4 .. v11}, Lcom/angry/mod/SwitchStyle;->drawRoundRect(Landroid/graphics/Canvas;FFFFFLandroid/graphics/Paint;)V

    .line 348
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 349
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 350
    iget v6, p0, Lcom/angry/mod/SwitchStyle;->left:F

    iget v7, p0, Lcom/angry/mod/SwitchStyle;->top:F

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    mul-float v2, v1, v3

    add-float v8, v6, v2

    mul-float v1, v1, v3

    add-float v9, v7, v1

    const/high16 v10, 0x42b40000  # 90.0f

    const/high16 v11, 0x43340000  # 180.0f

    iget-object v12, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    invoke-direct/range {v4 .. v12}, Lcom/angry/mod/SwitchStyle;->drawArc(Landroid/graphics/Canvas;FFFFFFLandroid/graphics/Paint;)V

    .line 354
    iget v1, p0, Lcom/angry/mod/SwitchStyle;->left:F

    iget v2, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    add-float v5, v1, v2

    iget v6, p0, Lcom/angry/mod/SwitchStyle;->top:F

    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v7, v1, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->top:F

    iget v2, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    mul-float v2, v2, v3

    add-float v8, v1, v2

    iget-object v9, p0, Lcom/angry/mod/SwitchStyle;->paint:Landroid/graphics/Paint;

    move-object v4, p1

    invoke-virtual/range {v4 .. v9}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 359
    iget-boolean v1, p0, Lcom/angry/mod/SwitchStyle;->showIndicator:Z

    if-eqz v1, :cond_c8

    .line 360
    invoke-virtual {p0, p1}, Lcom/angry/mod/SwitchStyle;->drawCheckedIndicator(Landroid/graphics/Canvas;)V

    .line 363
    :cond_c8
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v1, v1, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    iget v2, p0, Lcom/angry/mod/SwitchStyle;->centerY:F

    invoke-direct {p0, p1, v1, v2}, Lcom/angry/mod/SwitchStyle;->drawButton(Landroid/graphics/Canvas;FF)V

    .line 364
    return-void
.end method

.method protected onMeasure(II)V
    .registers 8
    .param p1, "widthMeasureSpec"  # I
    .param p2, "heightMeasureSpec"  # I

    .line 255
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v0

    .line 256
    .local v0, "widthMode":I
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v1

    .line 258
    .local v1, "heightMode":I
    const/high16 v2, -0x80000000

    const/high16 v3, 0x40000000  # 2.0f

    if-eqz v0, :cond_10

    if-ne v0, v2, :cond_16

    .line 260
    :cond_10
    sget v4, Lcom/angry/mod/SwitchStyle;->DEFAULT_WIDTH:I

    invoke-static {v4, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    .line 262
    :cond_16
    if-eqz v1, :cond_1a

    if-ne v1, v2, :cond_20

    .line 264
    :cond_1a
    sget v2, Lcom/angry/mod/SwitchStyle;->DEFAULT_HEIGHT:I

    invoke-static {v2, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    .line 266
    :cond_20
    invoke-super {p0, p1, p2}, Landroid/view/View;->onMeasure(II)V

    .line 267
    return-void
.end method

.method protected onSizeChanged(IIII)V
    .registers 11
    .param p1, "w"  # I
    .param p2, "h"  # I
    .param p3, "oldw"  # I
    .param p4, "oldh"  # I

    .line 271
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onSizeChanged(IIII)V

    .line 273
    iget v0, p0, Lcom/angry/mod/SwitchStyle;->shadowRadius:I

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->shadowOffset:I

    add-int/2addr v0, v1

    iget v1, p0, Lcom/angry/mod/SwitchStyle;->borderWidth:I

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-float v0, v0

    .line 275
    .local v0, "viewPadding":F
    int-to-float v1, p2

    sub-float/2addr v1, v0

    sub-float/2addr v1, v0

    iput v1, p0, Lcom/angry/mod/SwitchStyle;->height:F

    .line 276
    int-to-float v2, p1

    sub-float/2addr v2, v0

    sub-float/2addr v2, v0

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->width:F

    .line 278
    const/high16 v2, 0x3f000000  # 0.5f

    mul-float v1, v1, v2

    iput v1, p0, Lcom/angry/mod/SwitchStyle;->viewRadius:F

    .line 279
    iget v3, p0, Lcom/angry/mod/SwitchStyle;->borderWidth:I

    int-to-float v3, v3

    sub-float v3, v1, v3

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->buttonRadius:F

    .line 281
    iput v0, p0, Lcom/angry/mod/SwitchStyle;->left:F

    .line 282
    iput v0, p0, Lcom/angry/mod/SwitchStyle;->top:F

    .line 283
    int-to-float v3, p1

    sub-float/2addr v3, v0

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->right:F

    .line 284
    int-to-float v4, p2

    sub-float/2addr v4, v0

    iput v4, p0, Lcom/angry/mod/SwitchStyle;->bottom:F

    .line 286
    add-float v5, v0, v3

    mul-float v5, v5, v2

    iput v5, p0, Lcom/angry/mod/SwitchStyle;->centerX:F

    .line 287
    add-float/2addr v4, v0

    mul-float v4, v4, v2

    iput v4, p0, Lcom/angry/mod/SwitchStyle;->centerY:F

    .line 289
    add-float v2, v0, v1

    iput v2, p0, Lcom/angry/mod/SwitchStyle;->buttonMinX:F

    .line 290
    sub-float/2addr v3, v1

    iput v3, p0, Lcom/angry/mod/SwitchStyle;->buttonMaxX:F

    .line 292
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isChecked()Z

    move-result v1

    if-eqz v1, :cond_50

    .line 293
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {p0, v1}, Lcom/angry/mod/SwitchStyle;->setCheckedViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V

    goto :goto_55

    .line 295
    :cond_50
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    invoke-direct {p0, v1}, Lcom/angry/mod/SwitchStyle;->setUncheckViewState(Lcom/angry/mod/SwitchStyle$ViewState;)V

    .line 298
    :goto_55
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/angry/mod/SwitchStyle;->isUiInited:Z

    .line 300
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->postInvalidate()V

    .line 302
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 12
    .param p1, "event"  # Landroid/view/MotionEvent;

    .line 503
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isEnabled()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    .line 504
    :cond_8
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    .line 506
    .local v0, "actionMasked":I
    const/high16 v2, 0x3f800000  # 1.0f

    const/4 v3, 0x0

    const/4 v4, 0x1

    packed-switch v0, :pswitch_data_fe

    goto/16 :goto_fd

    .line 565
    :pswitch_15  #0x3
    iput-boolean v1, p0, Lcom/angry/mod/SwitchStyle;->isTouchingDown:Z

    .line 567
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->postPendingDrag:Ljava/lang/Runnable;

    invoke-virtual {p0, v1}, Lcom/angry/mod/SwitchStyle;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 569
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->isPendingDragState()Z

    move-result v1

    if-nez v1, :cond_28

    .line 570
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->isDragState()Z

    move-result v1

    if-eqz v1, :cond_fd

    .line 571
    :cond_28
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->pendingCancelDragState()V

    goto/16 :goto_fd

    .line 515
    :pswitch_2d  #0x2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    .line 516
    .local v1, "eventX":F
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->isPendingDragState()Z

    move-result v5

    if-eqz v5, :cond_53

    .line 517
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->getWidth()I

    move-result v5

    int-to-float v5, v5

    div-float v5, v1, v5

    .line 518
    .local v5, "fraction":F
    invoke-static {v2, v5}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    .line 520
    .end local v5  # "fraction":F
    .local v2, "fraction":F
    iget-object v3, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v5, p0, Lcom/angry/mod/SwitchStyle;->buttonMinX:F

    iget v6, p0, Lcom/angry/mod/SwitchStyle;->buttonMaxX:F

    sub-float/2addr v6, v5

    mul-float v6, v6, v2

    add-float/2addr v5, v6

    iput v5, v3, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    .end local v2  # "fraction":F
    goto :goto_94

    .line 524
    :cond_53
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->isDragState()Z

    move-result v5

    if-eqz v5, :cond_94

    .line 525
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->getWidth()I

    move-result v5

    int-to-float v5, v5

    div-float v5, v1, v5

    .line 526
    .restart local v5  # "fraction":F
    invoke-static {v2, v5}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    .line 528
    .end local v5  # "fraction":F
    .restart local v2  # "fraction":F
    iget-object v3, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget v5, p0, Lcom/angry/mod/SwitchStyle;->buttonMinX:F

    iget v6, p0, Lcom/angry/mod/SwitchStyle;->buttonMaxX:F

    sub-float/2addr v6, v5

    mul-float v6, v6, v2

    add-float/2addr v5, v6

    iput v5, v3, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    .line 532
    iget-object v3, p0, Lcom/angry/mod/SwitchStyle;->viewState:Lcom/angry/mod/SwitchStyle$ViewState;

    iget-object v5, p0, Lcom/angry/mod/SwitchStyle;->argbEvaluator:Landroid/animation/ArgbEvaluator;

    iget v6, p0, Lcom/angry/mod/SwitchStyle;->uncheckColor:I

    .line 534
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    iget v7, p0, Lcom/angry/mod/SwitchStyle;->checkedColor:I

    .line 535
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    .line 532
    invoke-virtual {v5, v2, v6, v7}, Landroid/animation/ArgbEvaluator;->evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    iput v5, v3, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    .line 537
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->postInvalidate()V

    .line 539
    .end local v2  # "fraction":F
    goto :goto_fd

    .line 524
    :cond_94
    :goto_94
    goto :goto_fd

    .line 543
    .end local v1  # "eventX":F
    :pswitch_95  #0x1
    iput-boolean v1, p0, Lcom/angry/mod/SwitchStyle;->isTouchingDown:Z

    .line 544
    iget-object v5, p0, Lcom/angry/mod/SwitchStyle;->postPendingDrag:Ljava/lang/Runnable;

    invoke-virtual {p0, v5}, Lcom/angry/mod/SwitchStyle;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 546
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    iget-wide v7, p0, Lcom/angry/mod/SwitchStyle;->touchDownTime:J

    sub-long/2addr v5, v7

    const-wide/16 v7, 0x12c

    cmp-long v9, v5, v7

    if-gtz v9, :cond_ad

    .line 547
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->toggle()V

    goto :goto_fd

    .line 548
    :cond_ad
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->isDragState()Z

    move-result v5

    if-eqz v5, :cond_dd

    .line 549
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v5

    .line 550
    .local v5, "eventX":F
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->getWidth()I

    move-result v6

    int-to-float v6, v6

    div-float v6, v5, v6

    .line 551
    .local v6, "fraction":F
    invoke-static {v2, v6}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    .line 552
    .end local v6  # "fraction":F
    .restart local v2  # "fraction":F
    const/high16 v3, 0x3f000000  # 0.5f

    cmpl-float v3, v2, v3

    if-lez v3, :cond_cd

    const/4 v1, 0x1

    .line 553
    .local v1, "newCheck":Z
    :cond_cd
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isChecked()Z

    move-result v3

    if-ne v1, v3, :cond_d7

    .line 554
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->pendingCancelDragState()V

    goto :goto_e7

    .line 556
    :cond_d7
    iput-boolean v1, p0, Lcom/angry/mod/SwitchStyle;->isChecked:Z

    .line 557
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->pendingSettleState()V

    goto :goto_e7

    .line 559
    .end local v1  # "newCheck":Z
    .end local v2  # "fraction":F
    .end local v5  # "eventX":F
    :cond_dd
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->isPendingDragState()Z

    move-result v1

    if-eqz v1, :cond_e7

    .line 560
    invoke-direct {p0}, Lcom/angry/mod/SwitchStyle;->pendingCancelDragState()V

    goto :goto_fd

    .line 559
    :cond_e7
    :goto_e7
    goto :goto_fd

    .line 508
    :pswitch_e8  #0x0
    iput-boolean v4, p0, Lcom/angry/mod/SwitchStyle;->isTouchingDown:Z

    .line 509
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    iput-wide v1, p0, Lcom/angry/mod/SwitchStyle;->touchDownTime:J

    .line 510
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->postPendingDrag:Ljava/lang/Runnable;

    invoke-virtual {p0, v1}, Lcom/angry/mod/SwitchStyle;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 511
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->postPendingDrag:Ljava/lang/Runnable;

    const-wide/16 v2, 0x32

    invoke-virtual {p0, v1, v2, v3}, Lcom/angry/mod/SwitchStyle;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 512
    nop

    .line 576
    :cond_fd
    :goto_fd
    return v4

    :pswitch_data_fe
    .packed-switch 0x0
        :pswitch_e8  #00000000
        :pswitch_95  #00000001
        :pswitch_2d  #00000002
        :pswitch_15  #00000003
    .end packed-switch
.end method

.method public setButtonEdgeFrame(Z)V
    .registers 2
    .param p1, "value"  # Z

    .line 99
    iput-boolean p1, p0, Lcom/angry/mod/SwitchStyle;->buttonEdgeFrame:Z

    .line 100
    return-void
.end method

.method public setChecked(Z)V
    .registers 4
    .param p1, "checked"  # Z

    .line 73
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->isChecked()Z

    move-result v0

    if-ne p1, v0, :cond_a

    .line 74
    invoke-virtual {p0}, Lcom/angry/mod/SwitchStyle;->postInvalidate()V

    .line 75
    return-void

    .line 77
    :cond_a
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->enableEffect:Z

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/angry/mod/SwitchStyle;->toggle(ZZ)V

    .line 78
    return-void
.end method

.method public setCheckedButtonColor(I)V
    .registers 2
    .param p1, "checkedButtonColor"  # I

    .line 91
    iput p1, p0, Lcom/angry/mod/SwitchStyle;->checkedButtonColor:I

    .line 92
    return-void
.end method

.method public setEnableEffect(Z)V
    .registers 2
    .param p1, "enable"  # Z

    .line 124
    iput-boolean p1, p0, Lcom/angry/mod/SwitchStyle;->enableEffect:Z

    .line 125
    return-void
.end method

.method public setOnCheckedChangeListener(Lcom/angry/mod/SwitchStyle$OnCheckedChangeListener;)V
    .registers 2
    .param p1, "l"  # Lcom/angry/mod/SwitchStyle$OnCheckedChangeListener;

    .line 59
    iput-object p1, p0, Lcom/angry/mod/SwitchStyle;->onCheckedChangeListener:Lcom/angry/mod/SwitchStyle$OnCheckedChangeListener;

    .line 60
    return-void
.end method

.method public final setOnClickListener(Landroid/view/View$OnClickListener;)V
    .registers 2
    .param p1, "l"  # Landroid/view/View$OnClickListener;

    .line 53
    return-void
.end method

.method public final setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V
    .registers 2
    .param p1, "l"  # Landroid/view/View$OnLongClickListener;

    .line 56
    return-void
.end method

.method public final setPadding(IIII)V
    .registers 6
    .param p1, "left"  # I
    .param p2, "top"  # I
    .param p3, "right"  # I
    .param p4, "bottom"  # I

    .line 68
    const/4 v0, 0x0

    invoke-super {p0, v0, v0, v0, v0}, Landroid/view/View;->setPadding(IIII)V

    .line 69
    return-void
.end method

.method public setShadowEffect(Z)V
    .registers 7
    .param p1, "shadowEffect"  # Z

    .line 107
    iget-boolean v0, p0, Lcom/angry/mod/SwitchStyle;->shadowEffect:Z

    if-ne v0, p1, :cond_5

    return-void

    .line 108
    :cond_5
    iput-boolean p1, p0, Lcom/angry/mod/SwitchStyle;->shadowEffect:Z

    .line 110
    const/4 v0, 0x0

    if-eqz p1, :cond_18

    .line 111
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->buttonPaint:Landroid/graphics/Paint;

    iget v2, p0, Lcom/angry/mod/SwitchStyle;->shadowRadius:I

    int-to-float v2, v2

    iget v3, p0, Lcom/angry/mod/SwitchStyle;->shadowOffset:I

    int-to-float v3, v3

    iget v4, p0, Lcom/angry/mod/SwitchStyle;->shadowColor:I

    invoke-virtual {v1, v2, v0, v3, v4}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    goto :goto_1e

    .line 116
    :cond_18
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle;->buttonPaint:Landroid/graphics/Paint;

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v0, v0, v2}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 121
    :goto_1e
    return-void
.end method

.method public setUncheckedButtonColor(I)V
    .registers 2
    .param p1, "uncheckButtonColor"  # I

    .line 95
    iput p1, p0, Lcom/angry/mod/SwitchStyle;->uncheckButtonColor:I

    .line 96
    return-void
.end method

.method public toggle()V
    .registers 2

    .line 87
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/angry/mod/SwitchStyle;->toggle(Z)V

    .line 88
    return-void
.end method

.method public toggle(Z)V
    .registers 3
    .param p1, "animate"  # Z

    .line 103
    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, Lcom/angry/mod/SwitchStyle;->toggle(ZZ)V

    .line 104
    return-void
.end method
