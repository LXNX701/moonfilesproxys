.class public Lcom/angry/mod/Initialize;
.super Ljava/lang/Object;
.source "Initialize.java"


# static fields
.field public static socket:Ljava/lang/String;


# instance fields
.field public daemonEXE:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4
    .param p1, "context"  # Landroid/content/Context;

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    const-string v0, "UtilityHelper"

    iput-object v0, p0, Lcom/angry/mod/Initialize;->daemonEXE:Ljava/lang/String;

    .line 20
    const-string v0, "Utility"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 23
    :try_start_c
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    .line 24
    .local v0, "packageManager":Landroid/content/pm/PackageManager;
    const-string v1, "com.dts.freefiremax"

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    .line 25
    .local v1, "launchIntent":Landroid/content/Intent;
    if-eqz v1, :cond_1b

    .line 26
    invoke-virtual {p1, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_1b} :catch_1c

    .line 29
    .end local v0  # "packageManager":Landroid/content/pm/PackageManager;
    .end local v1  # "launchIntent":Landroid/content/Intent;
    :cond_1b
    goto :goto_1d

    .line 28
    :catch_1c
    move-exception v0

    .line 31
    :goto_1d
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/angry/mod/Initialize$1;

    invoke-direct {v1, p0, p1}, Lcom/angry/mod/Initialize$1;-><init>(Lcom/angry/mod/Initialize;Landroid/content/Context;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 64
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 65
    return-void
.end method

.method public static CopyFromAssets(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 12
    .param p0, "ctx"  # Landroid/content/Context;
    .param p1, "outPath"  # Ljava/lang/String;
    .param p2, "fileName"  # Ljava/lang/String;

    .line 68
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 69
    .local v0, "file":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_e

    .line 70
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 73
    :cond_e
    const/4 v1, 0x0

    .line 74
    .local v1, "inputStream":Ljava/io/InputStream;
    const/4 v2, 0x0

    .line 77
    .local v2, "fileOutputStream":Ljava/io/FileOutputStream;
    const/4 v3, 0x0

    :try_start_11
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v4

    invoke-virtual {v4, p2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v4

    move-object v1, v4

    .line 78
    new-instance v4, Ljava/io/File;

    invoke-direct {v4, v0, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 79
    .local v4, "outFile":Ljava/io/File;
    new-instance v5, Ljava/io/FileOutputStream;

    invoke-direct {v5, v4}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    move-object v2, v5

    .line 81
    const/16 v5, 0x1000

    new-array v5, v5, [B

    .line 83
    .local v5, "buffer":[B
    :goto_29
    invoke-virtual {v1, v5}, Ljava/io/InputStream;->read([B)I

    move-result v6

    move v7, v6

    .local v7, "byteRead":I
    const/4 v8, -0x1

    if-eq v6, v8, :cond_35

    .line 84
    invoke-virtual {v2, v5, v3, v7}, Ljava/io/FileOutputStream;->write([BII)V

    goto :goto_29

    .line 87
    :cond_35
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->flush()V
    :try_end_38
    .catch Ljava/io/IOException; {:try_start_11 .. :try_end_38} :catch_57
    .catchall {:try_start_11 .. :try_end_38} :catchall_47

    .line 88
    nop

    .line 93
    if-eqz v1, :cond_41

    :try_start_3b
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    goto :goto_41

    .line 95
    :catch_3f
    move-exception v3

    goto :goto_45

    .line 94
    :cond_41
    :goto_41
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V
    :try_end_44
    .catch Ljava/io/IOException; {:try_start_3b .. :try_end_44} :catch_3f

    .line 96
    nop

    .line 88
    :goto_45
    const/4 v3, 0x1

    return v3

    .line 92
    .end local v4  # "outFile":Ljava/io/File;
    .end local v5  # "buffer":[B
    .end local v7  # "byteRead":I
    :catchall_47
    move-exception v3

    .line 93
    if-eqz v1, :cond_50

    :try_start_4a
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    goto :goto_50

    .line 95
    :catch_4e
    move-exception v4

    goto :goto_56

    .line 94
    :cond_50
    :goto_50
    if-eqz v2, :cond_55

    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V
    :try_end_55
    .catch Ljava/io/IOException; {:try_start_4a .. :try_end_55} :catch_4e

    .line 96
    :cond_55
    nop

    .line 97
    :goto_56
    throw v3

    .line 89
    :catch_57
    move-exception v4

    .line 90
    .local v4, "e":Ljava/io/IOException;
    nop

    .line 93
    if-eqz v1, :cond_61

    :try_start_5b
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    goto :goto_61

    .line 95
    :catch_5f
    move-exception v5

    goto :goto_67

    .line 94
    :cond_61
    :goto_61
    if-eqz v2, :cond_66

    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V
    :try_end_66
    .catch Ljava/io/IOException; {:try_start_5b .. :try_end_66} :catch_5f

    .line 96
    :cond_66
    nop

    .line 90
    :goto_67
    return v3
.end method
