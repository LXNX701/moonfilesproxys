.class Lcom/angry/mod/Floater$3;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater;->onCreateTemplate()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/angry/mod/Floater;


# direct methods
.method constructor <init>(Lcom/angry/mod/Floater;)V
    .registers 2
    .param p1, "this$0"  # Lcom/angry/mod/Floater;

    .line 406
    iput-object p1, p0, Lcom/angry/mod/Floater$3;->this$0:Lcom/angry/mod/Floater;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 5
    .param p1, "view"  # Landroid/view/View;

    .line 409
    iget-object v0, p0, Lcom/angry/mod/Floater$3;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$400(Lcom/angry/mod/Floater;)Landroid/widget/RelativeLayout;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout;->setVisibility(I)V

    .line 410
    iget-object v0, p0, Lcom/angry/mod/Floater$3;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$500(Lcom/angry/mod/Floater;)Landroid/widget/LinearLayout;

    move-result-object v0

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 411
    iget-object v0, p0, Lcom/angry/mod/Floater$3;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$000(Lcom/angry/mod/Floater;)Z

    move-result v0

    if-eqz v0, :cond_30

    .line 412
    iget-object v0, p0, Lcom/angry/mod/Floater$3;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$200(Lcom/angry/mod/Floater;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 413
    iget-object v0, p0, Lcom/angry/mod/Floater$3;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$300(Lcom/angry/mod/Floater;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_42

    .line 415
    :cond_30
    iget-object v0, p0, Lcom/angry/mod/Floater$3;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$200(Lcom/angry/mod/Floater;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 416
    iget-object v0, p0, Lcom/angry/mod/Floater$3;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$300(Lcom/angry/mod/Floater;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 418
    :goto_42
    return-void
.end method
