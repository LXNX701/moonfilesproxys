.class Lcom/angry/mod/Floater$4$1;
.super Ljava/lang/Object;
.source "Floater.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Floater$4;->onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/angry/mod/Floater$4;


# direct methods
.method constructor <init>(Lcom/angry/mod/Floater$4;)V
    .registers 2
    .param p1, "this$1"  # Lcom/angry/mod/Floater$4;

    .line 445
    iput-object p1, p0, Lcom/angry/mod/Floater$4$1;->this$1:Lcom/angry/mod/Floater$4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 448
    iget-object v0, p0, Lcom/angry/mod/Floater$4$1;->this$1:Lcom/angry/mod/Floater$4;

    iget-object v0, v0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/angry/mod/Floater;->access$702(Lcom/angry/mod/Floater;Z)Z

    .line 449
    iget-object v0, p0, Lcom/angry/mod/Floater$4$1;->this$1:Lcom/angry/mod/Floater$4;

    iget-object v0, v0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$400(Lcom/angry/mod/Floater;)Landroid/widget/RelativeLayout;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/RelativeLayout;->getAlpha()F

    move-result v0

    const/high16 v1, 0x3f000000  # 0.5f

    cmpl-float v0, v0, v1

    if-lez v0, :cond_27

    .line 450
    iget-object v0, p0, Lcom/angry/mod/Floater$4$1;->this$1:Lcom/angry/mod/Floater$4;

    iget-object v0, v0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$400(Lcom/angry/mod/Floater;)Landroid/widget/RelativeLayout;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout;->setAlpha(F)V

    goto :goto_35

    .line 452
    :cond_27
    iget-object v0, p0, Lcom/angry/mod/Floater$4$1;->this$1:Lcom/angry/mod/Floater$4;

    iget-object v0, v0, Lcom/angry/mod/Floater$4;->this$0:Lcom/angry/mod/Floater;

    invoke-static {v0}, Lcom/angry/mod/Floater;->access$400(Lcom/angry/mod/Floater;)Landroid/widget/RelativeLayout;

    move-result-object v0

    const v1, 0x3f733333  # 0.95f

    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout;->setAlpha(F)V

    .line 454
    :goto_35
    return-void
.end method
