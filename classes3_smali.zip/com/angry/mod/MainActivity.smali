.class public Lcom/angry/mod/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# static fields
.field private static final REQUEST_CODE_LOCATION_PERMISSION:I = 0x3eb

.field private static final REQUEST_CODE_OVERLAY_PERMISSION:I = 0x4d2

.field private static final REQUEST_CODE_STORAGE_PERMISSION:I = 0x3ea

.field private static final REQUEST_CODE_WIFI_PERMISSION:I = 0x3e9


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 19
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private checkPermissions()V
    .registers 3

    .line 44
    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_11

    .line 46
    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x3eb

    invoke-static {p0, v0, v1}, Landroidx/core/app/ActivityCompat;->requestPermissions(Landroid/app/Activity;[Ljava/lang/String;I)V

    .line 51
    :cond_11
    const-string v0, "android.permission.READ_EXTERNAL_STORAGE"

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_22

    .line 53
    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x3ea

    invoke-static {p0, v0, v1}, Landroidx/core/app/ActivityCompat;->requestPermissions(Landroid/app/Activity;[Ljava/lang/String;I)V

    .line 58
    :cond_22
    const-string v0, "android.permission.ACCESS_WIFI_STATE"

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_33

    .line 60
    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x3e9

    invoke-static {p0, v0, v1}, Landroidx/core/app/ActivityCompat;->requestPermissions(Landroid/app/Activity;[Ljava/lang/String;I)V

    .line 64
    :cond_33
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .registers 6
    .param p1, "savedInstanceState"  # Landroid/os/Bundle;

    .line 28
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 29
    const-string v0, "Utility"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 30
    invoke-direct {p0}, Lcom/angry/mod/MainActivity;->checkPermissions()V

    .line 31
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_3c

    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_3c

    .line 32
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 33
    .local v0, "stringBuilder":Ljava/lang/StringBuilder;
    const-string v1, "package:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    invoke-virtual {p0}, Lcom/angry/mod/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    new-instance v1, Landroid/content/Intent;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const-string v3, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    invoke-direct {v1, v3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/16 v2, 0x7d2

    invoke-virtual {p0, v1, v2}, Lcom/angry/mod/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 38
    .end local v0  # "stringBuilder":Ljava/lang/StringBuilder;
    :cond_3c
    new-instance v0, Lcom/angry/mod/LoginActivity;

    invoke-direct {v0, p0}, Lcom/angry/mod/LoginActivity;-><init>(Landroid/content/Context;)V

    .line 39
    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .registers 6
    .param p1, "requestCode"  # I
    .param p2, "permissions"  # [Ljava/lang/String;
    .param p3, "grantResults"  # [I

    .line 69
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 70
    const/4 v0, 0x0

    packed-switch p1, :pswitch_data_1a

    goto :goto_19

    .line 90
    :pswitch_8  #0x3eb
    array-length v1, p3

    if-lez v1, :cond_19

    aget v0, p3, v0

    goto :goto_19

    .line 82
    :pswitch_e  #0x3ea
    array-length v1, p3

    if-lez v1, :cond_19

    aget v0, p3, v0

    goto :goto_19

    .line 72
    :pswitch_14  #0x3e9
    array-length v1, p3

    if-lez v1, :cond_19

    aget v0, p3, v0

    .line 97
    :cond_19
    :goto_19
    return-void

    :pswitch_data_1a
    .packed-switch 0x3e9
        :pswitch_14  #000003e9
        :pswitch_e  #000003ea
        :pswitch_8  #000003eb
    .end packed-switch
.end method
