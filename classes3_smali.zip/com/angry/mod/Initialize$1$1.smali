.class Lcom/angry/mod/Initialize$1$1;
.super Ljava/lang/Object;
.source "Initialize.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/angry/mod/Initialize$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/angry/mod/Initialize$1;


# direct methods
.method constructor <init>(Lcom/angry/mod/Initialize$1;)V
    .registers 2
    .param p1, "this$1"  # Lcom/angry/mod/Initialize$1;

    .line 53
    iput-object p1, p0, Lcom/angry/mod/Initialize$1$1;->this$1:Lcom/angry/mod/Initialize$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 56
    new-instance v0, Lcom/angry/mod/Floater;

    iget-object v1, p0, Lcom/angry/mod/Initialize$1$1;->this$1:Lcom/angry/mod/Initialize$1;

    iget-object v1, v1, Lcom/angry/mod/Initialize$1;->val$context:Landroid/content/Context;

    invoke-direct {v0, v1}, Lcom/angry/mod/Floater;-><init>(Landroid/content/Context;)V

    .line 57
    return-void
.end method
