.class Lcom/angry/mod/SwitchStyle$2;
.super Ljava/lang/Object;
.source "SwitchStyle.java"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/angry/mod/SwitchStyle;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/angry/mod/SwitchStyle;


# direct methods
.method constructor <init>(Lcom/angry/mod/SwitchStyle;)V
    .registers 2
    .param p1, "this$0"  # Lcom/angry/mod/SwitchStyle;

    .line 770
    iput-object p1, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .registers 8
    .param p1, "animation"  # Landroid/animation/ValueAnimator;

    .line 773
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    .line 774
    .local v0, "value":F
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v1}, Lcom/angry/mod/SwitchStyle;->access$300(Lcom/angry/mod/SwitchStyle;)I

    move-result v1

    packed-switch v1, :pswitch_data_174

    :pswitch_13  #0x2
    goto/16 :goto_16d

    .line 803
    :pswitch_15  #0x5
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v1}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v1

    iget-object v2, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v2}, Lcom/angry/mod/SwitchStyle;->access$500(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v2

    iget v2, v2, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    iget-object v3, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    .line 804
    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->access$600(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v3

    iget v3, v3, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    iget-object v4, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->access$500(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v4

    iget v4, v4, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    sub-float/2addr v3, v4

    mul-float v3, v3, v0

    add-float/2addr v2, v3

    iput v2, v1, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    .line 806
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v1}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v1

    iget v1, v1, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    iget-object v2, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v2}, Lcom/angry/mod/SwitchStyle;->access$800(Lcom/angry/mod/SwitchStyle;)F

    move-result v2

    sub-float/2addr v1, v2

    iget-object v2, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v2}, Lcom/angry/mod/SwitchStyle;->access$900(Lcom/angry/mod/SwitchStyle;)F

    move-result v2

    iget-object v3, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->access$800(Lcom/angry/mod/SwitchStyle;)F

    move-result v3

    sub-float/2addr v2, v3

    div-float/2addr v1, v2

    .line 808
    .local v1, "fraction":F
    iget-object v2, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v2}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v2

    iget-object v3, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->access$700(Lcom/angry/mod/SwitchStyle;)Landroid/animation/ArgbEvaluator;

    move-result-object v3

    iget-object v4, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    .line 810
    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->access$1000(Lcom/angry/mod/SwitchStyle;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    iget-object v5, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    .line 811
    invoke-static {v5}, Lcom/angry/mod/SwitchStyle;->access$1100(Lcom/angry/mod/SwitchStyle;)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    .line 808
    invoke-virtual {v3, v1, v4, v5}, Landroid/animation/ArgbEvaluator;->evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    iput v3, v2, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    .line 814
    iget-object v2, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v2}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v2

    iget-object v3, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->access$1200(Lcom/angry/mod/SwitchStyle;)F

    move-result v3

    mul-float v3, v3, v1

    iput v3, v2, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    .line 815
    iget-object v2, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v2}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v2

    iget-object v3, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->access$700(Lcom/angry/mod/SwitchStyle;)Landroid/animation/ArgbEvaluator;

    move-result-object v3

    .line 817
    const/4 v4, 0x0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    iget-object v5, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    .line 818
    invoke-static {v5}, Lcom/angry/mod/SwitchStyle;->access$1300(Lcom/angry/mod/SwitchStyle;)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    .line 815
    invoke-virtual {v3, v1, v4, v5}, Landroid/animation/ArgbEvaluator;->evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    iput v3, v2, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    .line 820
    goto/16 :goto_16d

    .line 780
    .end local v1  # "fraction":F
    :pswitch_bb  #0x1, 0x3, 0x4
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v1}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v1

    iget-object v2, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v2}, Lcom/angry/mod/SwitchStyle;->access$700(Lcom/angry/mod/SwitchStyle;)Landroid/animation/ArgbEvaluator;

    move-result-object v2

    iget-object v3, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    .line 782
    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->access$500(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v3

    iget v3, v3, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iget-object v4, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    .line 783
    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->access$600(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v4

    iget v4, v4, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    .line 780
    invoke-virtual {v2, v0, v3, v4}, Landroid/animation/ArgbEvaluator;->evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iput v2, v1, Lcom/angry/mod/SwitchStyle$ViewState;->checkedLineColor:I

    .line 786
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v1}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v1

    iget-object v2, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v2}, Lcom/angry/mod/SwitchStyle;->access$500(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v2

    iget v2, v2, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    iget-object v3, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    .line 787
    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->access$600(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v3

    iget v3, v3, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    iget-object v4, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->access$500(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v4

    iget v4, v4, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    sub-float/2addr v3, v4

    mul-float v3, v3, v0

    add-float/2addr v2, v3

    iput v2, v1, Lcom/angry/mod/SwitchStyle$ViewState;->radius:F

    .line 789
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v1}, Lcom/angry/mod/SwitchStyle;->access$300(Lcom/angry/mod/SwitchStyle;)I

    move-result v1

    const/4 v2, 0x1

    if-eq v1, v2, :cond_13c

    .line 790
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v1}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v1

    iget-object v2, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v2}, Lcom/angry/mod/SwitchStyle;->access$500(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v2

    iget v2, v2, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    iget-object v3, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    .line 791
    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->access$600(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v3

    iget v3, v3, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    iget-object v4, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->access$500(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v4

    iget v4, v4, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    sub-float/2addr v3, v4

    mul-float v3, v3, v0

    add-float/2addr v2, v3

    iput v2, v1, Lcom/angry/mod/SwitchStyle$ViewState;->buttonX:F

    .line 794
    :cond_13c
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v1}, Lcom/angry/mod/SwitchStyle;->access$400(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v1

    iget-object v2, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-static {v2}, Lcom/angry/mod/SwitchStyle;->access$700(Lcom/angry/mod/SwitchStyle;)Landroid/animation/ArgbEvaluator;

    move-result-object v2

    iget-object v3, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    .line 796
    invoke-static {v3}, Lcom/angry/mod/SwitchStyle;->access$500(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v3

    iget v3, v3, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iget-object v4, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    .line 797
    invoke-static {v4}, Lcom/angry/mod/SwitchStyle;->access$600(Lcom/angry/mod/SwitchStyle;)Lcom/angry/mod/SwitchStyle$ViewState;

    move-result-object v4

    iget v4, v4, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    .line 794
    invoke-virtual {v2, v0, v3, v4}, Landroid/animation/ArgbEvaluator;->evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iput v2, v1, Lcom/angry/mod/SwitchStyle$ViewState;->checkStateColor:I

    .line 800
    nop

    .line 829
    :goto_16d
    iget-object v1, p0, Lcom/angry/mod/SwitchStyle$2;->this$0:Lcom/angry/mod/SwitchStyle;

    invoke-virtual {v1}, Lcom/angry/mod/SwitchStyle;->postInvalidate()V

    .line 830
    return-void

    nop

    :pswitch_data_174
    .packed-switch 0x1
        :pswitch_bb  #00000001
        :pswitch_13  #00000002
        :pswitch_bb  #00000003
        :pswitch_bb  #00000004
        :pswitch_15  #00000005
    .end packed-switch
.end method
